"""Report models for the `gedq batch` command."""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, model_validator

from gedq.errors import ErrorDetail


class BatchOpStatus(StrEnum):
    """Closed status vocabulary for one batch operation line."""

    APPLIED = "applied"
    """The batch committed and this line's mutation is in the written file."""

    WOULD_APPLY = "would_apply"
    """Dry-run only: this line planned clean and would have applied."""

    NOT_APPLIED = "not_applied"
    """This line planned clean, but a later line aborted the batch; rolled back."""

    FAILED = "failed"
    """This line is the one that aborted the batch."""

    NOT_REACHED = "not_reached"
    """This line was never planned because an earlier line aborted the batch."""


class BatchOpResult(BaseModel):
    """Result reported for one ops-file line."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    line: int
    """1-based ops-file line number."""

    xref: str | None
    """The line's target xref, or `None` if the line failed before xref parse."""

    status: BatchOpStatus
    """This line's outcome."""

    error: ErrorDetail | None = None
    """Embedded single-edit error envelope content, present only when `status` is `failed`."""

    @model_validator(mode="after")
    def _check_error_matches_status(self) -> BatchOpResult:
        """Require `error` exactly when `status` is `failed`."""
        has_error = self.error is not None
        is_failed = self.status is BatchOpStatus.FAILED
        if has_error != is_failed:
            raise ValueError("error must be set if and only if status is 'failed'")
        return self


class BatchSummary(BaseModel):
    """Aggregate counts across all lines in one batch report."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    total: int
    applied: int
    failed: int
    not_applied: int
    not_reached: int

    @model_validator(mode="after")
    def _check_arithmetic(self) -> BatchSummary:
        """Enforce `total = applied + failed + not_applied + not_reached` and non-negativity."""
        counts = (self.total, self.applied, self.failed, self.not_applied, self.not_reached)
        if any(count < 0 for count in counts):
            raise ValueError("batch summary counts cannot be negative")
        expected_total = self.applied + self.failed + self.not_applied + self.not_reached
        if self.total != expected_total:
            raise ValueError(
                "batch summary arithmetic violated: "
                f"total ({self.total}) != applied + failed + not_applied + not_reached "
                f"({expected_total})"
            )
        if self.failed > 1:
            raise ValueError("at most one line can be 'failed' (all-or-nothing abort)")
        return self


class BatchReport(BaseModel):
    """Full per-operation report for one `gedq batch` invocation."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    ops: tuple[BatchOpResult, ...]
    """One entry per ops-file line, in file order."""

    summary: BatchSummary
    """Aggregate counts across `ops`."""

    dry_run: bool
    """Whether this report describes a `--dry-run` invocation (no write occurred)."""

    @model_validator(mode="after")
    def _check_ops_match_summary(self) -> BatchReport:
        """Cross-check `ops` length/status counts against `summary`."""
        if len(self.ops) != self.summary.total:
            raise ValueError(
                f"batch report has {len(self.ops)} ops but summary.total={self.summary.total}"
            )
        counted: dict[BatchOpStatus, int] = dict.fromkeys(BatchOpStatus, 0)
        for op in self.ops:
            counted[op.status] += 1

        success_flavor = BatchOpStatus.WOULD_APPLY if self.dry_run else BatchOpStatus.APPLIED
        disallowed_flavor = BatchOpStatus.APPLIED if self.dry_run else BatchOpStatus.WOULD_APPLY
        blocked = counted[BatchOpStatus.FAILED] > 0

        if counted[disallowed_flavor] != 0:
            raise ValueError(
                f"unexpected '{disallowed_flavor.value}' op for dry_run={self.dry_run}"
            )
        if blocked and counted[success_flavor] != 0:
            raise ValueError(f"aborted batch must not report any op as '{success_flavor.value}'")
        if counted[success_flavor] != self.summary.applied:
            raise ValueError("ops success-flavor count does not match summary.applied")
        if counted[BatchOpStatus.FAILED] != self.summary.failed:
            raise ValueError("ops 'failed' count does not match summary.failed")
        if counted[BatchOpStatus.NOT_APPLIED] != self.summary.not_applied:
            raise ValueError("ops 'not_applied' count does not match summary.not_applied")
        if counted[BatchOpStatus.NOT_REACHED] != self.summary.not_reached:
            raise ValueError("ops 'not_reached' count does not match summary.not_reached")
        return self
