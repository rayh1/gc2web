"""Structlog configuration helpers for gedq."""

from __future__ import annotations

import logging
import sys
from collections.abc import Iterator
from contextlib import contextmanager
from hashlib import sha256
from typing import cast

import structlog
from structlog.contextvars import bound_contextvars
from structlog.typing import FilteringBoundLogger

_RESOURCE_REDACTION_DOMAIN = b"gedq-resource-v1\0"


def configure_logging(json_output: bool = False, level: int = logging.INFO) -> None:
    """Configure structlog for the current process.

    Args:
        json_output: Whether logs should use a JSON renderer.
        level: Standard-library logging level applied to the bound logger.
    """
    renderer = (
        structlog.processors.JSONRenderer() if json_output else structlog.dev.ConsoleRenderer()
    )

    logging.basicConfig(level=level, format="%(message)s")
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            renderer,
        ],
        wrapper_class=structlog.make_filtering_bound_logger(level),
        logger_factory=structlog.PrintLoggerFactory(file=sys.__stderr__),
        cache_logger_on_first_use=True,
    )


def resolve_log_level(level_name: str) -> int:
    """Resolve a configured log-level name to a stdlib logging level."""
    return logging.getLevelNamesMapping().get(level_name.upper(), logging.INFO)


def get_logger() -> FilteringBoundLogger:
    """Return the package logger.

    Returns:
        A structlog bound logger for gedq diagnostics.
    """
    return cast(FilteringBoundLogger, structlog.get_logger("gedq"))


def redact_resource_id(resource_id: str) -> str:
    """Return a deterministic, non-reversible resource correlation value.

    Args:
        resource_id: Raw resource identifier that must not enter logs.

    Returns:
        A domain-separated SHA-256 correlation token.
    """
    digest = sha256(_RESOURCE_REDACTION_DOMAIN + resource_id.encode("utf-8")).hexdigest()
    return f"sha256:{digest[:16]}"


@contextmanager
def redacted_resource_context(resource_id: str) -> Iterator[None]:
    """Bind a safe resource identifier for the duration of one operation.

    Args:
        resource_id: Raw resource identifier to correlate without disclosing it.

    Yields:
        Control while the redacted resource context is active.
    """
    with bound_contextvars(resource_id=redact_resource_id(resource_id)):
        yield
