"""Tree rendering service helpers."""

from __future__ import annotations

import re

from gedq.errors import UserError
from gedq.model.entity_ids import normalize_entity_id
from gedq.model.output import OutputRecord
from gedq.model.records import EntityRecord, RecordField
from gedq.parser.projection import Projection
from gedq.render.tree import branch_line, child_indent, format_annotation, render_tree_output
from gedq.service.read import lookup_entity_or_error
from gedq.service.validate import load_strict_document
from gedq.storage.ladybug_index import QueryHandle

_YEAR_PATTERN = re.compile(r"(\d{4})(?!.*\d{4})")


def build_tree_output(
    handle: QueryHandle,
    entity_id: str,
    *,
    direction: str,
    depth: int | None,
    mode: str,
    cap: int,
    color_mode: str,
    label: str,
    show_ids: bool,
    note_cap: int,
) -> str:
    """Build the outward ASCII tree output."""
    _ = color_mode, label, note_cap
    normalized_direction = direction.strip().lower()
    if normalized_direction not in {"up", "down"}:
        raise UserError("--direction must be one of: up, down")
    normalized_mode = mode.strip().lower()
    if normalized_mode not in {"clean", "annotated"}:
        raise UserError("--mode must be one of: clean, annotated")
    if cap < 1:
        raise UserError("--cap must be >= 1")
    if depth is not None and depth < 0:
        raise UserError("--depth must be >= 0")

    _, projection = load_strict_document(handle.source_path)
    root = lookup_entity_or_error(handle, entity_id, expected_kind="INDI", projection=projection)
    record_map = {
        normalize_entity_id(record.entity_id): record
        for record in projection.records
        if record.entity_id is not None
    }
    lines = [
        _label(
            handle,
            projection,
            root,
            record_map,
            normalized_mode,
            color_mode,
            label,
            show_ids,
            note_cap,
        )
    ]
    remaining_cap = cap - 1
    if remaining_cap <= 0 or depth == 0:
        if remaining_cap < 0:
            lines.append("… (1 more — widen scope)")
        return render_tree_output(lines)

    rendered = 0
    hidden = 0
    visited = {root.entity_id or ""}
    if normalized_direction == "down":
        rendered, hidden = _append_descendants(
            lines,
            handle,
            projection,
            record_map,
            root,
            indent="  ",
            remaining_depth=depth,
            remaining_cap=remaining_cap,
            mode=normalized_mode,
            color_mode=color_mode,
            label=label,
            show_ids=show_ids,
            note_cap=note_cap,
            visited=visited,
        )
    else:
        rendered, hidden = _append_ancestors(
            lines,
            handle,
            projection,
            record_map,
            root,
            indent="  ",
            remaining_depth=depth,
            remaining_cap=remaining_cap,
            mode=normalized_mode,
            color_mode=color_mode,
            label=label,
            show_ids=show_ids,
            note_cap=note_cap,
            visited=visited,
        )
    if hidden > 0:
        lines.append(f"… ({hidden} more — widen scope)")
    return render_tree_output(lines)


def _append_descendants(
    lines: list[str],
    handle: QueryHandle,
    projection: Projection,
    record_map: dict[str, EntityRecord],
    root: OutputRecord,
    *,
    indent: str,
    remaining_depth: int | None,
    remaining_cap: int,
    mode: str,
    color_mode: str,
    label: str,
    show_ids: bool,
    note_cap: int,
    visited: set[str],
) -> tuple[int, int]:
    if remaining_depth is not None and remaining_depth <= 0:
        return 0, 0
    if root.entity_id is None:
        return 0, 0

    families = _raw_values(root, "FAMS")
    if not families:
        return 0, 0

    rendered = 0
    hidden = 0
    next_depth = None if remaining_depth is None else remaining_depth - 1
    entries: list[tuple[OutputRecord, bool, OutputRecord | None]] = []
    for family_id in families:
        family = _lookup_optional(handle, family_id, projection)
        if family is None:
            continue
        family_people = _raw_values(family, "HUSB") + _raw_values(family, "WIFE")
        spouse_ids = [value for value in family_people if value != root.entity_id]
        for spouse_id in spouse_ids:
            spouse = _lookup_optional(handle, spouse_id, projection)
            if spouse is not None:
                entries.append((spouse, True, family))
        for child_id in _sorted_people(handle, projection, _raw_values(family, "CHIL")):
            child = _lookup_optional(handle, child_id, projection)
            if child is not None:
                entries.append((child, False, None))

    for index, (entry, is_spouse, family) in enumerate(entries):
        is_last = index == len(entries) - 1
        if remaining_cap - rendered <= 0:
            hidden += 1
            continue
        entry_label = _label(
            handle,
            projection,
            entry,
            record_map,
            mode,
            color_mode,
            label,
            show_ids,
            note_cap,
            family=family,
            spouse=is_spouse,
        )
        lines.append(branch_line(indent, entry_label, is_last=is_last, spouse=is_spouse))
        rendered += 1
        if is_spouse or entry.entity_id is None or entry.entity_id in visited:
            continue
        visited.add(entry.entity_id)
        more_rendered, more_hidden = _append_descendants(
            lines,
            handle,
            projection,
            record_map,
            entry,
            indent=child_indent(indent, has_more_siblings=not is_last),
            remaining_depth=next_depth,
            remaining_cap=remaining_cap - rendered,
            mode=mode,
            color_mode=color_mode,
            label=label,
            show_ids=show_ids,
            note_cap=note_cap,
            visited=visited,
        )
        rendered += more_rendered
        hidden += more_hidden
    return rendered, hidden


def _append_ancestors(
    lines: list[str],
    handle: QueryHandle,
    projection: Projection,
    record_map: dict[str, EntityRecord],
    root: OutputRecord,
    *,
    indent: str,
    remaining_depth: int | None,
    remaining_cap: int,
    mode: str,
    color_mode: str,
    label: str,
    show_ids: bool,
    note_cap: int,
    visited: set[str],
) -> tuple[int, int]:
    if remaining_depth is not None and remaining_depth <= 0:
        return 0, 0
    if root.entity_id is None:
        return 0, 0

    families = _raw_values(root, "FAMC")
    if not families:
        return 0, 0

    rendered = 0
    hidden = 0
    next_depth = None if remaining_depth is None else remaining_depth - 1
    entries: list[tuple[OutputRecord, bool, OutputRecord | None]] = []
    for family_id in families:
        family = _lookup_optional(handle, family_id, projection)
        if family is None:
            continue
        primary_id = _raw_values(family, "HUSB") or _raw_values(family, "WIFE")
        if not primary_id:
            continue
        parent = _lookup_optional(handle, primary_id[0], projection)
        if parent is None:
            continue
        entries.append((parent, False, None))
        family_people = _raw_values(family, "HUSB") + _raw_values(family, "WIFE")
        spouse_ids = [value for value in family_people if value != parent.entity_id]
        for spouse_id in spouse_ids:
            spouse = _lookup_optional(handle, spouse_id, projection)
            if spouse is not None:
                entries.append((spouse, True, family))

    for index, (entry, is_spouse, family) in enumerate(entries):
        is_last = index == len(entries) - 1
        if remaining_cap - rendered <= 0:
            hidden += 1
            continue
        entry_label = _label(
            handle,
            projection,
            entry,
            record_map,
            mode,
            color_mode,
            label,
            show_ids,
            note_cap,
            family=family,
            spouse=is_spouse,
        )
        lines.append(branch_line(indent, entry_label, is_last=is_last, spouse=is_spouse))
        rendered += 1
        if is_spouse or entry.entity_id is None or entry.entity_id in visited:
            continue
        visited.add(entry.entity_id)
        more_rendered, more_hidden = _append_ancestors(
            lines,
            handle,
            projection,
            record_map,
            entry,
            indent=child_indent(indent, has_more_siblings=not is_last),
            remaining_depth=next_depth,
            remaining_cap=remaining_cap - rendered,
            mode=mode,
            color_mode=color_mode,
            label=label,
            show_ids=show_ids,
            note_cap=note_cap,
            visited=visited,
        )
        rendered += more_rendered
        hidden += more_hidden
    return rendered, hidden


def _lookup_optional(
    handle: QueryHandle, entity_id: str, projection: Projection
) -> OutputRecord | None:
    try:
        return lookup_entity_or_error(handle, entity_id, projection=projection)
    except UserError:
        return None


def _sorted_people(
    handle: QueryHandle, projection: Projection, entity_ids: tuple[str, ...]
) -> list[str]:
    def key(entity_id: str) -> tuple[int, int, str]:
        record = _lookup_optional(handle, entity_id, projection)
        year = _birth_year(record)
        if year is None:
            return (1, 9999, entity_id)
        return (0, year, entity_id)

    return sorted(dict.fromkeys(entity_ids), key=key)


def _birth_year(record: OutputRecord | None) -> int | None:
    if record is None:
        return None
    for event in record.events:
        if event.tag == "BIRT" and event.date is not None:
            return _year_from_date(event.date)
    return None


def _year_from_date(raw: str | None) -> int | None:
    if not raw:
        return None
    match = _YEAR_PATTERN.search(raw)
    return None if match is None else int(match.group(1))


def _raw_values(record: OutputRecord, tag: str) -> tuple[str, ...]:
    value = record.raw_fields.get(tag)
    if value is None:
        return ()
    if isinstance(value, str):
        return (value,)
    if isinstance(value, list):
        return tuple(item for item in value if isinstance(item, str))
    return ()


def _label(
    handle: QueryHandle,
    projection: Projection,
    record: OutputRecord,
    record_map: dict[str, EntityRecord],
    mode: str,
    color_mode: str,
    label_mode: str,
    show_ids: bool,
    note_cap: int,
    *,
    family: OutputRecord | None = None,
    spouse: bool = False,
) -> str:
    label = _render_label(record, label_mode)
    if spouse and family is not None:
        suffix = _marriage_suffix(family)
        if suffix:
            label = f"{label}{suffix}"
    glyph = _glyph(handle, projection, record, record_map) if mode == "annotated" else None
    if glyph is not None:
        note = _glyph_note(handle, projection, record, record_map, glyph, note_cap)
        annotation = format_annotation(glyph, note, color_mode=color_mode)
        label = f"{label} {annotation}"
    if show_ids and record.entity_id is not None and "{id}" not in label_mode:
        label = f"{label} @{record.entity_id}@"
    return label


def _render_label(record: OutputRecord, label_mode: str) -> str:
    context = {
        "name": _display_name(record),
        "birth": _year_label(record, "BIRT"),
        "death": _year_label(record, "DEAT"),
        "birthplace": _event_place(record, "BIRT"),
        "id": record.entity_id or "",
        "occu": _event_value(record, "OCCU")
        or (_raw_values(record, "OCCU")[0] if _raw_values(record, "OCCU") else ""),
        "sex": _raw_values(record, "SEX")[0] if _raw_values(record, "SEX") else "",
    }
    if label_mode == "minimal":
        return context["name"]
    if label_mode == "standard":
        return f"{context['name']} {_lifespan_label(record)}"
    if label_mode == "rich":
        details = [_lifespan_label(record).strip("()")]
        if context["birthplace"]:
            details.append(context["birthplace"])
        if context["occu"]:
            details.append(context["occu"])
        return f"{context['name']} ({', '.join(details)})"
    rendered = label_mode
    for field, value in context.items():
        rendered = rendered.replace(f"{{{field}}}", value)
    return rendered


def _display_name(record: OutputRecord) -> str:
    if record.name is None:
        return f"@{record.entity_id}@" if record.entity_id is not None else "unknown"
    if "/" not in record.name:
        return record.name
    first = record.name.find("/")
    second = record.name.find("/", first + 1)
    if second == -1:
        return record.name.replace("/", "").strip()
    before = record.name[:first].strip()
    surname = record.name[first + 1 : second].strip()
    after = record.name[second + 1 :].strip()
    given = " ".join(part for part in (before, after) if part)
    return " ".join(part for part in (given, surname) if part)


def _lifespan_label(record: OutputRecord) -> str:
    return _compose_lifespan_label(_year_label(record, "BIRT"), _year_label(record, "DEAT"))


def _compose_lifespan_label(birth: str, death: str) -> str:
    return f"({birth}–{death})"


def _year_label(record: OutputRecord, tag: str) -> str:
    for event in record.events:
        if event.tag == tag and event.date is not None:
            year = _year_from_date(event.date)
            if year is not None:
                return str(year)
    return "?"


def _event_place(record: OutputRecord, tag: str) -> str:
    for event in record.events:
        if event.tag == tag and event.place is not None:
            return _normalize_place(event.place)
    return ""


def _normalize_place(place: str) -> str:
    parts = [part.strip() for part in place.split(",")]
    non_empty = [part for part in parts if part]
    return ", ".join(non_empty)


def _event_value(record: OutputRecord, tag: str) -> str | None:
    for event in record.events:
        if event.tag == tag and event.value is not None:
            return event.value
    return None


def _glyph(
    handle: QueryHandle,
    projection: Projection,
    record: OutputRecord,
    record_map: dict[str, EntityRecord],
) -> str | None:
    entity = record_map.get(record.entity_id or "")
    if entity is None:
        return None
    record_sources = set(_raw_values(record, "SOUR"))
    if not record_sources:
        return "✗"
    if _has_unsourced_fact(entity):
        return "⚠"
    cited_sources = set(_normalized_source_ids(record, entity))
    if any(_source_text_empty(handle, projection, source_id) for source_id in cited_sources):
        return "○"
    if any(_source_media_missing(handle, projection, source_id) for source_id in cited_sources):
        return "◍"
    return None


def _glyph_note(
    handle: QueryHandle,
    projection: Projection,
    record: OutputRecord,
    record_map: dict[str, EntityRecord],
    glyph: str,
    note_cap: int,
) -> str | None:
    entity = record_map.get(record.entity_id or "")
    if entity is None:
        return None
    if glyph == "✗":
        return None
    if glyph == "⚠":
        tags = _unsourced_tags(entity)
        return None if not tags else ",".join(tags)
    cited_sources = _normalized_source_ids(record, entity)
    if glyph == "○":
        source_ids = [
            source_id
            for source_id in cited_sources
            if _source_text_empty(handle, projection, source_id)
        ]
        return _format_source_id_note(source_ids, note_cap)
    if glyph == "◍":
        source_ids = [
            source_id
            for source_id in cited_sources
            if _source_media_missing(handle, projection, source_id)
        ]
        return _format_source_id_note(source_ids, note_cap)
    return None


def _format_source_id_note(source_ids: list[str], note_cap: int) -> str | None:
    if not source_ids:
        return None
    if note_cap == 0:
        return f"{len(source_ids)} total"
    if len(source_ids) <= note_cap:
        return ",".join(source_ids)
    visible = ",".join(source_ids[:note_cap])
    hidden = len(source_ids) - note_cap
    return f"{visible} +{hidden} more"


def _event_source_ids(record: EntityRecord) -> tuple[str, ...]:
    source_ids: list[str] = []
    for event in record.events:
        source_ids.extend(event.source_ids)
        for association in event.associations:
            source_ids.extend(association.source_ids)
    for association in record.associations:
        source_ids.extend(association.source_ids)
    for field in record.fields:
        if field.tag == "NAME":
            source_ids.extend(field.source_ids)
    return tuple(dict.fromkeys(source_ids))


def _normalized_source_ids(record: OutputRecord, entity: EntityRecord) -> tuple[str, ...]:
    source_ids = list(_raw_values(record, "SOUR")) + list(_event_source_ids(entity))
    normalized = [normalize_entity_id(source_id) for source_id in source_ids]
    return tuple(dict.fromkeys(normalized))


def _has_unsourced_fact(record: EntityRecord) -> bool:
    return bool(_unsourced_tags(record))


def _unsourced_tags(record: EntityRecord) -> tuple[str, ...]:
    tags: list[str] = []
    for event in record.events:
        if _is_substantive_event(event) and not event.source_ids:
            tags.append(event.tag)
    for field in record.fields:
        if (
            field.tag == "NAME"
            and field.value is not None
            and not field.source_ids
            and not _placeholder_name(field)
        ):
            tags.append(field.tag)
    return tuple(dict.fromkeys(tags))


def _marriage_suffix(family: OutputRecord) -> str:
    for event in family.events:
        if event.tag == "MARR" and event.date is not None:
            return f" m. {event.date}"
    return ""


def _is_substantive_event(event: object) -> bool:
    return bool(
        getattr(event, "value", None)
        or getattr(event, "date_raw", None)
        or getattr(event, "place", None)
    )


def _placeholder_name(field: RecordField) -> bool:
    if field.value is None:
        return False
    normalized = field.value.decode("utf-8").strip().upper()
    return normalized in {"N /N/", "N.N. /.../"}


def _source_text_empty(handle: QueryHandle, projection: Projection, source_id: str) -> bool:
    source = _lookup_optional(handle, source_id, projection)
    return source is not None and (source.source_text is None or not source.source_text.strip())


def _source_media_missing(handle: QueryHandle, projection: Projection, source_id: str) -> bool:
    source = _lookup_optional(handle, source_id, projection)
    if source is None:
        return False
    if source.media_path is not None:
        return False
    return not _raw_values(source, "OBJE")
