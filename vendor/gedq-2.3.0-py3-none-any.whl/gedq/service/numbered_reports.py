"""Shared numbered genealogy report services."""

from __future__ import annotations

from dataclasses import dataclass

from gedq.errors import UserError
from gedq.model.dates import DateValue, parse_date_value
from gedq.model.entity_ids import canonical_entity_xref, normalize_entity_id
from gedq.model.output import NumberedReport, NumberedReportPersonRow, OutputRecord
from gedq.model.records import EntityRecord, RecordField
from gedq.parser.projection import Projection
from gedq.service.read import _load_projection, lookup_entity_or_error
from gedq.service.tree import _compose_lifespan_label, _display_name
from gedq.storage.ladybug_index import QueryHandle


@dataclass(frozen=True)
class NumberedReportRequest:
    """Typed request for numbered genealogy report commands."""

    report: str
    entity_id: str
    generations: int | None = None
    system: str = "sosa"

    @classmethod
    def ahnentafel(
        cls,
        *,
        entity_id: str,
        generations: int | None = None,
    ) -> NumberedReportRequest:
        """Build a request for the Ahnentafel command."""
        return cls(report="ahnentafel", entity_id=entity_id, generations=generations, system="sosa")

    @classmethod
    def register(
        cls,
        *,
        entity_id: str,
        generations: int | None = None,
        system: str = "register",
    ) -> NumberedReportRequest:
        """Build a request for the descendant numbered-report command."""
        return cls(report="register", entity_id=entity_id, generations=generations, system=system)


def build_ahnentafel_report(
    handle: QueryHandle,
    request: NumberedReportRequest,
) -> NumberedReport:
    """Build a deterministic Sosa-Stradonitz ancestor report."""
    projection = _load_projection(handle)
    root_record = _lookup_record(handle, request.entity_id)
    rows = _build_ahnentafel_rows(
        handle,
        projection,
        root_record,
        number=1,
        generation=1,
        generations=request.generations,
        path=(normalize_entity_id(root_record.entity_id or request.entity_id),),
    )
    rows.sort(key=lambda row: _number_sort_key(row.number))
    cross_refs = _cross_reference_numbers(rows)
    finalized_rows = []
    for row in rows:
        if row.entity_id is None:
            finalized_rows.append(row)
            continue
        finalized_rows.append(
            row.model_copy(
                update={"also_numbered": cross_refs.get(f"{row.entity_id}:{row.number}", ())}
            )
        )
    return NumberedReport(
        report="ahnentafel",
        subject_id=normalize_entity_id(root_record.entity_id or request.entity_id),
        system="sosa",
        generations=request.generations,
        people=tuple(finalized_rows),
    )


def build_register_report(
    handle: QueryHandle,
    request: NumberedReportRequest,
) -> NumberedReport:
    """Build a deterministic descendant numbered report."""
    projection = _load_projection(handle)
    root_record = _lookup_record(handle, request.entity_id)
    rows: list[NumberedReportPersonRow] = []
    seen_entities: dict[str, str] = {}

    if request.system == "daboville":
        _build_daboville_rows(
            handle,
            projection,
            root_record,
            number="1",
            generation=1,
            generations=request.generations,
            rows=rows,
            seen_entities=seen_entities,
            active_path=(normalize_entity_id(root_record.entity_id or request.entity_id),),
        )
    else:
        rows.extend(
            _build_register_generation_banded_rows(
                handle, projection, root_record, request.generations
            )
        )

    return NumberedReport(
        report="register",
        subject_id=normalize_entity_id(root_record.entity_id or request.entity_id),
        system=request.system,
        generations=request.generations,
        people=tuple(rows),
    )


def _build_ahnentafel_rows(
    handle: QueryHandle,
    projection: Projection,
    record: EntityRecord,
    *,
    number: int,
    generation: int,
    generations: int | None,
    path: tuple[str, ...],
) -> list[NumberedReportPersonRow]:
    entity_id = normalize_entity_id(record.entity_id)
    if not entity_id:
        raise UserError(f"entity not found: {path[-1]}")
    if entity_id in path[:-1]:
        raise UserError(f"cycle detected while traversing ahnentafel: {' -> '.join(path)}")

    output = lookup_entity_or_error(handle, entity_id)
    row = NumberedReportPersonRow(
        number=str(number),
        entity_id=entity_id,
        name=output.name,
        birth_year=_event_year(output, "BIRT"),
        death_year=_event_year(output, "DEAT"),
        generation=generation,
    )
    rows = [row]
    if generations is not None and generation >= generations:
        return rows

    father_id, mother_id = _parent_slots(record, projection)
    next_generation = generation + 1
    rows.extend(
        _ahnentafel_parent_rows(
            handle,
            projection,
            parent_id=father_id,
            number=2 * number,
            generation=next_generation,
            generations=generations,
            path=(
                *path,
                normalize_entity_id(father_id)
                if father_id is not None
                else f"unknown:{2 * number}",
            ),
        )
    )
    rows.extend(
        _ahnentafel_parent_rows(
            handle,
            projection,
            parent_id=mother_id,
            number=2 * number + 1,
            generation=next_generation,
            generations=generations,
            path=(
                *path,
                normalize_entity_id(mother_id)
                if mother_id is not None
                else f"unknown:{2 * number + 1}",
            ),
        )
    )
    return rows


def _ahnentafel_parent_rows(
    handle: QueryHandle,
    projection: Projection,
    *,
    parent_id: str | None,
    number: int,
    generation: int,
    generations: int | None,
    path: tuple[str, ...],
) -> list[NumberedReportPersonRow]:
    if parent_id is None:
        return [_unknown_row(number=number, generation=generation)]

    parent_record = projection.get_record(parent_id)
    if parent_record is None:
        return [_unknown_row(number=number, generation=generation)]

    return _build_ahnentafel_rows(
        handle,
        projection,
        parent_record,
        number=number,
        generation=generation,
        generations=generations,
        path=path,
    )


def _unknown_row(*, number: int, generation: int) -> NumberedReportPersonRow:
    return NumberedReportPersonRow(
        number=str(number),
        entity_id=None,
        name="— unknown —",
        birth_year=None,
        death_year=None,
        generation=generation,
    )


def _build_daboville_rows(
    handle: QueryHandle,
    projection: Projection,
    record: EntityRecord,
    *,
    number: str,
    generation: int,
    generations: int | None,
    rows: list[NumberedReportPersonRow],
    seen_entities: dict[str, str],
    active_path: tuple[str, ...],
) -> None:
    entity_id = normalize_entity_id(record.entity_id)
    if not entity_id:
        raise UserError(f"entity not found: {active_path[-1]}")
    if entity_id in active_path[:-1]:
        raise UserError(f"cycle detected while traversing register: {' -> '.join(active_path)}")

    output = lookup_entity_or_error(handle, entity_id)
    first_number = seen_entities.get(entity_id)
    if first_number is None:
        seen_entities[entity_id] = number
        rows.append(
            NumberedReportPersonRow(
                number=number,
                entity_id=entity_id,
                name=output.name,
                birth_year=_event_year(output, "BIRT"),
                death_year=_event_year(output, "DEAT"),
                generation=generation,
            )
        )
    else:
        rows.append(
            NumberedReportPersonRow(
                number=number,
                entity_id=entity_id,
                name=output.name,
                birth_year=_event_year(output, "BIRT"),
                death_year=_event_year(output, "DEAT"),
                generation=generation,
                also_numbered=(first_number,),
            )
        )
        return

    if generations is not None and generation >= generations:
        return

    for index, child in enumerate(_ordered_descendants(projection, record), start=1):
        _build_daboville_rows(
            handle,
            projection,
            child,
            number=f"{number}.{index}",
            generation=generation + 1,
            generations=generations,
            rows=rows,
            seen_entities=seen_entities,
            active_path=(*active_path, normalize_entity_id(child.entity_id)),
        )


@dataclass(frozen=True)
class _RegisterPrincipal:
    record: EntityRecord
    generation: int
    active_path: tuple[str, ...]


def _build_register_generation_banded_rows(
    handle: QueryHandle,
    projection: Projection,
    root_record: EntityRecord,
    generations: int | None,
) -> list[NumberedReportPersonRow]:
    root_id = normalize_entity_id(root_record.entity_id)
    current_level = [_RegisterPrincipal(root_record, 1, (root_id,))]
    first_occurrence: dict[str, str] = {root_id: "1"}
    rows: list[NumberedReportPersonRow] = []
    next_entry_number = 1

    while current_level:
        next_level: list[_RegisterPrincipal] = []
        for principal in current_level:
            entity_id = normalize_entity_id(principal.record.entity_id)
            if not entity_id:
                raise UserError(f"entity not found: {principal.active_path[-1]}")

            entry_number = str(next_entry_number)
            next_entry_number += 1
            output = lookup_entity_or_error(handle, entity_id)
            rows.append(
                NumberedReportPersonRow(
                    number=entry_number,
                    entity_id=entity_id,
                    name=output.name,
                    birth_year=_event_year(output, "BIRT"),
                    death_year=_event_year(output, "DEAT"),
                    generation=principal.generation,
                )
            )

            if generations is not None and principal.generation >= generations:
                continue

            descendants = _ordered_descendants(projection, principal.record)
            for marker, child in zip(_roman_markers(len(descendants)), descendants, strict=False):
                child_id = normalize_entity_id(child.entity_id)
                if child_id in principal.active_path:
                    cycle = " -> ".join((*principal.active_path, child_id))
                    raise UserError(f"cycle detected while traversing register: {cycle}")

                preview_number = f"{entry_number}.{marker}"
                child_output = lookup_entity_or_error(handle, child_id)
                already_seen = child_id in first_occurrence
                child_has_descendants = bool(_ordered_descendants(projection, child))
                carries_forward = not already_seen and child_has_descendants
                if not already_seen:
                    first_occurrence[child_id] = preview_number
                rows.append(
                    NumberedReportPersonRow(
                        number=preview_number,
                        entity_id=child_id,
                        name=child_output.name,
                        birth_year=_event_year(child_output, "BIRT"),
                        death_year=_event_year(child_output, "DEAT"),
                        generation=principal.generation + 1,
                        child_marker=marker,
                        carries_forward=carries_forward,
                        also_numbered=(first_occurrence[child_id],) if already_seen else (),
                    )
                )
                if carries_forward:
                    next_level.append(
                        _RegisterPrincipal(
                            child,
                            principal.generation + 1,
                            (*principal.active_path, child_id),
                        )
                    )
        current_level = next_level

    return rows


def _ordered_descendants(projection: Projection, record: EntityRecord) -> list[EntityRecord]:
    descendants: list[tuple[tuple[int, int, int, str], EntityRecord]] = []
    for family in _families_for_parent(projection, record):
        for child_id in _child_ids(family.fields):
            child_record = projection.get_record(child_id)
            if child_record is None:
                continue
            descendants.append((_birth_sort_key(child_record), child_record))
    descendants.sort(key=lambda item: item[0])
    return [record for _, record in descendants]


def _families_for_parent(projection: Projection, record: EntityRecord) -> list[EntityRecord]:
    family_ids = [ref for field in record.fields if field.tag == "FAMS" for ref in field.references]
    families: list[tuple[tuple[int, int, int, str], EntityRecord]] = []
    for family_id in family_ids:
        family = projection.get_record(family_id)
        if family is None:
            continue
        families.append((_family_sort_key(family), family))
    families.sort(key=lambda item: item[0])
    return [family for _, family in families]


def _child_ids(fields: tuple[RecordField, ...]) -> list[str]:
    children: list[str] = []
    for field in fields:
        if field.tag != "CHIL":
            continue
        children.extend(field.references)
    return children


def _birth_sort_key(record: EntityRecord) -> tuple[int, int, int, str]:
    birth = _record_event_date(record, "BIRT")
    return _date_sort_key(birth, normalize_entity_id(record.entity_id))


def _family_sort_key(record: EntityRecord) -> tuple[int, int, int, str]:
    marriage = _earliest_family_order_date(record)
    return _date_sort_key(marriage, normalize_entity_id(record.entity_id))


def _date_sort_key(date_value: DateValue | None, entity_id: str) -> tuple[int, int, int, str]:
    if date_value is None:
        return (9999, 99, 99, entity_id)
    month = date_value.month if date_value.month is not None else 99
    day = date_value.day if date_value.day is not None else 99
    year = date_value.year if date_value.year is not None else 9999
    return (year, month, day, entity_id)


def _earliest_family_order_date(record: EntityRecord) -> DateValue | None:
    candidates = [
        _record_event_date(record, tag)
        for tag in ("MARR", "MARB", "MARL", "MARC")
        if _record_event_date(record, tag) is not None
    ]
    if not candidates:
        return None
    return min(candidates, key=lambda value: _date_sort_key(value, ""))


def _record_event_year(record: EntityRecord, tag: str) -> int | None:
    date_value = _record_event_date(record, tag)
    return None if date_value is None else date_value.year


def _record_event_date(record: EntityRecord, tag: str) -> DateValue | None:
    for event in record.events:
        if event.tag == tag and event.date is not None:
            return event.date
    return None


def _roman_markers(count: int) -> list[str]:
    return [_to_roman(value).lower() for value in range(1, count + 1)]


def _to_roman(value: int) -> str:
    numerals = (
        (1000, "M"),
        (900, "CM"),
        (500, "D"),
        (400, "CD"),
        (100, "C"),
        (90, "XC"),
        (50, "L"),
        (40, "XL"),
        (10, "X"),
        (9, "IX"),
        (5, "V"),
        (4, "IV"),
        (1, "I"),
    )
    remainder = value
    output: list[str] = []
    for arabic, roman in numerals:
        while remainder >= arabic:
            remainder -= arabic
            output.append(roman)
    return "".join(output)


def _lookup_record(handle: QueryHandle, entity_id: str) -> EntityRecord:
    projection = _load_projection(handle)
    record = projection.get_record(canonical_entity_xref(entity_id))
    if record is None:
        raise UserError(f"entity not found: {entity_id}")
    return record


def _parent_slots(record: EntityRecord, projection: Projection) -> tuple[str | None, str | None]:
    famc_ids = [ref for field in record.fields if field.tag == "FAMC" for ref in field.references]
    if not famc_ids:
        return None, None

    family = projection.get_record(famc_ids[0])
    if family is None:
        return None, None

    husband = _first_reference(family.fields, "HUSB")
    wife = _first_reference(family.fields, "WIFE")
    return husband, wife


def _first_reference(fields: tuple[RecordField, ...], tag: str) -> str | None:
    for field in fields:
        if field.tag == tag and field.references:
            return field.references[0]
    return None


def _event_year(record: OutputRecord, tag: str) -> int | None:
    for event in record.events:
        if event.tag != tag or event.date is None:
            continue
        parsed = parse_date_value(event.date.encode("utf-8"))
        if parsed is not None:
            return parsed.year
    return None


def _cross_reference_numbers(
    rows: list[NumberedReportPersonRow],
) -> dict[str, tuple[str, ...]]:
    numbers_by_entity: dict[str, list[str]] = {}
    for row in rows:
        if row.entity_id is None:
            continue
        numbers_by_entity.setdefault(row.entity_id, []).append(row.number)

    cross_refs: dict[str, tuple[str, ...]] = {}
    for entity_id, numbers in numbers_by_entity.items():
        if len(numbers) <= 1:
            continue
        ordered = tuple(sorted(numbers, key=_number_sort_key))
        for current in ordered:
            cross_refs[f"{entity_id}:{current}"] = tuple(
                number for number in ordered if number != current
            )
    return cross_refs


def _number_sort_key(number: str) -> tuple[int, ...]:
    return tuple(int(part) for part in number.split("."))


def format_numbered_report(report: NumberedReport) -> str:
    """Render numbered report rows in the outward human-readable format."""
    return "\n".join(_format_numbered_row(row) for row in report.people)


def _format_numbered_row(row: NumberedReportPersonRow) -> str:
    if row.name is None:
        name = "— unknown —"
    else:
        display_record = OutputRecord(
            kind="INDI",
            entity_id=row.entity_id,
            name=row.name,
        )
        name = _display_name(display_record)
    identity = f"[{row.entity_id}]" if row.entity_id is not None else ""
    birth = str(row.birth_year) if row.birth_year is not None else "?"
    death = str(row.death_year) if row.death_year is not None else "?"
    lifespan = _compose_lifespan_label(birth, death)
    parts = [row.number, name]
    if identity:
        parts.append(identity)
    parts.append(lifespan)
    if row.also_numbered:
        also = ", ".join(row.also_numbered)
        parts.append(f"(also {also})")
    if row.child_marker is not None:
        parts.append(f"[{row.child_marker}]")
    if row.carries_forward:
        parts.append("+")
    return "  ".join(parts)
