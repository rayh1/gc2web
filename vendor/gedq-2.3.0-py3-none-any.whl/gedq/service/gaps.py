"""Deterministic worklist helpers for the gaps command."""

from __future__ import annotations

from dataclasses import dataclass

from gedq.errors import UserError
from gedq.model.output import GapRow, GapsReport, OutputRecord
from gedq.model.records import EntityRecord
from gedq.parser.projection import Projection
from gedq.query.properties import build_record_raw_fields
from gedq.service.analyze import _year_from_raw
from gedq.service.read import lookup_entity
from gedq.service.tree import _compose_lifespan_label, _display_name
from gedq.service.validate import load_strict_document
from gedq.storage.ladybug_index import QueryHandle

_CHECK_ORDER = (
    "marriage-no-children",
    "couple-no-marriage",
    "death-no-burial",
    "overdue-death",
    "birth-no-baptism",
)
_DEFAULT_CHECKS = _CHECK_ORDER[:4]


@dataclass(frozen=True)
class GapsRequest:
    """Normalized outward request for the gaps command."""

    checks: tuple[str, ...]
    reference_year: int | None = None

    @classmethod
    def from_cli(cls, *, checks: str | None, as_of: str | None) -> GapsRequest:
        """Normalize the outward CLI selection for the gaps command."""
        resolved_checks = parse_check_selection(checks)
        return cls(checks=resolved_checks, reference_year=_parse_reference_year(as_of))


def parse_check_selection(raw: str | None) -> tuple[str, ...]:
    """Normalize the outward `--check` selection."""
    if raw is None:
        return _DEFAULT_CHECKS
    parts = tuple(part.strip().lower() for part in raw.split(",") if part.strip())
    if not parts:
        raise UserError("--check requires one or more values")
    invalid = [part for part in parts if part not in _CHECK_ORDER]
    if invalid:
        valid = ", ".join(_CHECK_ORDER)
        raise UserError(f"unsupported gaps check(s): {', '.join(invalid)}; valid checks: {valid}")
    return tuple(dict.fromkeys(parts))


def build_gaps_report(handle: QueryHandle, request: GapsRequest) -> GapsReport:
    """Build the outward gaps report for one GEDCOM file."""
    _, projection = load_strict_document(handle.source_path)
    reference_year = request.reference_year
    if reference_year is None:
        reference_year = latest_resolvable_year(projection)
    rows: list[GapRow] = []
    for check in request.checks:
        rows.extend(_rows_for_check(handle, projection, check, reference_year))
    rows.sort(key=lambda row: (_CHECK_ORDER.index(row.check), row.entity_id))
    return GapsReport(reference_year=reference_year, niches=tuple(rows))


def format_gaps_report(report: GapsReport) -> str:
    """Render gaps rows in the outward human-readable format."""
    if not report.niches:
        return "no gaps found"
    return "\n".join(
        f"{row.check}  {row.entity_id}  {row.label}  {row.reason}" for row in report.niches
    )


def latest_resolvable_year(projection: Projection) -> int:
    """Return the latest exact year resolved anywhere in the file, or zero if none exist."""
    years = [
        year
        for record in projection.records
        for event in record.events
        for year in (_exact_event_year(event),)
        if year is not None
    ]
    return max(years, default=0)


def _parse_reference_year(raw: str | None) -> int | None:
    if raw is None:
        return None
    text = raw.strip()
    if not text:
        raise UserError("--as-of must be a 4-digit year or ISO date")
    if len(text) == 4 and text.isdigit():
        return int(text)
    if len(text) >= 4 and text[:4].isdigit() and text[4:5] == "-":
        return int(text[:4])
    raise UserError("--as-of must be a 4-digit year or ISO date")


def _rows_for_check(
    handle: QueryHandle,
    projection: Projection,
    check: str,
    reference_year: int,
) -> list[GapRow]:
    if check == "marriage-no-children":
        return _marriage_no_children_rows(handle, projection)
    if check == "couple-no-marriage":
        return _couple_no_marriage_rows(handle, projection)
    if check == "death-no-burial":
        return _death_no_burial_rows(handle, projection)
    if check == "overdue-death":
        return _overdue_death_rows(handle, projection, reference_year)
    if check == "birth-no-baptism":
        return _birth_no_baptism_rows(handle, projection)
    raise UserError(f"unsupported gaps check: {check}")


def _marriage_no_children_rows(handle: QueryHandle, projection: Projection) -> list[GapRow]:
    rows: list[GapRow] = []
    for record in projection.records:
        if record.kind != "FAM" or record.entity_id is None:
            continue
        fields = build_record_raw_fields(record, projection)
        if not _has_event(record, "MARR"):
            continue
        if _values_as_tuple(fields.get("CHIL")):
            continue
        rows.append(
            GapRow(
                check="marriage-no-children",
                entity_id=_normalized_id(record.entity_id),
                entity_kind="FAM",
                label=_family_label(handle, projection, record),
                reason=f"MARR {_event_year_label(record, 'MARR')}, 0 CHIL",
            )
        )
    return rows


def _couple_no_marriage_rows(handle: QueryHandle, projection: Projection) -> list[GapRow]:
    rows: list[GapRow] = []
    for record in projection.records:
        if record.kind != "FAM" or record.entity_id is None:
            continue
        fields = build_record_raw_fields(record, projection)
        if not _values_as_tuple(fields.get("HUSB")) or not _values_as_tuple(fields.get("WIFE")):
            continue
        if _has_event(record, "MARR"):
            continue
        rows.append(
            GapRow(
                check="couple-no-marriage",
                entity_id=_normalized_id(record.entity_id),
                entity_kind="FAM",
                label=_family_label(handle, projection, record),
                reason="HUSB + WIFE present, no MARR",
            )
        )
    return rows


def _death_no_burial_rows(handle: QueryHandle, projection: Projection) -> list[GapRow]:
    rows: list[GapRow] = []
    for record in projection.records:
        if record.kind != "INDI" or record.entity_id is None:
            continue
        if not _has_event(record, "DEAT") or _has_event(record, "BURI"):
            continue
        rows.append(
            GapRow(
                check="death-no-burial",
                entity_id=_normalized_id(record.entity_id),
                entity_kind="INDI",
                label=_person_label(handle, projection, record),
                reason=f"DEAT {_event_year_label(record, 'DEAT')}, no BURI",
            )
        )
    return rows


def _overdue_death_rows(
    handle: QueryHandle,
    projection: Projection,
    reference_year: int,
) -> list[GapRow]:
    rows: list[GapRow] = []
    for record in projection.records:
        if record.kind != "INDI" or record.entity_id is None or _has_event(record, "DEAT"):
            continue
        birth_year = _birth_year(record)
        if birth_year is None:
            continue
        age = reference_year - birth_year
        if age <= 120:
            continue
        rows.append(
            GapRow(
                check="overdue-death",
                entity_id=_normalized_id(record.entity_id),
                entity_kind="INDI",
                label=_person_label(handle, projection, record),
                reason=f"born {birth_year}; no DEAT; {age}y by {reference_year}",
                birth_year=birth_year,
            )
        )
    return rows


def _birth_no_baptism_rows(handle: QueryHandle, projection: Projection) -> list[GapRow]:
    rows: list[GapRow] = []
    for record in projection.records:
        if record.kind != "INDI" or record.entity_id is None:
            continue
        if (
            not _has_event(record, "BIRT")
            or _has_event(record, "CHR")
            or _has_event(record, "BAPM")
        ):
            continue
        rows.append(
            GapRow(
                check="birth-no-baptism",
                entity_id=_normalized_id(record.entity_id),
                entity_kind="INDI",
                label=_person_label(handle, projection, record),
                reason=f"BIRT {_event_year_label(record, 'BIRT')}, no CHR/BAPM",
            )
        )
    return rows


def _person_label(handle: QueryHandle, projection: Projection, record: EntityRecord) -> str:
    output = lookup_entity(handle, record.entity_id or "", projection=projection)
    if output is None:
        return _normalized_id(record.entity_id)
    return f"{_display_name(output)} {_lifespan(output)}"


def _family_label(handle: QueryHandle, projection: Projection, record: EntityRecord) -> str:
    fields = build_record_raw_fields(record, projection)
    spouses = []
    for key in ("HUSB", "WIFE"):
        for entity_id in _values_as_tuple(fields.get(key)):
            output = lookup_entity(handle, entity_id, expected_kind="INDI", projection=projection)
            if output is None:
                spouses.append(entity_id)
                continue
            spouses.append(f"{_display_name(output)} {_lifespan(output)}")
    return " & ".join(spouses) if spouses else _normalized_id(record.entity_id)


def _lifespan(record: OutputRecord) -> str:
    birth = _event_year_label_from_output(record, "BIRT")
    death = _event_year_label_from_output(record, "DEAT")
    return _compose_lifespan_label(birth, death)


def _event_year_label(record: EntityRecord, tag: str) -> str:
    for event in record.events:
        if event.tag == tag:
            year = _year_from_raw(event.date_raw)
            return "?" if year is None else str(year)
    return "?"


def _event_year_label_from_output(record: OutputRecord, tag: str) -> str:
    for event in record.events:
        if event.tag == tag and event.date is not None:
            year = _year_from_raw(event.date.encode("utf-8"))
            return "?" if year is None else str(year)
    return "?"


def _birth_year(record: EntityRecord) -> int | None:
    for event in record.events:
        if event.tag == "BIRT":
            return _exact_event_year(event)
    return None


def _exact_event_year(record_event: object) -> int | None:
    event = record_event
    parsed = getattr(event, "date", None)
    if parsed is None:
        return None
    year: int | None = parsed.year
    if year is None:
        return None
    if parsed.confidence not in {"exact", "month_only", "year_only", "dual_dating"}:
        return None
    return year


def _has_event(record: EntityRecord, tag: str) -> bool:
    return any(event.tag == tag for event in record.events)


def _normalized_id(entity_id: str | None) -> str:
    if entity_id is None:
        return ""
    return entity_id.strip("@")


def _values_as_tuple(value: object | None) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, list):
        return tuple(str(item) for item in value if item is not None)
    return (str(value),)
