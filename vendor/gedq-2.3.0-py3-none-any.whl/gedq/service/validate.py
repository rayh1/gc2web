"""Validation helpers for strict ingest and on-demand diagnostics."""

from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass
from datetime import date, timedelta
from pathlib import Path

from gedq.config import Settings
from gedq.errors import ErrorLocation, ParseDataError
from gedq.model.dates import (
    DateValue,
    earliest_possible_date,
    latest_possible_date,
    parse_date_value,
)
from gedq.model.entity_ids import normalize_entity_id
from gedq.model.events import EventRecord
from gedq.model.output import ValidationIssuePayload
from gedq.model.records import EntityRecord
from gedq.model.tags import PERSONAL_NAME_PIECE_TAGS, supports_event_tag
from gedq.parser.document import GedDocument, GedNode, parse_document
from gedq.parser.projection import (
    NOTE_REF_LABEL_PATTERN,
    NOTE_REF_PATTERN,
    Projection,
    project_document,
)


class ValidationIssue(ValidationIssuePayload):
    """One non-fatal validation finding returned by `gedq validate`."""

    def stable_signature(self) -> str:
        """Return the line-stable identity used for baseline diffing."""
        return json.dumps(
            {
                "code": self.code,
                "entity_id": self.entity_id,
                "message": self.message,
            },
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        )


_BASELINE_VERSION = 1


@dataclass(frozen=True)
class _DatedEventNode:
    tag: str
    text: str
    date_value: DateValue
    location: ErrorLocation | None


def load_strict_document(ged_path: Path) -> tuple[GedDocument, Projection]:
    """Load one GEDCOM file with the v1 strict parse-time checks applied."""
    document = parse_document(ged_path.read_bytes())
    require_strict_document(document)
    return document, project_document(document)


def require_strict_document(document: GedDocument) -> None:
    """Apply the v1 strict parse-time checks to an already-parsed document.

    Shared by `load_strict_document` (parses from disk, then checks) and the
    `plan_batch` fold in `gedq.service.write` (re-checks in-memory state
    evolved by prior ops-file lines). Every sequential single-edit
    invocation gets these checks for free at the top of `plan_edit` via
    `_load_guarded_state` -> `load_strict_document`; a batch must re-run
    them per fold step so a strict failure introduced by an earlier line is
    caught at the same point a subsequent single `gedq edit` invocation
    would catch it — instead of silently folding through invalid
    intermediate state.

    Args:
        document: The already-parsed document to check.

    Raises:
        ParseDataError: If the document fails a v1 strict check.
    """
    _require_supported_version(document)
    _require_valid_dates(document)


def validate_file(ged_path: Path) -> list[ValidationIssue]:
    """Run the on-demand GEDCOM validation sweep for one file."""
    document, projection = load_strict_document(ged_path)
    settings = Settings()
    issues: list[ValidationIssue] = []
    issues.extend(_collect_invalid_date_issues(document))
    issues.extend(_collect_duplicate_id_issues(document))
    issues.extend(_collect_blank_value_issues(document, tags={"DATE", "PLAC"}))
    issues.extend(_collect_missing_required_tag_issues(document, projection))
    issues.extend(_collect_dangling_reference_issues(document))
    issues.extend(_collect_asymmetric_family_link_issues(document))
    issues.extend(_collect_orphan_name_piece_issues(document))
    issues.extend(_collect_dangling_note_reference_issues(projection))
    issues.extend(_collect_duplicate_citation_issues(document))
    issues.extend(_collect_unsourced_event_issues(projection, settings))
    issues.extend(_collect_unsourced_name_issues(projection, settings))
    issues.extend(_collect_event_date_out_of_order_issues(document))
    issues.extend(_collect_implausible_relationship_issues(document))
    issues.extend(_collect_orphan_record_issues(document))
    issues.extend(_collect_sex_role_mismatch_issues(document, settings))
    issues.extend(_collect_cyclic_pedigree_issues(ged_path, projection))
    return issues


def filter_validation_issues(
    issues: list[ValidationIssue],
    *,
    entity_ids: tuple[str, ...] = (),
    codes: tuple[str, ...] = (),
) -> list[ValidationIssue]:
    """Filter validate findings by normalized entity IDs and issue codes."""
    normalized_entities = {
        normalize_entity_id(entity_id) for entity_id in entity_ids if entity_id.strip()
    }
    normalized_codes = {code.strip() for code in codes if code.strip()}
    return [
        issue
        for issue in issues
        if (not normalized_entities or issue.entity_id in normalized_entities)
        and (not normalized_codes or issue.code in normalized_codes)
    ]


def build_validation_baseline(issues: list[ValidationIssue]) -> Counter[str]:
    """Return signature counts for the current validate finding set."""
    return Counter(issue.stable_signature() for issue in issues)


def diff_validation_issues_against_baseline(
    issues: list[ValidationIssue], baseline: Counter[str]
) -> list[ValidationIssue]:
    """Return only findings whose stable signature count exceeds the baseline."""
    seen: Counter[str] = Counter()
    new_issues: list[ValidationIssue] = []
    for issue in issues:
        signature = issue.stable_signature()
        seen[signature] += 1
        if seen[signature] > baseline.get(signature, 0):
            new_issues.append(issue)
    return new_issues


def load_validation_baseline(path: Path) -> Counter[str]:
    """Load a stored validation baseline signature counter."""
    payload = json.loads(path.read_text(encoding="utf-8"))
    signatures = payload.get("signatures", {})
    if not isinstance(signatures, dict):
        raise ValueError("invalid validation baseline: signatures must be an object")
    return Counter({str(key): int(value) for key, value in signatures.items()})


def write_validation_baseline(path: Path, issues: list[ValidationIssue]) -> None:
    """Persist the current validate signature counter as the new baseline."""
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "version": _BASELINE_VERSION,
        "signatures": dict(sorted(build_validation_baseline(issues).items())),
    }
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def _require_supported_version(document: GedDocument) -> None:
    head = next((root for root in document.roots if root.tag == "HEAD"), None)
    if head is None:
        return

    gedc = next((child for child in head.children if child.tag == "GEDC"), None)
    if gedc is None:
        return

    version = next((child for child in gedc.children if child.tag == "VERS"), None)
    if version is None or version.value is None:
        return

    text = version.value.decode("utf-8")
    if text != "5.5.1":
        raise ParseDataError(
            f"unsupported GEDCOM version: {text}",
            location=_node_location(version),
        )


def _require_valid_dates(document: GedDocument) -> None:
    for node in _iter_document_nodes(document):
        if node.tag != "DATE" or node.value is None:
            continue
        text = node.value.decode("utf-8").strip()
        if not text:
            continue
        parsed = parse_date_value(node.value)
        if parsed is None or not parsed.syntax_valid:
            raise ParseDataError(
                f"unsupported GEDCOM date: {text}",
                location=_node_location(node),
            )


def _collect_blank_value_issues(document: GedDocument, *, tags: set[str]) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []

    for root in document.roots:
        owner_id = _normalize_id(root.xref) if root.xref is not None else None
        for child in root.children:
            if not supports_event_tag(root.tag, child.tag):
                continue
            for grandchild in child.children:
                if grandchild.tag not in tags or not _is_blank_value(grandchild.value):
                    continue
                issues.append(
                    ValidationIssue(
                        code="blank-value",
                        message=f"blank value: {owner_id} -> {child.tag} -> {grandchild.tag}",
                        location=_node_location(grandchild),
                        entity_id=owner_id,
                    )
                )

    return issues


def _collect_invalid_date_issues(document: GedDocument) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []

    for root in document.roots:
        owner_id = _normalize_id(root.xref) if root.xref is not None else None
        ancestors = () if owner_id is not None else (root.tag,)
        for child in root.children:
            _collect_node_invalid_date_issues(
                child,
                owner_id=owner_id,
                ancestors=ancestors,
                issues=issues,
            )

    return issues


def _collect_node_invalid_date_issues(
    node: GedNode,
    *,
    owner_id: str | None,
    ancestors: tuple[str, ...],
    issues: list[ValidationIssue],
) -> None:
    path = (*ancestors, node.tag)
    if node.tag == "DATE" and node.value is not None:
        text = node.value.decode("utf-8").strip()
        if text:
            parsed = parse_date_value(node.value)
            if parsed is not None and parsed.syntax_valid and not parsed.supported:
                path_text = " -> ".join(path)
                if owner_id is not None:
                    path_text = f"{owner_id} -> {path_text}"
                issues.append(
                    ValidationIssue(
                        code="invalid-date",
                        message=f"invalid date: {path_text} -> {text}",
                        location=_node_location(node),
                        entity_id=owner_id,
                    )
                )

    for child in node.children:
        _collect_node_invalid_date_issues(
            child,
            owner_id=owner_id,
            ancestors=path,
            issues=issues,
        )


def _collect_duplicate_id_issues(document: GedDocument) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    seen_ids: set[str] = set()

    for root in document.roots:
        if root.xref is None:
            continue
        normalized = _normalize_id(root.xref)
        if normalized not in seen_ids:
            seen_ids.add(normalized)
            continue
        issues.append(
            ValidationIssue(
                code="duplicate-id",
                message=f"duplicate id: {normalized}",
                location=_node_location(root),
                entity_id=normalized,
            )
        )

    return issues


def _collect_missing_required_tag_issues(
    document: GedDocument, projection: Projection
) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []

    head = next((root for root in document.roots if root.tag == "HEAD"), None)
    if head is None:
        issues.append(
            ValidationIssue(code="missing-required-tag", message="missing required tag: HEAD")
        )
    else:
        gedc = next((child for child in head.children if child.tag == "GEDC"), None)
        if gedc is None:
            issues.append(
                ValidationIssue(
                    code="missing-required-tag",
                    message="missing required tag: HEAD -> GEDC",
                    location=_node_location(head),
                )
            )
        elif next((child for child in gedc.children if child.tag == "VERS"), None) is None:
            issues.append(
                ValidationIssue(
                    code="missing-required-tag",
                    message="missing required tag: HEAD -> GEDC -> VERS",
                    location=_node_location(gedc),
                )
            )

    for record in projection.records:
        if record.kind != "INDI" or record.entity_id is None:
            continue
        if any(field.tag == "NAME" for field in record.fields):
            continue
        issues.append(
            ValidationIssue(
                code="missing-required-tag",
                message=f"missing required tag: {record.entity_id} -> NAME",
                entity_id=record.entity_id.strip("@"),
                location=_line_location(record.root_line_indexes),
            )
        )

    return issues


def _collect_dangling_reference_issues(document: GedDocument) -> list[ValidationIssue]:
    known_ids = {_normalize_id(root.xref) for root in document.roots if root.xref is not None}
    issues: list[ValidationIssue] = []

    for root in document.roots:
        if root.xref is None:
            continue
        owner_id = _normalize_id(root.xref)
        for child in root.children:
            _collect_node_dangling_reference_issues(
                child,
                owner_id=owner_id,
                known_ids=known_ids,
                ancestors=(),
                issues=issues,
            )

    return issues


def _collect_asymmetric_family_link_issues(document: GedDocument) -> list[ValidationIssue]:
    indi_roots = {
        _normalize_id(root.xref): root
        for root in document.roots
        if root.tag == "INDI" and root.xref is not None
    }
    fam_roots = {
        _normalize_id(root.xref): root
        for root in document.roots
        if root.tag == "FAM" and root.xref is not None
    }
    issues: list[ValidationIssue] = []
    seen_indi_side: set[tuple[str, str, str]] = set()
    seen_fam_side: set[tuple[str, str, str]] = set()

    for indi_id, indi_root in indi_roots.items():
        for family_id, node in _reference_children(indi_root, {"FAMS"}):
            if family_id not in fam_roots:
                continue
            key = (indi_id, family_id, node.tag)
            if key in seen_indi_side:
                continue
            seen_indi_side.add(key)
            if indi_id in _reference_ids(fam_roots[family_id], {"HUSB", "WIFE"}):
                continue
            issues.append(
                ValidationIssue(
                    code="asymmetric-family-link",
                    message=(
                        f"asymmetric link: {indi_id} -> {node.tag} @{family_id}@ "
                        f"but {family_id} has no HUSB/WIFE @{indi_id}@"
                    ),
                    entity_id=indi_id,
                    location=_node_location(node),
                )
            )

        for family_id, node in _reference_children(indi_root, {"FAMC"}):
            if family_id not in fam_roots:
                continue
            key = (indi_id, family_id, node.tag)
            if key in seen_indi_side:
                continue
            seen_indi_side.add(key)
            if indi_id in _reference_ids(fam_roots[family_id], {"CHIL"}):
                continue
            issues.append(
                ValidationIssue(
                    code="asymmetric-family-link",
                    message=(
                        f"asymmetric link: {indi_id} -> {node.tag} @{family_id}@ "
                        f"but {family_id} has no CHIL @{indi_id}@"
                    ),
                    entity_id=indi_id,
                    location=_node_location(node),
                )
            )

    for family_id, fam_root in fam_roots.items():
        for indi_id, node in _reference_children(fam_root, {"HUSB", "WIFE"}):
            if indi_id not in indi_roots:
                continue
            key = (family_id, indi_id, node.tag)
            if key in seen_fam_side:
                continue
            seen_fam_side.add(key)
            if family_id in _reference_ids(indi_roots[indi_id], {"FAMS"}):
                continue
            issues.append(
                ValidationIssue(
                    code="asymmetric-family-link",
                    message=(
                        f"asymmetric link: {family_id} -> {node.tag} @{indi_id}@ "
                        f"but {indi_id} has no FAMS @{family_id}@"
                    ),
                    entity_id=family_id,
                    location=_node_location(node),
                )
            )

        for indi_id, node in _reference_children(fam_root, {"CHIL"}):
            if indi_id not in indi_roots:
                continue
            key = (family_id, indi_id, node.tag)
            if key in seen_fam_side:
                continue
            seen_fam_side.add(key)
            if family_id in _reference_ids(indi_roots[indi_id], {"FAMC"}):
                continue
            issues.append(
                ValidationIssue(
                    code="asymmetric-family-link",
                    message=(
                        f"asymmetric link: {family_id} -> {node.tag} @{indi_id}@ "
                        f"but {indi_id} has no FAMC @{family_id}@"
                    ),
                    entity_id=family_id,
                    location=_node_location(node),
                )
            )

    return issues


def _collect_orphan_name_piece_issues(document: GedDocument) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []

    for root in document.roots:
        if root.tag != "INDI" or root.xref is None:
            continue
        owner_id = _normalize_id(root.xref)
        for child in root.children:
            if child.tag not in PERSONAL_NAME_PIECE_TAGS:
                continue
            issues.append(
                ValidationIssue(
                    code="orphan-name-piece",
                    message=f"orphan name piece: {owner_id} -> {child.tag}",
                    entity_id=owner_id,
                    location=_node_location(child),
                )
            )

    return issues


def _collect_node_dangling_reference_issues(
    node: GedNode,
    *,
    owner_id: str,
    known_ids: set[str],
    ancestors: tuple[str, ...],
    issues: list[ValidationIssue],
) -> None:
    path = (*ancestors, node.tag)
    reference = _reference_value(node.value)
    if reference is not None and reference not in known_ids:
        issues.append(
            ValidationIssue(
                code="dangling-reference",
                message=f"dangling ref: {owner_id} -> {'.'.join(path)} -> {reference}",
                entity_id=owner_id,
                location=_node_location(node),
            )
        )

    for child in node.children:
        _collect_node_dangling_reference_issues(
            child,
            owner_id=owner_id,
            known_ids=known_ids,
            ancestors=path,
            issues=issues,
        )


def _collect_cyclic_pedigree_issues(
    ged_path: Path, projection: Projection
) -> list[ValidationIssue]:
    from gedq.query.relations import trace_ancestors
    from gedq.storage.ladybug_index import GraphIndexService

    issues: list[ValidationIssue] = []
    seen_messages: set[str] = set()
    handle = GraphIndexService().open_for_query(ged_path)

    for record in projection.records:
        if record.kind != "INDI" or record.entity_id is None:
            continue
        traversal = trace_ancestors(handle, record.entity_id)
        if traversal.cycle_notice is None or traversal.cycle_notice in seen_messages:
            continue
        seen_messages.add(traversal.cycle_notice)
        issues.append(
            ValidationIssue(
                code="cyclic-pedigree",
                message=traversal.cycle_notice,
                entity_id=_normalize_id(record.entity_id),
                location=_line_location(record.root_line_indexes),
            )
        )

    return issues


def _collect_dangling_note_reference_issues(projection: Projection) -> list[ValidationIssue]:
    known_ids = {record.entity_id for record in projection.records if record.entity_id is not None}
    issues: list[ValidationIssue] = []
    seen: set[tuple[str, str, str]] = set()

    for record in projection.records:
        if record.entity_id is None:
            continue
        owner_id = _normalize_id(record.entity_id)
        for event in record.events:
            for note_value, note_line_indexes in zip(
                event.notes,
                event.note_line_indexes,
                strict=False,
            ):
                for note_ref in _extract_note_references(note_value):
                    if note_ref in known_ids:
                        continue
                    normalized_ref = _normalize_id(note_ref)
                    key = (owner_id, event.tag, normalized_ref)
                    if key in seen:
                        continue
                    seen.add(key)
                    issues.append(
                        ValidationIssue(
                            code="unresolved-note-ref",
                            message=(
                                f"dangling ref: {owner_id} -> {event.tag}.NOTE -> {normalized_ref}"
                            ),
                            entity_id=owner_id,
                            location=_line_location(note_line_indexes),
                        )
                    )

    return issues


def _extract_note_references(value: bytes) -> tuple[str, ...]:
    seen: set[str] = set()
    ordered: list[str] = []

    def add(reference: str) -> None:
        if reference in seen:
            return
        seen.add(reference)
        ordered.append(reference)

    text = value.decode("utf-8")
    for reference in NOTE_REF_PATTERN.findall(text):
        add(reference)
    for identifier in NOTE_REF_LABEL_PATTERN.findall(text):
        add(f"@{identifier}@")
    return tuple(ordered)


def _collect_duplicate_citation_issues(document: GedDocument) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []

    for root in document.roots:
        if root.xref is None:
            continue
        _collect_duplicate_citations_for_node(
            root,
            owner_id=_normalize_id(root.xref),
            path=(),
            issues=issues,
        )

    return issues


def _collect_unsourced_event_issues(
    projection: Projection, settings: Settings
) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []

    for record in projection.records:
        if record.entity_id is None:
            continue
        owner_id = _normalize_id(record.entity_id)
        record_source_ids = _record_source_ids(record)
        for event in record.events:
            if not _is_substantive_event(event):
                continue
            if not _include_unsourced_event_tag(event.tag, settings):
                continue
            if event.source_ids:
                continue
            if settings.validate_unsourced_lenient_record_fallback and record_source_ids:
                continue
            issues.append(
                ValidationIssue(
                    code="unsourced-event",
                    message=(
                        f"unsourced event: {owner_id} -> {event.tag}{_event_detail_suffix(event)} "
                        f"(no SOUR)"
                    ),
                    entity_id=owner_id,
                    location=_line_location(event.line_indexes),
                )
            )

    return issues


def _collect_unsourced_name_issues(
    projection: Projection, settings: Settings
) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []

    for record in projection.records:
        if record.kind != "INDI" or record.entity_id is None:
            continue
        owner_id = _normalize_id(record.entity_id)
        record_source_ids = _record_source_ids(record)
        for field in record.fields:
            if field.tag != "NAME" or field.value is None:
                continue
            raw_name = field.value.decode("utf-8")
            if _is_placeholder_name(raw_name, settings):
                continue
            if field.source_ids:
                continue
            if settings.validate_unsourced_lenient_record_fallback and record_source_ids:
                continue
            issues.append(
                ValidationIssue(
                    code="unsourced-name",
                    message=f'unsourced name: {owner_id} -> NAME "{raw_name}" (no name-level SOUR)',
                    entity_id=owner_id,
                    location=_line_location(field.line_indexes),
                )
            )

    return issues


def _collect_event_date_out_of_order_issues(document: GedDocument) -> list[ValidationIssue]:
    family_roots = {
        _normalize_id(root.xref): root
        for root in document.roots
        if root.tag == "FAM" and root.xref is not None
    }
    issues: list[ValidationIssue] = []

    for root in document.roots:
        if root.tag != "INDI" or root.xref is None:
            continue
        owner_id = _normalize_id(root.xref)
        births = _dated_event_nodes(root, {"BIRT"})
        baptisms = _dated_event_nodes(root, {"BAPM", "CHR"})
        deaths = _dated_event_nodes(root, {"DEAT"})
        burials = _dated_event_nodes(root, {"BURI", "CREM"})
        marriages: list[_DatedEventNode] = []
        for family_id, _ in _reference_children(root, {"FAMS"}):
            family_root = family_roots.get(family_id)
            if family_root is None:
                continue
            marriages.extend(_dated_event_nodes(family_root, {"MARR"}))

        _append_out_of_order_issues(owner_id, births, baptisms, issues)
        _append_out_of_order_issues(owner_id, births, marriages, issues)
        _append_out_of_order_issues(owner_id, births, deaths, issues)
        _append_out_of_order_issues(owner_id, births, burials, issues)
        _append_out_of_order_issues(owner_id, baptisms, marriages, issues)
        _append_out_of_order_issues(owner_id, baptisms, deaths, issues)
        _append_out_of_order_issues(owner_id, baptisms, burials, issues)
        _append_out_of_order_issues(owner_id, marriages, deaths, issues)
        _append_out_of_order_issues(owner_id, marriages, burials, issues)
        _append_out_of_order_issues(owner_id, deaths, burials, issues)

    return issues


def _dated_event_nodes(root: GedNode, tags: set[str]) -> list[_DatedEventNode]:
    events: list[_DatedEventNode] = []
    for child in root.children:
        if child.tag not in tags:
            continue
        date_node = next(
            (grandchild for grandchild in child.children if grandchild.tag == "DATE"),
            None,
        )
        if date_node is None or date_node.value is None:
            continue
        text = date_node.value.decode("utf-8").strip()
        if not text:
            continue
        parsed = parse_date_value(date_node.value)
        if parsed is None:
            continue
        events.append(
            _DatedEventNode(
                tag=child.tag,
                text=text,
                date_value=parsed,
                location=_node_location(date_node),
            )
        )
    return events


def _append_out_of_order_issues(
    owner_id: str,
    expected_earlier: list[_DatedEventNode],
    expected_later: list[_DatedEventNode],
    issues: list[ValidationIssue],
) -> None:
    for earlier in expected_earlier:
        earlier_earliest = earliest_possible_date(earlier.date_value)
        if earlier_earliest is None:
            continue
        for later in expected_later:
            later_latest = latest_possible_date(later.date_value)
            if later_latest is None or later_latest >= earlier_earliest:
                continue
            issues.append(
                ValidationIssue(
                    code="event-date-out-of-order",
                    message=(
                        f"event order: {owner_id} {later.tag} {later.text} precedes "
                        f"{earlier.tag} {earlier.text}"
                    ),
                    entity_id=owner_id,
                    location=later.location,
                )
            )


def _collect_implausible_relationship_issues(document: GedDocument) -> list[ValidationIssue]:
    indi_roots = {
        _normalize_id(root.xref): root
        for root in document.roots
        if root.tag == "INDI" and root.xref is not None
    }
    family_roots = {
        _normalize_id(root.xref): root
        for root in document.roots
        if root.tag == "FAM" and root.xref is not None
    }
    issues: list[ValidationIssue] = []

    for indi_id, indi_root in indi_roots.items():
        birth = _first_dated_event_node(indi_root, {"BIRT"})
        death = _first_dated_event_node(indi_root, {"DEAT"})
        if birth is not None and death is not None:
            min_lifespan = _min_year_gap(birth.date_value, death.date_value)
            if min_lifespan is not None and min_lifespan > 120:
                message = f"implausible: {indi_id} lifespan {min_lifespan}y exceeds 120y threshold"
                issues.append(
                    ValidationIssue(
                        code="implausible-relationship",
                        message=message,
                        entity_id=indi_id,
                        location=death.location,
                    )
                )

    for family_id, family_root in family_roots.items():
        marriage = _first_dated_event_node(family_root, {"MARR"})
        husband_id = _first_reference_id(family_root, {"HUSB"})
        wife_id = _first_reference_id(family_root, {"WIFE"})

        if marriage is not None and husband_id in indi_roots:
            husband_birth = _first_dated_event_node(indi_roots[husband_id], {"BIRT"})
            max_age = (
                _max_year_gap(husband_birth.date_value, marriage.date_value)
                if husband_birth
                else None
            )
            if max_age is not None and max_age < 12:
                issues.append(
                    ValidationIssue(
                        code="implausible-relationship",
                        message=(f"implausible: {husband_id} married at {max_age}y in {family_id}"),
                        entity_id=husband_id,
                        location=marriage.location,
                    )
                )

        if marriage is not None and wife_id in indi_roots:
            wife_birth = _first_dated_event_node(indi_roots[wife_id], {"BIRT"})
            max_age = (
                _max_year_gap(wife_birth.date_value, marriage.date_value) if wife_birth else None
            )
            if max_age is not None and max_age < 12:
                issues.append(
                    ValidationIssue(
                        code="implausible-relationship",
                        message=f"implausible: {wife_id} married at {max_age}y in {family_id}",
                        entity_id=wife_id,
                        location=marriage.location,
                    )
                )

        father_birth = (
            _first_dated_event_node(indi_roots[husband_id], {"BIRT"})
            if husband_id in indi_roots
            else None
        )
        father_death = (
            _first_dated_event_node(indi_roots[husband_id], {"DEAT"})
            if husband_id in indi_roots
            else None
        )
        mother_birth = (
            _first_dated_event_node(indi_roots[wife_id], {"BIRT"})
            if wife_id in indi_roots
            else None
        )
        mother_death = (
            _first_dated_event_node(indi_roots[wife_id], {"DEAT"})
            if wife_id in indi_roots
            else None
        )

        for child_id, _ in _reference_children(family_root, {"CHIL"}):
            child_root = indi_roots.get(child_id)
            if child_root is None:
                continue
            child_birth = _first_dated_event_node(child_root, {"BIRT"})
            if child_birth is None:
                continue

            _append_parent_birth_order_issue(
                child_id,
                child_birth,
                parent_id=husband_id,
                parent_birth=father_birth,
                parent_role="father",
                issues=issues,
            )
            _append_parent_birth_order_issue(
                child_id,
                child_birth,
                parent_id=wife_id,
                parent_birth=mother_birth,
                parent_role="mother",
                issues=issues,
            )
            _append_posthumous_issue(
                child_id,
                child_birth,
                parent_id=husband_id,
                parent_death=father_death,
                parent_role="father",
                allowed_gap=timedelta(days=365),
                issues=issues,
            )
            _append_posthumous_issue(
                child_id,
                child_birth,
                parent_id=wife_id,
                parent_death=mother_death,
                parent_role="mother",
                allowed_gap=timedelta(0),
                issues=issues,
            )
            _append_parent_age_issue(
                child_id,
                child_birth,
                parent_id=husband_id,
                parent_birth=father_birth,
                parent_role="father",
                min_years=12,
                max_years=None,
                issues=issues,
            )
            _append_parent_age_issue(
                child_id,
                child_birth,
                parent_id=wife_id,
                parent_birth=mother_birth,
                parent_role="mother",
                min_years=12,
                max_years=55,
                issues=issues,
            )

    return issues


def _collect_orphan_record_issues(document: GedDocument) -> list[ValidationIssue]:
    incoming = Counter[str]()
    tracked_roots = {
        _normalize_id(root.xref): root
        for root in document.roots
        if root.xref is not None and root.tag in {"INDI", "FAM", "SOUR", "OBJE", "REPO", "NOTE"}
    }
    for root in document.roots:
        for node in _iter_child_nodes(root):
            reference = _reference_value(node.value)
            if reference is not None and reference in tracked_roots:
                incoming[reference] += 1

    single_tracked_record = len(tracked_roots) == 1
    issues: list[ValidationIssue] = []
    for root_id, root in tracked_roots.items():
        if root.tag in {"SOUR", "OBJE", "REPO", "NOTE"}:
            if incoming.get(root_id, 0) == 0:
                issues.append(
                    ValidationIssue(
                        code="orphan-record",
                        message=f"orphan record: {root_id} ({root.tag}) is referenced by no record",
                        entity_id=root_id,
                        location=_node_location(root),
                    )
                )
            continue

        if root.tag == "INDI":
            has_family_link = bool(_reference_children(root, {"FAMC", "FAMS"}))
        else:
            has_family_link = bool(_reference_children(root, {"HUSB", "WIFE", "CHIL"}))
        if single_tracked_record or has_family_link or incoming.get(root_id, 0) > 0:
            continue
        issues.append(
            ValidationIssue(
                code="orphan-record",
                message=f"orphan record: {root_id} ({root.tag}) is fully disconnected",
                entity_id=root_id,
                location=_node_location(root),
            )
        )

    return issues


def _collect_sex_role_mismatch_issues(
    document: GedDocument, settings: Settings
) -> list[ValidationIssue]:
    indi_roots = {
        _normalize_id(root.xref): root
        for root in document.roots
        if root.tag == "INDI" and root.xref is not None
    }
    family_roots = {
        _normalize_id(root.xref): root
        for root in document.roots
        if root.tag == "FAM" and root.xref is not None
    }
    issues: list[ValidationIssue] = []
    roles_by_person: dict[str, list[tuple[str, str, GedNode]]] = {}

    for family_id, family_root in family_roots.items():
        for role_tag in ("HUSB", "WIFE"):
            for person_id, node in _reference_children(family_root, {role_tag}):
                roles_by_person.setdefault(person_id, []).append((family_id, role_tag, node))
                if not settings.validate_sex_role_check_enabled:
                    continue
                sex = _first_child_text(indi_roots.get(person_id), "SEX")
                if sex not in {"M", "F"}:
                    continue
                if (role_tag == "HUSB" and sex == "F") or (role_tag == "WIFE" and sex == "M"):
                    issues.append(
                        ValidationIssue(
                            code="sex-role-mismatch",
                            message=(
                                f"sex/role: {family_id} {role_tag} @{person_id}@ "
                                f"but {person_id} SEX is {sex}"
                            ),
                            entity_id=family_id,
                            location=_node_location(node),
                        )
                    )

    for person_id, roles in roles_by_person.items():
        role_names = {role for _, role, _ in roles}
        if role_names != {"HUSB", "WIFE"}:
            continue
        family_id, role_tag, node = roles[-1]
        other_family_id = next(fam for fam, role, _ in roles if role != role_tag)
        issues.append(
            ValidationIssue(
                code="sex-role-mismatch",
                message=(
                    f"sex/role: {person_id} is {role_tag} in {family_id} and "
                    f"{('HUSB' if role_tag == 'WIFE' else 'WIFE')} in {other_family_id}"
                ),
                entity_id=person_id,
                location=_node_location(node),
            )
        )

    return issues


def _first_dated_event_node(root: GedNode, tags: set[str]) -> _DatedEventNode | None:
    events = _dated_event_nodes(root, tags)
    return events[0] if events else None


def _first_reference_id(root: GedNode, tags: set[str]) -> str | None:
    references = _reference_children(root, tags)
    return references[0][0] if references else None


def _first_child_text(root: GedNode | None, tag: str) -> str | None:
    if root is None:
        return None
    for child in root.children:
        if child.tag == tag and child.value is not None:
            return child.value.decode("utf-8").strip().upper()
    return None


def _append_parent_birth_order_issue(
    child_id: str,
    child_birth: _DatedEventNode,
    *,
    parent_id: str | None,
    parent_birth: _DatedEventNode | None,
    parent_role: str,
    issues: list[ValidationIssue],
) -> None:
    if parent_id is None or parent_birth is None:
        return
    parent_earliest = earliest_possible_date(parent_birth.date_value)
    child_latest = latest_possible_date(child_birth.date_value)
    if parent_earliest is None or child_latest is None or child_latest >= parent_earliest:
        return
    issues.append(
        ValidationIssue(
            code="implausible-relationship",
            message=(
                f"impossible: {child_id} born {child_birth.text} but {parent_role} {parent_id} "
                f"was born {parent_birth.text}"
            ),
            entity_id=child_id,
            location=child_birth.location,
        )
    )


def _append_posthumous_issue(
    child_id: str,
    child_birth: _DatedEventNode,
    *,
    parent_id: str | None,
    parent_death: _DatedEventNode | None,
    parent_role: str,
    allowed_gap: timedelta,
    issues: list[ValidationIssue],
) -> None:
    if parent_id is None or parent_death is None:
        return
    child_earliest = earliest_possible_date(child_birth.date_value)
    parent_latest_death = latest_possible_date(parent_death.date_value)
    if child_earliest is None or parent_latest_death is None:
        return
    threshold = parent_latest_death + allowed_gap
    if child_earliest <= threshold:
        return
    gap_years = max(0, (child_earliest - parent_latest_death).days // 365)
    issues.append(
        ValidationIssue(
            code="implausible-relationship",
            message=(
                f"impossible: {child_id} born {child_birth.text} but {parent_role} {parent_id} "
                f"died {parent_death.text} ({gap_years}y posthumous)"
            ),
            entity_id=child_id,
            location=child_birth.location,
        )
    )


def _append_parent_age_issue(
    child_id: str,
    child_birth: _DatedEventNode,
    *,
    parent_id: str | None,
    parent_birth: _DatedEventNode | None,
    parent_role: str,
    min_years: int,
    max_years: int | None,
    issues: list[ValidationIssue],
) -> None:
    if parent_id is None or parent_birth is None:
        return
    max_age = _max_year_gap(parent_birth.date_value, child_birth.date_value)
    if max_age is not None and max_age < min_years:
        issues.append(
            ValidationIssue(
                code="implausible-relationship",
                message=(
                    f"implausible: {child_id} {parent_role} {parent_id} was {max_age}y at birth"
                ),
                entity_id=child_id,
                location=child_birth.location,
            )
        )
        return
    if max_years is None:
        return
    min_age = _min_year_gap(parent_birth.date_value, child_birth.date_value)
    if min_age is None or min_age <= max_years:
        return
    issues.append(
        ValidationIssue(
            code="implausible-relationship",
            message=(f"implausible: {child_id} {parent_role} {parent_id} was {min_age}y at birth"),
            entity_id=child_id,
            location=child_birth.location,
        )
    )


def _max_year_gap(start: DateValue, end: DateValue) -> int | None:
    start_earliest = earliest_possible_date(start)
    end_latest = latest_possible_date(end)
    if start_earliest is None or end_latest is None:
        return None
    return _whole_years_between(start_earliest, end_latest)


def _min_year_gap(start: DateValue, end: DateValue) -> int | None:
    start_latest = latest_possible_date(start)
    end_earliest = earliest_possible_date(end)
    if start_latest is None or end_earliest is None:
        return None
    return _whole_years_between(start_latest, end_earliest)


def _whole_years_between(start: date, end: date) -> int:
    years = end.year - start.year
    if (end.month, end.day) < (start.month, start.day):
        years -= 1
    return years


def _collect_duplicate_citations_for_node(
    node: GedNode,
    *,
    owner_id: str,
    path: tuple[str, ...],
    issues: list[ValidationIssue],
) -> None:
    seen_sources: set[str] = set()

    for child in node.children:
        if child.tag != "SOUR":
            continue
        source_id = _reference_value(child.value)
        if source_id is None:
            continue
        if source_id in seen_sources:
            path_text = f"{owner_id} -> {' -> '.join(path)} -> " if path else f"{owner_id} -> "
            issues.append(
                ValidationIssue(
                    code="duplicate-citation",
                    message=f"duplicate citation: {path_text}SOUR @{source_id}@",
                    entity_id=owner_id,
                    location=_node_location(child),
                )
            )
            continue
        seen_sources.add(source_id)

    for child in node.children:
        if child.tag == "SOUR":
            continue
        next_path = (*path, child.tag) if node.xref is not None or path else (*path, child.tag)
        _collect_duplicate_citations_for_node(
            child,
            owner_id=owner_id,
            path=next_path,
            issues=issues,
        )


def _iter_document_nodes(document: GedDocument) -> list[GedNode]:
    nodes: list[GedNode] = []
    for root in document.roots:
        nodes.append(root)
        nodes.extend(_iter_child_nodes(root))
    return nodes


def _iter_child_nodes(node: GedNode) -> list[GedNode]:
    nodes: list[GedNode] = []
    for child in node.children:
        nodes.append(child)
        nodes.extend(_iter_child_nodes(child))
    return nodes


def _is_blank_value(value: bytes | None) -> bool:
    return value is None or not value.decode("utf-8").strip()


def _record_source_ids(record: EntityRecord) -> set[str]:
    return {
        reference
        for field in record.fields
        if field.tag == "SOUR"
        for reference in field.references
    }


def _is_substantive_event(event: EventRecord) -> bool:
    return any(
        value is not None and value.decode("utf-8").strip()
        for value in (event.value, event.date_raw, event.place)
    )


def _include_unsourced_event_tag(tag: str, settings: Settings) -> bool:
    included = {value.upper() for value in settings.validate_unsourced_event_tags}
    excluded = {value.upper() for value in settings.validate_unsourced_event_exclude_tags}
    tag_upper = tag.upper()
    if included and tag_upper not in included:
        return False
    return tag_upper not in excluded


def _is_placeholder_name(name: str, settings: Settings) -> bool:
    return any(
        re.search(pattern, name, flags=re.IGNORECASE)
        for pattern in settings.validate_unsourced_name_placeholder_patterns
    )


def _event_detail_suffix(event: EventRecord) -> str:
    for value in (event.value, event.date_raw, event.place):
        if value is None:
            continue
        text = value.decode("utf-8").strip()
        if text:
            return f" {text}"
    return ""


def _reference_children(node: GedNode, tags: set[str]) -> list[tuple[str, GedNode]]:
    references: list[tuple[str, GedNode]] = []
    for child in node.children:
        if child.tag not in tags:
            continue
        reference = _reference_value(child.value)
        if reference is None:
            continue
        references.append((reference, child))
    return references


def _reference_ids(node: GedNode, tags: set[str]) -> set[str]:
    return {reference for reference, _ in _reference_children(node, tags)}


def _reference_value(value: bytes | None) -> str | None:
    if value is None:
        return None
    text = value.decode("utf-8").strip()
    if text.startswith("@") and text.endswith("@") and len(text) >= 3:
        return text.strip("@")
    return None


def _node_location(node: GedNode) -> ErrorLocation | None:
    return _line_location(node.line_indexes)


def _line_location(line_indexes: tuple[int, ...]) -> ErrorLocation | None:
    if not line_indexes:
        return None
    return ErrorLocation(line=min(line_indexes) + 1, column=1)


def _normalize_id(entity_id: str | None) -> str:
    return "" if entity_id is None else entity_id.strip("@")
