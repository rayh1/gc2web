"""Read/query service helpers for gedq."""

from __future__ import annotations

import re
from collections.abc import Sequence
from datetime import date
from pathlib import Path
from typing import Any, NamedTuple

from gedq.errors import UserError
from gedq.model.dates import (
    ComputedDateField,
    DateValue,
    exact_year_difference,
    fallback_difference,
    parse_date_value,
    supports_exact_arithmetic,
)
from gedq.model.entity_ids import canonical_entity_xref, normalize_entity_id
from gedq.model.events import EventRecord
from gedq.model.output import (
    CommonAncestorPath,
    CousinDistancePath,
    LookupPayload,
    OutputAssociation,
    OutputCitationEventNotes,
    OutputCitationFact,
    OutputEvent,
    OutputFieldSourceMap,
    OutputNameOccurrence,
    OutputNoteSourceRef,
    OutputRecord,
    OutputSourceRef,
    TraversalEdge,
    TraversalElement,
    TraversalPerson,
    TraversalRole,
    serialize_output_event_payload,
)
from gedq.model.output_keys import (
    EVENT_VALUE_SOURCE_TAG,
    event_outward_json_key,
    record_outward_json_key,
)
from gedq.model.records import EntityRecord
from gedq.parser.projection import Projection
from gedq.query.properties import build_record_raw_fields
from gedq.query.raw import execute_raw_query
from gedq.query.relations import (
    LineageTraversal,
    TraversalNode,
    get_ancestor_nodes,
    get_ancestors,
    get_common_ancestor,
    get_cousin_distance,
    get_cousin_path_nodes,
    get_cousin_relationship,
    get_descendant_nodes,
    get_descendants,
    get_shortest_path,
    get_shortest_path_nodes,
    get_sibling_nodes,
    get_siblings,
    trace_ancestors,
    trace_descendants,
)
from gedq.query.search import search_entities
from gedq.service.validate import load_strict_document
from gedq.storage.ladybug_index import QueryHandle

_POINT_IN_TIME_EVENT_TAGS = {"BIRT", "DEAT", "MARR", "DIV", "MARB"}
_FAMILY_REPRESENTATIVE_EVENT_TAGS = ("MARR", "MARB", "MARL", "MARC")
_LOOKUP_KIND_LABELS = {"INDI": "person", "FAM": "family", "SOUR": "source"}
_SOURCE_CITES_EXPAND_TAG = "CITES"
_OUTWARD_ASSOCIATIONS_KEY = record_outward_json_key("ASSO") or "associations"
_OUTWARD_NICKNAME_KEY = record_outward_json_key("NICK") or "nickname"
_OUTWARD_MEDIA_PATH_KEY = record_outward_json_key("FILE") or "media_path"
_OUTWARD_MEDIA_REFS_KEY = record_outward_json_key("OBJE") or "media_refs"
_OUTWARD_SOURCE_TEXT_KEY = record_outward_json_key("TEXT") or "source_text"
_OUTWARD_TITLE_KEY = record_outward_json_key("TITL") or "title"
_OUTWARD_PUBLICATION_KEY = record_outward_json_key("PUBL") or "publication"
_OUTWARD_REPOSITORY_REF_KEY = record_outward_json_key("REPO") or "repository_ref"
_OUTWARD_EVENT_ASSOCIATIONS_KEY = event_outward_json_key("ASSO") or "associations"
_OUTWARD_EVENT_CAUSE_KEY = event_outward_json_key("CAUS") or "cause"
_OUTWARD_EVENT_SOURCE_IDS_KEY = event_outward_json_key("SOUR") or "source_ids"
_OUTWARD_EVENT_VALUE_KEY = event_outward_json_key(EVENT_VALUE_SOURCE_TAG) or "value"
_NOTE_REF_PATTERN = re.compile(r"@(?:I|F|S)[A-Za-z0-9:_-]+@")
_NOTE_REF_LABEL_PATTERN = re.compile(r"\bxref_id\s*:\s*@?([IFS][A-Za-z0-9:_-]+)@?", re.I)


def lookup_entity(
    handle: QueryHandle,
    entity_id: str,
    *,
    expected_kind: str | None = None,
    with_src: bool = False,
    projection: Projection | None = None,
) -> OutputRecord | None:
    """Look up one projected entity by GEDCOM identifier.

    Args:
        handle: The derived index handle.
        entity_id: The GEDCOM identifier to resolve.
        expected_kind: Optional GEDCOM entity kind required by the caller.
        with_src: Whether to retain line/file provenance on the returned record.
        projection: Optional pre-loaded semantic projection for repeated lookups.

    Returns:
        The typed output record, if present.
    """
    effective_projection = _load_projection(handle) if projection is None else projection
    record = effective_projection.get_record(_canonical_entity_id(entity_id))
    if record is None:
        return None
    if expected_kind is not None:
        normalized_kind = expected_kind.strip().upper()
        if record.kind != normalized_kind:
            label = _LOOKUP_KIND_LABELS.get(normalized_kind, normalized_kind)
            raise UserError(f"{entity_id} is not a {label}")
    output = _build_output_record(handle.source_path, record, effective_projection)
    return output if with_src else output.without_provenance()


def lookup_entity_or_error(
    handle: QueryHandle,
    entity_id: str,
    *,
    expected_kind: str | None = None,
    with_src: bool = False,
    projection: Projection | None = None,
) -> OutputRecord:
    """Look up one entity and raise the shared not-found error when unresolved."""
    record = lookup_entity(
        handle,
        entity_id,
        expected_kind=expected_kind,
        with_src=with_src,
        projection=projection,
    )
    if record is None:
        raise UserError(f"entity not found: {_normalize_id(entity_id)}")
    return record


def lookup_entity_payload(
    handle: QueryHandle,
    entity_id: str,
    expand: str | Sequence[str] | None = None,
    *,
    expand_all: bool = False,
    expected_kind: str | None = None,
    with_src: bool = False,
    projection: Projection | None = None,
) -> LookupPayload | None:
    """Return a lookup payload with optional inline expansion.

    Args:
        handle: The derived index handle.
        entity_id: The GEDCOM identifier to resolve.
        expand: Optional raw field name to expand inline.
        expand_all: Whether to expand every expandable field one level deep.
        expected_kind: Optional GEDCOM entity kind required by the caller.
        with_src: Whether to retain line/file provenance on the returned payload.
        projection: Optional pre-loaded semantic projection for repeated lookups.

    Returns:
        The lookup payload for rendering, if present.
    """
    effective_projection = _load_projection(handle) if projection is None else projection
    record = lookup_entity(
        handle,
        entity_id,
        expected_kind=expected_kind,
        with_src=with_src,
        projection=effective_projection,
    )
    if record is None:
        return None

    if expand is None and not expand_all:
        return LookupPayload.from_record(record)

    return LookupPayload.from_record(
        record,
        expanded_fields=_expanded_fields_for_record(
            handle,
            record,
            expand=expand,
            expand_all=expand_all,
            projection=effective_projection,
        ),
    )


def lookup_entity_payload_or_error(
    handle: QueryHandle,
    entity_id: str,
    expand: str | Sequence[str] | None = None,
    *,
    expand_all: bool = False,
    expected_kind: str | None = None,
    with_src: bool = False,
    projection: Projection | None = None,
) -> LookupPayload:
    """Return one lookup payload or raise the shared not-found error."""
    payload = lookup_entity_payload(
        handle,
        entity_id,
        expand,
        expand_all=expand_all,
        expected_kind=expected_kind,
        with_src=with_src,
        projection=projection,
    )
    if payload is None:
        raise UserError(f"entity not found: {_normalize_id(entity_id)}")
    return payload


def descendants(handle: QueryHandle, entity_id: str, depth: int | None = None) -> list[str]:
    """Return descendants for an entity."""
    return get_descendants(handle, entity_id, depth)


def descendant_elements(
    handle: QueryHandle,
    entity_id: str,
    depth: int | None = None,
    *,
    expand_all: bool = False,
    with_src: bool = False,
) -> list[TraversalElement]:
    """Return descendants as typed traversal elements."""
    return _traversal_elements_for_nodes(
        handle,
        get_descendant_nodes(handle, entity_id, depth),
        expand_all=expand_all,
        with_src=with_src,
    )


def descendants_with_notices(
    handle: QueryHandle, entity_id: str, depth: int | None = None
) -> LineageTraversal:
    """Return descendants plus any lineage notices."""
    return trace_descendants(handle, entity_id, depth)


def ancestors(handle: QueryHandle, entity_id: str, depth: int | None = None) -> list[str]:
    """Return ancestors for an entity."""
    return get_ancestors(handle, entity_id, depth)


def ancestor_elements(
    handle: QueryHandle,
    entity_id: str,
    depth: int | None = None,
    *,
    expand_all: bool = False,
    with_src: bool = False,
) -> list[TraversalElement]:
    """Return ancestors as typed traversal elements."""
    return _traversal_elements_for_nodes(
        handle,
        get_ancestor_nodes(handle, entity_id, depth),
        expand_all=expand_all,
        with_src=with_src,
    )


def ancestors_with_notices(
    handle: QueryHandle, entity_id: str, depth: int | None = None
) -> LineageTraversal:
    """Return ancestors plus any lineage notices."""
    return trace_ancestors(handle, entity_id, depth)


def path_between(handle: QueryHandle, start_id: str, end_id: str) -> list[str]:
    """Return the shortest relationship path between two entities."""
    return get_shortest_path(handle, start_id, end_id)


def path_elements(
    handle: QueryHandle,
    start_id: str,
    end_id: str,
    *,
    expand_all: bool = False,
    with_src: bool = False,
) -> list[TraversalElement]:
    """Return the shortest relationship path as typed traversal elements."""
    return _traversal_elements_for_nodes(
        handle,
        get_shortest_path_nodes(handle, start_id, end_id),
        expand_all=expand_all,
        with_src=with_src,
    )


def common_ancestor(handle: QueryHandle, left_id: str, right_id: str) -> str | None:
    """Return a shared ancestor for two entities."""
    return get_common_ancestor(handle, left_id, right_id)


def common_ancestor_path(
    handle: QueryHandle,
    left_id: str,
    right_id: str,
    *,
    expand_all: bool = False,
    with_src: bool = False,
) -> CommonAncestorPath:
    """Return the common-ancestor wrapper with typed traversal elements."""
    ancestor_id = get_common_ancestor(handle, left_id, right_id)
    if ancestor_id is None:
        return CommonAncestorPath(common_ancestor=None, elements=[])
    return CommonAncestorPath(
        common_ancestor=ancestor_id,
        elements=path_elements(handle, left_id, right_id, expand_all=expand_all, with_src=with_src),
    )


def cousin_distance(handle: QueryHandle, left_id: str, right_id: str) -> int | None:
    """Return a cousin degree for two entities."""
    return get_cousin_distance(handle, left_id, right_id)


def cousin_distance_path(
    handle: QueryHandle,
    left_id: str,
    right_id: str,
    *,
    expand_all: bool = False,
    with_src: bool = False,
) -> CousinDistancePath:
    """Return the cousin-distance wrapper with typed traversal elements."""
    relationship = get_cousin_relationship(handle, left_id, right_id)
    if relationship is None:
        return CousinDistancePath(cousin_distance=None, generations_removed=None, elements=[])
    return CousinDistancePath(
        cousin_distance=relationship.cousin_distance,
        generations_removed=relationship.generations_removed,
        elements=_traversal_elements_for_nodes(
            handle,
            get_cousin_path_nodes(handle, left_id, right_id),
            expand_all=expand_all,
            with_src=with_src,
        ),
    )


def siblings(handle: QueryHandle, entity_id: str) -> list[str]:
    """Return siblings for an entity."""
    return get_siblings(handle, entity_id)


def sibling_elements(
    handle: QueryHandle,
    entity_id: str,
    *,
    expand_all: bool = False,
    with_src: bool = False,
) -> list[TraversalElement]:
    """Return siblings as typed traversal elements."""
    return _traversal_elements_for_nodes(
        handle,
        get_sibling_nodes(handle, entity_id),
        expand_all=expand_all,
        include_root=False,
        with_src=with_src,
    )


def search(
    handle: QueryHandle,
    *,
    kind: str | None = None,
    surname: str | None = None,
    name: str | None = None,
    place: str | None = None,
    year: int | None = None,
    year_from: int | None = None,
    year_to: int | None = None,
    occupation: str | None = None,
    sex: str | None = None,
    residence: str | None = None,
    text: str | None = None,
    cites: str | None = None,
    full: bool = False,
    with_src: bool = False,
) -> list[OutputRecord]:
    """Search entities and return typed renderer inputs."""
    ids = search_entities(
        handle,
        kind=kind,
        surname=surname,
        name=name,
        place=place,
        year=year,
        year_from=year_from,
        year_to=year_to,
        occupation=occupation,
        sex=sex,
        residence=residence,
        text=text,
        cites=cites,
    )
    projection = _load_projection(handle)
    records = [
        record
        for entity_id in ids
        if (
            record := lookup_entity(
                handle,
                entity_id,
                with_src=with_src,
                projection=projection,
            )
        )
        is not None
    ]
    if full:
        return records
    return [record.lean_search_view(with_src=with_src) for record in records]


def search_payloads(
    handle: QueryHandle,
    *,
    kind: str | None = None,
    surname: str | None = None,
    name: str | None = None,
    place: str | None = None,
    year: int | None = None,
    year_from: int | None = None,
    year_to: int | None = None,
    occupation: str | None = None,
    sex: str | None = None,
    residence: str | None = None,
    text: str | None = None,
    cites: str | None = None,
    expand: Sequence[str] = (),
    expand_all: bool = False,
    with_src: bool = False,
) -> list[LookupPayload]:
    """Search entities and return lookup payloads with optional expansion."""
    ids = search_entities(
        handle,
        kind=kind,
        surname=surname,
        name=name,
        place=place,
        year=year,
        year_from=year_from,
        year_to=year_to,
        occupation=occupation,
        sex=sex,
        residence=residence,
        text=text,
        cites=cites,
    )
    projection = _load_projection(handle)
    return [
        payload
        for entity_id in ids
        if (
            payload := lookup_entity_payload(
                handle,
                entity_id,
                expand=expand,
                expand_all=expand_all,
                with_src=with_src,
                projection=projection,
            )
        )
        is not None
    ]


def run_raw_query(handle: QueryHandle, cypher: str) -> list[dict[str, object]]:
    """Execute a raw Cypher query against the derived graph."""
    return execute_raw_query(handle, cypher)


def _decode_bytes(value: bytes | None) -> str | None:
    return None if value is None else value.decode("utf-8")


def _canonical_entity_id(entity_id: str) -> str:
    return canonical_entity_xref(entity_id)


def _normalize_id(entity_id: str | None) -> str:
    return normalize_entity_id(entity_id)


def _build_output_record(
    source_path: Path,
    record: EntityRecord,
    projection: Projection,
) -> OutputRecord:
    raw_fields, field_sources = _record_raw_fields(record, projection, source_path)
    name_values = _values_as_strings(raw_fields.get("NAME"))
    primary_name = name_values[0] if name_values else None
    if primary_name is not None:
        raw_fields["NAME"] = primary_name
    subject_birth = _record_event_date(record, "BIRT") if record.kind == "INDI" else None
    event_birth = subject_birth if record.kind == "INDI" else None
    events = tuple(
        _output_event(event, source_path, subject_birth=event_birth) for event in record.events
    )
    representative_event = _representative_event(record.kind, events)
    relations = tuple(
        value
        for tag in ("FAMC", "FAMS", "HUSB", "WIFE", "CHIL")
        for value in _values_as_strings(raw_fields.get(tag))
        if value is not None
    )
    names = _output_name_occurrences(record, source_path)
    person_fields = _person_computed_fields(record) if record.kind == "INDI" else {}
    family_fields = (
        _family_computed_fields(record, projection, raw_fields) if record.kind == "FAM" else {}
    )
    record_payload: dict[str, Any] = {
        "entity_id": _normalize_id(record.entity_id),
        "kind": record.kind,
        "src": _source_ref(source_path, record.root_line_indexes),
        "name": primary_name,
        "name_variants": name_values,
        "names": names,
        "date": representative_event.date if representative_event is not None else None,
        "date_tag": (
            representative_event.tag
            if representative_event is not None and representative_event.date is not None
            else None
        ),
        "place": representative_event.place if representative_event is not None else None,
        "note": _string_value(raw_fields.get("NOTE")),
        "relations": relations,
        "field_src": OutputFieldSourceMap(by_tag=field_sources) if field_sources else None,
        "raw_fields": raw_fields,
        "events": events,
        _OUTWARD_NICKNAME_KEY: _primary_name_nickname(record, raw_fields),
        _OUTWARD_MEDIA_PATH_KEY: _string_value(raw_fields.get("FILE")),
        _OUTWARD_MEDIA_REFS_KEY: _values_as_strings(raw_fields.get("OBJE")),
        _OUTWARD_SOURCE_TEXT_KEY: _string_value(raw_fields.get("TEXT")),
        _OUTWARD_TITLE_KEY: _string_value(raw_fields.get("TITL")),
        _OUTWARD_PUBLICATION_KEY: _string_value(raw_fields.get("PUBL")),
        _OUTWARD_REPOSITORY_REF_KEY: _string_value(raw_fields.get("REPO")),
        _OUTWARD_ASSOCIATIONS_KEY: tuple(
            _output_association(association, source_path) for association in record.associations
        ),
        "is_alive": _bool_field(person_fields, "is_alive"),
        "lifespan_years": _computed_field(person_fields, "lifespan_years"),
        "current_age": _computed_field(person_fields, "current_age"),
        "marriage_age_husb": _computed_field(family_fields, "marriage_age_husb"),
        "marriage_age_wife": _computed_field(family_fields, "marriage_age_wife"),
        "age_gap_years": _computed_field(family_fields, "age_gap_years"),
        "marriage_duration_years": _computed_field(family_fields, "marriage_duration_years"),
        "years_to_first_child": _computed_field(family_fields, "years_to_first_child"),
        "years_between_first_and_last_child": _computed_field(
            family_fields,
            "years_between_first_and_last_child",
        ),
    }
    return OutputRecord(**record_payload)


def _primary_name_nickname(
    record: EntityRecord,
    raw_fields: dict[str, object | None],
) -> str | None:
    for field in record.fields:
        if field.tag != "NAME":
            continue
        for child in field.children:
            if child.tag == "NICK" and child.value is not None:
                return child.value.decode("utf-8")
        break
    return _string_value(raw_fields.get("NICK"))


def _output_name_occurrences(
    record: EntityRecord,
    source_path: Path,
) -> tuple[OutputNameOccurrence, ...]:
    if record.kind != "INDI":
        return ()

    occurrences: list[OutputNameOccurrence] = []
    for field in record.fields:
        if field.tag != "NAME" or field.value is None or field.name_index is None:
            continue
        notes = tuple(
            _decode_bytes(child.value) or ""
            for child in field.children
            if child.tag == "NOTE" and child.value is not None
        )
        occurrences.append(
            OutputNameOccurrence(
                name_index=field.name_index,
                value=field.value.decode("utf-8"),
                source_ids=tuple(_normalize_id(source_id) for source_id in field.source_ids),
                notes=notes,
                note_refs=_extract_note_references(notes),
                src=_source_ref(source_path, field.line_indexes),
            )
        )
    return tuple(occurrences)


def _output_event(
    event: EventRecord,
    source_path: Path,
    *,
    subject_birth: DateValue | None = None,
) -> OutputEvent:
    age_at_event = None
    if subject_birth is not None:
        age_at_event = _difference_field(
            subject_birth,
            event.date,
            period_aware=event.tag not in _POINT_IN_TIME_EVENT_TAGS,
        )
    event_payload: dict[str, Any] = {
        "tag": event.tag,
        "src": _source_ref(source_path, event.line_indexes),
        _OUTWARD_EVENT_VALUE_KEY: _decode_bytes(event.value),
        "type": _decode_bytes(event.type_value),
        _OUTWARD_EVENT_CAUSE_KEY: _decode_bytes(event.cause),
        "date": _decode_bytes(event.date_raw),
        "place": _decode_bytes(event.place),
        "address": _decode_bytes(event.address),
        _OUTWARD_EVENT_SOURCE_IDS_KEY: tuple(
            _normalize_id(source_id) for source_id in event.source_ids
        ),
        _OUTWARD_EVENT_ASSOCIATIONS_KEY: tuple(
            _output_association(association, source_path) for association in event.associations
        ),
        "notes": tuple(_decode_bytes(note) or "" for note in event.notes),
        "note_src": tuple(
            OutputNoteSourceRef(src=_source_ref(source_path, indexes, include_line_end=True))
            for indexes in event.note_line_indexes
        ),
        "note_refs": event.note_refs,
        "age_at_event": age_at_event,
    }
    return OutputEvent(**event_payload)


def _output_association(association: Any, source_path: Path) -> OutputAssociation:
    return OutputAssociation(
        target_id=_normalize_id(association.target_id),
        role=_decode_bytes(association.role),
        source_ids=tuple(_normalize_id(source_id) for source_id in association.source_ids),
        src=_source_ref(source_path, association.line_indexes),
    )


def _record_raw_fields(
    record: EntityRecord,
    projection: Projection,
    source_path: Path,
) -> tuple[dict[str, object | None], dict[str, OutputSourceRef | list[OutputSourceRef]]]:
    raw_fields = build_record_raw_fields(record, projection)
    field_sources: dict[str, OutputSourceRef | list[OutputSourceRef]] = {}
    for field in record.fields:
        _insert_field_source(field_sources, field.tag, _source_ref(source_path, field.line_indexes))
    return raw_fields, field_sources


def _insert_field_source(
    field_sources: dict[str, OutputSourceRef | list[OutputSourceRef]],
    tag: str,
    value: OutputSourceRef,
) -> None:
    if tag not in field_sources:
        field_sources[tag] = value
        return

    current = field_sources[tag]
    if isinstance(current, list):
        current.append(value)
        return

    field_sources[tag] = [current, value]


def _representative_event(kind: str, events: tuple[OutputEvent, ...]) -> OutputEvent | None:
    if not events:
        return None

    if kind == "INDI":
        for preferred_tag in ("BIRT", "CHR", "BAPM"):
            tagged_event = next((event for event in events if event.tag == preferred_tag), None)
            if tagged_event is not None:
                return tagged_event

    if kind == "FAM":
        for preferred_tag in _FAMILY_REPRESENTATIVE_EVENT_TAGS:
            dated_event = next(
                (
                    event
                    for event in events
                    if event.tag == preferred_tag and event.date is not None
                ),
                None,
            )
            if dated_event is not None:
                return dated_event

        for preferred_tag in _FAMILY_REPRESENTATIVE_EVENT_TAGS:
            tagged_event = next((event for event in events if event.tag == preferred_tag), None)
            if tagged_event is not None:
                return tagged_event

        return None

    dated_events = [event for event in events if event.date is not None]
    earliest_dated = _select_earliest_output_event(dated_events)
    if earliest_dated is not None:
        return earliest_dated

    return events[0]


def _select_earliest_output_event(events: Sequence[OutputEvent]) -> OutputEvent | None:
    candidates = [(event, _output_event_chronology_key(event)) for event in events]
    known = [(event, key) for event, key in candidates if key is not None]
    if not known:
        return next((event for event, _ in candidates), None)
    return min(known, key=lambda item: item[1])[0]


def _output_event_chronology_key(event: OutputEvent) -> tuple[int, int, int, int] | None:
    if event.date is None:
        return None
    parsed = parse_date_value(event.date.encode("utf-8"))
    if parsed is None:
        return None
    return _chronology_key(parsed)


def _string_value(value: object | None) -> str | None:
    return value if isinstance(value, str) else None


def _values_as_strings(value: object | None) -> tuple[str, ...]:
    if isinstance(value, str):
        return (value,)
    if isinstance(value, list):
        return tuple(item for item in value if isinstance(item, str))
    return ()


def _extract_note_references(values: tuple[str, ...]) -> tuple[str, ...]:
    refs: list[str] = []
    seen: set[str] = set()
    for text in values:
        for reference in _NOTE_REF_PATTERN.findall(text):
            normalized = _normalize_id(reference)
            if normalized not in seen:
                seen.add(normalized)
                refs.append(normalized)
        for identifier in _NOTE_REF_LABEL_PATTERN.findall(text):
            normalized = _normalize_id(identifier)
            if normalized not in seen:
                seen.add(normalized)
                refs.append(normalized)
    return tuple(refs)


def _source_ref(
    source_path: Path,
    line_indexes: Sequence[int],
    *,
    include_line_end: bool = False,
) -> OutputSourceRef:
    line = line_indexes[0] + 1
    line_end = line_indexes[-1] + 1 if include_line_end and len(line_indexes) > 1 else None
    return OutputSourceRef(file=str(source_path), line=line, line_end=line_end)


def _expand_reference_value(
    handle: QueryHandle,
    reference: object | None,
    *,
    projection: Projection | None = None,
) -> Any:
    if isinstance(reference, str):
        expanded = lookup_entity(handle, reference, projection=projection)
        if expanded is None:
            return None
        return LookupPayload.from_record(expanded)

    if isinstance(reference, list):
        return [_expand_reference_value(handle, item, projection=projection) for item in reference]

    return None


class _SourceCitationExpansion(NamedTuple):
    facts: tuple[OutputCitationFact, ...]
    event_notes: tuple[OutputCitationEventNotes, ...]


def _expand_source_citation_details(
    handle: QueryHandle,
    record: OutputRecord,
    *,
    projection: Projection | None,
) -> _SourceCitationExpansion:
    if record.entity_id is None:
        return _SourceCitationExpansion((), ())

    rows = execute_raw_query(
        handle,
        "MATCH (e:entities)-[c:cites]->(s:entities {id: '"
        f"{record.entity_id}"
        "'}) RETURN e.id AS entity_id, e.kind AS entity_kind, "
        "c.subject_kind AS subject_kind, c.event_tag AS tag, "
        "c.association_target_id AS association_target_id, "
        "c.association_role AS association_role, c.name_index AS name_index "
        "ORDER BY entity_id, subject_kind, tag, association_target_id, "
        "association_role, name_index;",
    )
    if not rows:
        return _SourceCitationExpansion((), ())

    effective_projection = _load_projection(handle) if projection is None else projection
    owner_cache: dict[str, OutputRecord | None] = {}
    owner_states: dict[str, _CitationOwnerState] = {}
    facts: list[OutputCitationFact] = []
    event_notes: list[OutputCitationEventNotes] = []

    for row in rows:
        owner_id = _row_string(row, "entity_id")
        if owner_id is None:
            continue
        if owner_id not in owner_cache:
            owner_cache[owner_id] = lookup_entity(handle, owner_id, projection=effective_projection)
        owner = owner_cache[owner_id]
        if owner is not None and owner_id not in owner_states:
            owner_states[owner_id] = _CitationOwnerState(owner, record.entity_id)
        fact, cited_event_notes = _citation_fact_for_row(
            row,
            owner=owner,
            state=owner_states.get(owner_id),
        )
        facts.append(fact)
        if cited_event_notes is not None:
            event_notes.append(cited_event_notes)

    return _SourceCitationExpansion(tuple(facts), tuple(event_notes))


class _CitationOwnerState:
    def __init__(self, record: OutputRecord, source_id: str) -> None:
        self.record = record
        self.event_matches: dict[str, list[OutputEvent]] = {}
        self.association_matches: dict[
            tuple[str | None, str | None, str | None],
            list[OutputAssociation],
        ] = {}

        for event in record.events:
            if source_id in event.source_ids:
                self.event_matches.setdefault(event.tag, []).append(event)
            for association in event.associations:
                if source_id in association.source_ids:
                    event_key: tuple[str | None, str | None, str | None] = (
                        event.tag,
                        association.target_id,
                        association.role,
                    )
                    self.association_matches.setdefault(event_key, []).append(association)

        for association in record.associations:
            if source_id in association.source_ids:
                record_key: tuple[str | None, str | None, str | None] = (
                    None,
                    association.target_id,
                    association.role,
                )
                self.association_matches.setdefault(record_key, []).append(association)


def _citation_fact_for_row(
    row: dict[str, object],
    *,
    owner: OutputRecord | None,
    state: _CitationOwnerState | None,
) -> tuple[OutputCitationFact, OutputCitationEventNotes | None]:
    owner_entity_id = owner.entity_id if owner is not None else None
    owner_entity_kind = owner.kind if owner is not None else None
    entity_id = _row_string(row, "entity_id") or owner_entity_id or ""
    entity_kind = _row_string(row, "entity_kind") or owner_entity_kind or ""
    subject_kind = _row_string(row, "subject_kind") or "record"
    tag = _row_string(row, "tag")
    association_target_id = _row_string(row, "association_target_id")
    association_role = _row_string(row, "association_role")
    name_index = _row_int(row, "name_index")

    if subject_kind == "event" and state is not None and tag is not None:
        event = _consume_citation_event(state, tag)
        if event is not None:
            return (
                OutputCitationFact(
                    entity_id=entity_id,
                    entity_kind=entity_kind,
                    subject_kind="event",
                    tag=tag,
                    value=event.value,
                    type=event.type,
                    cause=event.cause,
                    date=event.date,
                    place=event.place,
                    address=event.address,
                ),
                _citation_event_notes(owner, entity_id, entity_kind, event),
            )
        return (
            OutputCitationFact(
                entity_id=entity_id,
                entity_kind=entity_kind,
                subject_kind="event",
                tag=tag,
                value=None,
            ),
            None,
        )

    if subject_kind == "association" and state is not None:
        _consume_citation_association(state, tag, association_target_id, association_role)
        return (
            OutputCitationFact(
                entity_id=entity_id,
                entity_kind=entity_kind,
                subject_kind="association",
                tag=tag,
                value=None,
                association_target_id=association_target_id,
                association_role=association_role,
            ),
            None,
        )

    if subject_kind == "name":
        value = None
        if owner is not None and name_index is not None and 0 <= name_index < len(owner.names):
            value = owner.names[name_index].value
        return (
            OutputCitationFact(
                entity_id=entity_id,
                entity_kind=entity_kind,
                subject_kind="name",
                tag="NAME",
                value=value,
                name_index=name_index,
            ),
            None,
        )

    return (
        OutputCitationFact(
            entity_id=entity_id,
            entity_kind=entity_kind,
            subject_kind="record",
            tag=tag,
            value=None,
            association_target_id=association_target_id,
            association_role=association_role,
        ),
        None,
    )


def _citation_event_notes(
    owner: OutputRecord | None,
    entity_id: str,
    entity_kind: str,
    event: OutputEvent,
) -> OutputCitationEventNotes | None:
    if not event.notes:
        return None
    owner_id = entity_id if owner is None or owner.entity_id is None else owner.entity_id
    owner_kind = entity_kind if owner is None else owner.kind
    return OutputCitationEventNotes(
        owner_id=owner_id,
        owner_kind=owner_kind,
        event_tag=event.tag,
        event_source_ids=event.source_ids,
        notes=event.notes,
        note_refs=event.note_refs,
    )


def _consume_citation_event(state: _CitationOwnerState, tag: str) -> OutputEvent | None:
    matches = state.event_matches.get(tag)
    if not matches:
        return None
    return matches.pop(0)


def _consume_citation_association(
    state: _CitationOwnerState,
    tag: str | None,
    association_target_id: str | None,
    association_role: str | None,
) -> OutputAssociation | None:
    matches = state.association_matches.get((tag, association_target_id, association_role))
    if not matches:
        return None
    return matches.pop(0)


def _row_string(row: dict[str, object], key: str) -> str | None:
    value = row.get(key)
    return value if isinstance(value, str) else None


def _row_int(row: dict[str, object], key: str) -> int | None:
    value = row.get(key)
    return value if isinstance(value, int) else None


def _traversal_elements_for_nodes(
    handle: QueryHandle,
    nodes: Sequence[TraversalNode],
    *,
    expand_all: bool,
    with_src: bool,
    include_root: bool = True,
) -> list[TraversalElement]:
    projection = _load_projection(handle)
    record_cache: dict[str, LookupPayload | None] = {}
    elements: list[TraversalElement] = []
    iterable = nodes if include_root else nodes
    for node in iterable:
        if node.relation is not None and node.family_id is not None:
            elements.append(
                TraversalEdge(
                    fam_id=node.family_id,
                    role=_edge_role_for_node(projection, node),
                    record=_lookup_payload_cached(
                        handle,
                        node.family_id,
                        projection=projection,
                        with_src=with_src,
                        record_cache=record_cache,
                    )
                    if expand_all
                    else None,
                )
            )
        elements.append(
            TraversalPerson(
                entity_id=node.person_id,
                record=_lookup_payload_cached(
                    handle,
                    node.person_id,
                    projection=projection,
                    with_src=with_src,
                    record_cache=record_cache,
                )
                if expand_all
                else None,
            )
        )
    return elements


def _edge_role_for_node(projection: Projection, node: TraversalNode) -> TraversalRole:
    if node.relation == "child":
        return "CHIL-of"
    if node.relation == "sibling":
        return "SIBLING-of"
    if node.family_id is None:
        raise ValueError(f"missing family id for traversal node {node.person_id}")

    family_record = projection.get_record(_canonical_entity_id(node.family_id))
    if family_record is None:
        raise ValueError(f"family {node.family_id} missing from projection")

    normalized_person_id = _canonical_entity_id(node.person_id)
    for field in family_record.fields:
        if normalized_person_id not in field.references:
            continue
        if field.tag == "HUSB":
            return "HUSB-of"
        if field.tag == "WIFE":
            return "WIFE-of"
        if field.tag == "CHIL":
            return "CHIL-of"

    raise ValueError(
        f"could not resolve traversal role for {node.person_id} in family {node.family_id}"
    )


def _lookup_payload_cached(
    handle: QueryHandle,
    entity_id: str,
    *,
    projection: Projection,
    with_src: bool,
    record_cache: dict[str, LookupPayload | None],
) -> LookupPayload | None:
    if entity_id not in record_cache:
        record = lookup_entity(handle, entity_id, with_src=with_src, projection=projection)
        record_cache[entity_id] = None if record is None else LookupPayload.from_record(record)
    return record_cache[entity_id]


def _expanded_fields_for_record(
    handle: QueryHandle,
    record: OutputRecord,
    *,
    expand: str | Sequence[str] | None,
    expand_all: bool,
    projection: Projection | None,
) -> dict[str, Any]:
    if expand_all:
        tags = tuple(
            dict.fromkeys(
                [
                    *(
                        tag
                        for tag in record.raw_fields
                        if _is_expandable_field(record, tag, record.raw_fields[tag])
                    ),
                    *(_synthetic_expand_tags(record)),
                ]
            )
        )
    elif isinstance(expand, str):
        tags = (expand.upper(),)
    elif expand is None:
        tags = ()
    else:
        tags = tuple(tag.upper() for tag in expand)

    expanded_fields: dict[str, Any] = {}
    for tag in tags:
        if tag == _SOURCE_CITES_EXPAND_TAG and record.kind == "SOUR":
            expansion = _expand_source_citation_details(handle, record, projection=projection)
            expanded_fields[tag] = expansion.facts
            expanded_fields["EVENT_NOTES"] = expansion.event_notes
            continue
        outward_tag = record_outward_json_key(tag) or tag
        expanded_fields[outward_tag] = _expanded_field_value(
            handle,
            record,
            tag,
            projection=projection,
        )
    return expanded_fields


def _expanded_field_value(
    handle: QueryHandle,
    record: OutputRecord,
    tag: str,
    *,
    projection: Projection | None,
) -> Any:
    if tag == _SOURCE_CITES_EXPAND_TAG and record.kind == "SOUR":
        return _expand_source_citation_details(handle, record, projection=projection).facts

    expanded_event = _expand_event_values(record, tag)
    if expanded_event is not None:
        return expanded_event

    reference = record.raw_fields.get(tag)
    if reference is None:
        return None
    return _expand_reference_value(handle, reference, projection=projection)


def _is_expandable_field(record: OutputRecord, tag: str, value: object | None) -> bool:
    if _expand_event_values(record, tag) is not None:
        return True
    if isinstance(value, str):
        return _looks_like_entity_id(value)
    if isinstance(value, list):
        return any(isinstance(item, str) and _looks_like_entity_id(item) for item in value)
    return False


def _synthetic_expand_tags(record: OutputRecord) -> tuple[str, ...]:
    if record.kind == "SOUR":
        return (_SOURCE_CITES_EXPAND_TAG,)
    return ()


def _looks_like_entity_id(value: str) -> bool:
    return value[:1].isalpha() and any(character.isdigit() for character in value)


def _load_projection(handle: QueryHandle) -> Projection:
    _, projection = load_strict_document(handle.source_path)
    return projection


def _expand_event_values(record: OutputRecord, tag: str) -> Any:
    values = [serialize_output_event_payload(event) for event in record.events if event.tag == tag]
    if not values:
        return None
    if len(values) == 1:
        return values[0]
    return values


def _person_computed_fields(record: EntityRecord) -> dict[str, object]:
    birth = _record_event_date(record, "BIRT")
    death = _record_event_date(record, "DEAT")
    has_death = death is not None
    is_alive = _compute_is_alive(birth, has_death)
    current_age = _compute_current_age(birth, is_alive)
    return {
        "is_alive": is_alive,
        "lifespan_years": _difference_field(birth, death),
        "current_age": current_age,
    }


def _family_computed_fields(
    record: EntityRecord,
    projection: Projection,
    raw_fields: dict[str, object | None],
) -> dict[str, object]:
    marriage = _record_event_date(record, "MARR")
    divorce = _record_event_date(record, "DIV")
    husband_birth = _linked_record_event_date(raw_fields.get("HUSB"), projection, "BIRT")
    husband_death = _linked_record_event_date(raw_fields.get("HUSB"), projection, "DEAT")
    wife_birth = _linked_record_event_date(raw_fields.get("WIFE"), projection, "BIRT")
    wife_death = _linked_record_event_date(raw_fields.get("WIFE"), projection, "DEAT")
    child_births = _linked_children_event_dates(raw_fields.get("CHIL"), projection, "BIRT")
    first_child = _select_earliest_date(child_births)
    last_child = _select_latest_date(child_births)
    duration_end = (
        divorce if divorce is not None else _select_earliest_date([husband_death, wife_death])
    )
    return {
        "marriage_age_husb": _difference_field(husband_birth, marriage),
        "marriage_age_wife": _difference_field(wife_birth, marriage),
        "age_gap_years": _difference_field(husband_birth, wife_birth),
        "marriage_duration_years": _difference_field(marriage, duration_end),
        "years_to_first_child": _difference_field(marriage, first_child),
        "years_between_first_and_last_child": _difference_field(first_child, last_child),
    }


def _record_event_date(record: EntityRecord, tag: str) -> DateValue | None:
    event = next((event for event in record.events if event.tag == tag), None)
    return None if event is None else event.date


def _linked_record_event_date(
    value: object | None,
    projection: Projection,
    tag: str,
) -> DateValue | None:
    if not isinstance(value, str):
        return None
    linked = projection.get_record(_canonical_entity_id(value))
    if linked is None:
        return None
    return _record_event_date(linked, tag)


def _linked_children_event_dates(
    value: object | None,
    projection: Projection,
    tag: str,
) -> list[DateValue | None]:
    child_ids = _values_as_strings(value)
    return [_linked_record_event_date(child_id, projection, tag) for child_id in child_ids]


def _difference_field(
    start: DateValue | None,
    end: DateValue | None,
    *,
    period_aware: bool = False,
) -> ComputedDateField:
    if (
        start is not None
        and end is not None
        and supports_exact_arithmetic(start)
        and supports_exact_arithmetic(end)
    ):
        return exact_year_difference(start, end)
    return fallback_difference(start, end, period_aware_index=1 if period_aware else None)


def _compute_is_alive(birth: DateValue | None, has_death: bool) -> bool | None:
    if has_death:
        return False
    if birth is None or birth.year is None:
        return None
    return date.today().year - birth.year < 110


def _compute_current_age(
    birth: DateValue | None,
    is_alive: bool | None,
) -> ComputedDateField | None:
    if not is_alive or birth is None or not supports_exact_arithmetic(birth):
        return None
    return exact_year_difference(birth, _today_date_value())


def _today_date_value() -> DateValue:
    today = date.today()
    return DateValue(
        raw=today.isoformat().encode("utf-8"),
        qualifier=None,
        year=today.year,
        month=today.month,
        day=today.day,
        confidence="exact",
        exact_date=today,
    )


def _select_earliest_date(values: Sequence[DateValue | None]) -> DateValue | None:
    candidates = [
        (candidate, _chronology_key(candidate)) for candidate in values if candidate is not None
    ]
    known = [(candidate, key) for candidate, key in candidates if key is not None]
    if not known:
        return next((candidate for candidate, _ in candidates), None)
    return min(known, key=lambda item: item[1])[0]


def _select_latest_date(values: Sequence[DateValue | None]) -> DateValue | None:
    candidates = [
        (candidate, _chronology_key(candidate)) for candidate in values if candidate is not None
    ]
    known = [(candidate, key) for candidate, key in candidates if key is not None]
    if not known:
        return next((candidate for candidate, _ in candidates), None)
    return max(known, key=lambda item: item[1])[0]


def _bool_field(values: dict[str, object], key: str) -> bool | None:
    value = values.get(key)
    return value if isinstance(value, bool) else None


def _computed_field(values: dict[str, object], key: str) -> ComputedDateField | None:
    value = values.get(key)
    return value if isinstance(value, ComputedDateField) else None


def _chronology_key(value: DateValue) -> tuple[int, int, int, int] | None:
    if value.exact_date is not None:
        return (1, value.exact_date.year, value.exact_date.month, value.exact_date.day)
    if value.era == "BC" and value.era_year is not None:
        return (0, -value.era_year, value.month or 0, value.day or 0)
    if value.year is not None:
        return (1, value.year, value.month or 0, value.day or 0)
    return None
