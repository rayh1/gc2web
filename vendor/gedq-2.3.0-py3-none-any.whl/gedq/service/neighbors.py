"""Deterministic co-occurrence report helpers for the neighbors command."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Literal

from gedq.errors import UserError
from gedq.model.entity_ids import normalize_entity_id
from gedq.model.events import AssociationRecord, EventRecord
from gedq.model.output import (
    NeighborAddressAnchor,
    NeighborEventAnchor,
    NeighborRow,
    NeighborSharedAnchors,
    NeighborsReport,
    NeighborWitnessAnchor,
)
from gedq.model.records import EntityRecord, RecordField
from gedq.parser.projection import Projection
from gedq.service.read import lookup_entity
from gedq.service.validate import load_strict_document
from gedq.storage.ladybug_index import QueryHandle

NeighborChannel = Literal["witness", "source", "event", "address"]
NEIGHBOR_CHANNELS: tuple[NeighborChannel, ...] = (
    "witness",
    "source",
    "event",
    "address",
)
DEFAULT_NEIGHBOR_CHANNELS: tuple[NeighborChannel, ...] = ("witness", "source", "event")
_INDI_ROLE_EVENT_PATTERN = re.compile(r"^(?P<role>.*?)\s*@#INDI(?::(?P<event>[A-Za-z0-9_]+))?@$")


@dataclass(frozen=True)
class NeighborsRequest:
    """Validated input for one neighbors report.

    Args:
        subject_id: Person identifier at the center of the report.
        channels: Selected co-occurrence channel names in public order.
        exclude_kin: Whether immediate relatives are removed from the report.
    """

    subject_id: str
    channels: tuple[NeighborChannel, ...] = DEFAULT_NEIGHBOR_CHANNELS
    exclude_kin: bool = False


@dataclass
class _NeighborAccumulator:
    witness: set[NeighborWitnessAnchor] = field(default_factory=set)
    source: set[str] = field(default_factory=set)
    event: set[NeighborEventAnchor] = field(default_factory=set)
    address: set[NeighborAddressAnchor] = field(default_factory=set)

    def channels(self) -> tuple[NeighborChannel, ...]:
        selected: list[NeighborChannel] = []
        for channel in NEIGHBOR_CHANNELS:
            if getattr(self, channel):
                selected.append(channel)
        return tuple(selected)


def build_neighbors_report(
    handle: QueryHandle,
    request: NeighborsRequest,
) -> NeighborsReport:
    """Build one deterministic co-occurrence report.

    Args:
        handle: The derived index handle for the source GEDCOM.
        request: Validated channel and filtering options.

    Returns:
        The typed neighbors report.

    Raises:
        UserError: If the subject is missing or is not an individual.
    """
    _, projection = load_strict_document(handle.source_path)
    subject = lookup_entity(
        handle,
        request.subject_id,
        projection=projection,
    )
    if subject is None:
        raise UserError("subject person not found")
    if subject.kind != "INDI":
        raise UserError("subject is not a person")
    normalized_subject_id = normalize_entity_id(subject.entity_id)
    people = _people_by_id(projection)
    accumulators: dict[str, _NeighborAccumulator] = {}

    if "witness" in request.channels:
        _collect_witness_neighbors(projection, normalized_subject_id, people, accumulators)
    if "source" in request.channels:
        _collect_source_neighbors(projection, normalized_subject_id, people, accumulators)
    if "event" in request.channels:
        _collect_event_neighbors(projection, normalized_subject_id, people, accumulators)
    if "address" in request.channels:
        _collect_address_neighbors(normalized_subject_id, people, accumulators)

    kin_ids = _immediate_kin_ids(projection, normalized_subject_id)
    rows = [
        _neighbor_row(entity_id, people[entity_id], accumulator, entity_id in kin_ids)
        for entity_id, accumulator in accumulators.items()
        if entity_id != normalized_subject_id
        and entity_id in people
        and not (request.exclude_kin and entity_id in kin_ids)
    ]
    rows.sort(key=lambda row: (-row.connection_count, row.entity_id))
    return NeighborsReport(subject_id=normalized_subject_id, neighbors=tuple(rows))


def format_neighbors_report(report: NeighborsReport, *, subject_name: str | None = None) -> str:
    """Render a neighbors report as deterministic human-readable rows.

    Args:
        report: The typed report to render.
        subject_name: Optional canonical GEDCOM name for the heading.

    Returns:
        Human-readable report text.
    """
    heading_name = _display_name(subject_name, report.subject_id)
    heading = f"{heading_name} [{report.subject_id}] — {len(report.neighbors)} associates"
    if not report.neighbors:
        return heading
    lines = [heading]
    for row in report.neighbors:
        channel_text = ", ".join(row.channels)
        anchor_text = _format_shared_anchors(row.shared)
        kin_text = "kin" if row.kin else "—"
        display_name = _display_name(row.name, row.entity_id)
        lines.append(f"{row.entity_id}  {display_name}  {channel_text}  {anchor_text}  {kin_text}")
    return "\n".join(lines)


def _people_by_id(projection: Projection) -> dict[str, EntityRecord]:
    return {
        normalize_entity_id(record.entity_id): record
        for record in projection.records
        if record.kind == "INDI" and record.entity_id is not None
    }


def _collect_witness_neighbors(
    projection: Projection,
    subject_id: str,
    people: dict[str, EntityRecord],
    accumulators: dict[str, _NeighborAccumulator],
) -> None:
    for owner_id, record in people.items():
        for event in record.events:
            for association in event.associations:
                _add_witness_anchor(
                    subject_id,
                    owner_id,
                    people,
                    accumulators,
                    association,
                    event_tag=event.tag,
                )
        for association in record.associations:
            _add_witness_anchor(
                subject_id,
                owner_id,
                people,
                accumulators,
                association,
            )


def _collect_source_neighbors(
    projection: Projection,
    subject_id: str,
    people: dict[str, EntityRecord],
    accumulators: dict[str, _NeighborAccumulator],
) -> None:
    resolvable_sources = {
        normalize_entity_id(record.entity_id)
        for record in projection.records
        if record.kind == "SOUR" and record.entity_id is not None
    }
    citations = {
        person_id: _record_source_ids(record) & resolvable_sources
        for person_id, record in people.items()
    }
    subject_sources = citations.get(subject_id, set())
    for person_id, source_ids in citations.items():
        if person_id == subject_id:
            continue
        shared = subject_sources & source_ids
        if shared:
            _accumulator(accumulators, person_id).source.update(shared)


def _collect_event_neighbors(
    projection: Projection,
    subject_id: str,
    people: dict[str, EntityRecord],
    accumulators: dict[str, _NeighborAccumulator],
) -> None:
    _collect_family_event_neighbors(projection, subject_id, people, accumulators)
    subject_events = _events_by_place_year(people[subject_id], include_residence=False)
    for person_id, record in people.items():
        if person_id == subject_id:
            continue
        other_events = _events_by_place_year(record, include_residence=False)
        for key in sorted(set(subject_events) & set(other_events)):
            place, year = key
            for subject_event in subject_events[key]:
                for other_event in other_events[key]:
                    _accumulator(accumulators, person_id).event.add(
                        NeighborEventAnchor(
                            kind="place_year",
                            event=subject_event.tag,
                            other_event=other_event.tag,
                            place=place,
                            year=year,
                        )
                    )


def _collect_family_event_neighbors(
    projection: Projection,
    subject_id: str,
    people: dict[str, EntityRecord],
    accumulators: dict[str, _NeighborAccumulator],
) -> None:
    for family in projection.records:
        if family.kind != "FAM" or family.entity_id is None or not family.events:
            continue
        participants = _family_participants(family) & set(people)
        if subject_id not in participants:
            continue
        family_id = normalize_entity_id(family.entity_id)
        for person_id in sorted(participants - {subject_id}):
            accumulator = _accumulator(accumulators, person_id)
            for event in family.events:
                accumulator.event.add(
                    NeighborEventAnchor(
                        kind="family",
                        event=event.tag,
                        family_id=family_id,
                    )
                )


def _collect_address_neighbors(
    subject_id: str,
    people: dict[str, EntityRecord],
    accumulators: dict[str, _NeighborAccumulator],
) -> None:
    subject_addresses = set(_events_by_place_year(people[subject_id], include_residence=True))
    for person_id, record in people.items():
        if person_id == subject_id:
            continue
        addresses = set(_events_by_place_year(record, include_residence=True))
        for place, year in sorted(subject_addresses & addresses):
            _accumulator(accumulators, person_id).address.add(
                NeighborAddressAnchor(place=place, year=year)
            )


def _events_by_place_year(
    record: EntityRecord,
    *,
    include_residence: bool,
) -> dict[tuple[str, int], tuple[EventRecord, ...]]:
    grouped: dict[tuple[str, int], list[EventRecord]] = {}
    for event in record.events:
        if (event.tag == "RESI") != include_residence:
            continue
        if event.place is None or event.date is None or event.date.year is None:
            continue
        key = (event.place.decode("utf-8"), event.date.year)
        grouped.setdefault(key, []).append(event)
    return {
        key: tuple(sorted(events, key=lambda event: (event.tag, event.line_indexes)))
        for key, events in grouped.items()
    }


def _record_source_ids(record: EntityRecord) -> set[str]:
    source_ids: set[str] = set()
    for event in record.events:
        source_ids.update(normalize_entity_id(source_id) for source_id in event.source_ids)
        for association in event.associations:
            source_ids.update(
                normalize_entity_id(source_id) for source_id in association.source_ids
            )
    for association in record.associations:
        source_ids.update(normalize_entity_id(source_id) for source_id in association.source_ids)
    source_ids.update(_field_source_ids(record.fields))
    source_ids.discard("")
    return source_ids


def _field_source_ids(fields: tuple[RecordField, ...]) -> set[str]:
    source_ids: set[str] = set()
    for record_field in fields:
        source_ids.update(normalize_entity_id(value) for value in record_field.source_ids)
        if record_field.tag == "SOUR":
            source_ids.update(normalize_entity_id(value) for value in record_field.references)
        source_ids.update(_field_source_ids(record_field.children))
    return source_ids


def _immediate_kin_ids(projection: Projection, subject_id: str) -> set[str]:
    kin_ids: set[str] = set()
    for family in projection.records:
        if family.kind != "FAM":
            continue
        parents = _field_reference_ids(family, ("HUSB", "WIFE"))
        children = _field_reference_ids(family, ("CHIL",))
        if subject_id in parents:
            kin_ids.update(parents - {subject_id})
            kin_ids.update(children)
        if subject_id in children:
            kin_ids.update(parents)
            kin_ids.update(children - {subject_id})
    kin_ids.discard(subject_id)
    return kin_ids


def _family_participants(record: EntityRecord) -> set[str]:
    return _field_reference_ids(record, ("HUSB", "WIFE", "CHIL"))


def _field_reference_ids(record: EntityRecord, tags: tuple[str, ...]) -> set[str]:
    return {
        normalize_entity_id(reference)
        for record_field in record.fields
        if record_field.tag in tags
        for reference in record_field.references
    }


def _neighbor_row(
    entity_id: str,
    record: EntityRecord,
    accumulator: _NeighborAccumulator,
    kin: bool,
) -> NeighborRow:
    channels = accumulator.channels()
    return NeighborRow(
        entity_id=entity_id,
        name=_record_name(record),
        kin=kin,
        connection_count=len(channels),
        channels=channels,
        shared=NeighborSharedAnchors(
            witness=tuple(sorted(accumulator.witness, key=_witness_sort_key)),
            source=tuple(sorted(accumulator.source)),
            event=tuple(sorted(accumulator.event, key=_event_sort_key)),
            address=tuple(sorted(accumulator.address, key=lambda value: (value.place, value.year))),
        ),
    )


def _accumulator(
    accumulators: dict[str, _NeighborAccumulator],
    entity_id: str,
) -> _NeighborAccumulator:
    return accumulators.setdefault(entity_id, _NeighborAccumulator())


def _record_name(record: EntityRecord) -> str | None:
    for record_field in record.fields:
        if record_field.tag == "NAME" and record_field.value is not None:
            return record_field.value.decode("utf-8")
    return None


def _display_name(name: str | None, entity_id: str) -> str:
    if name is None:
        return f"@{entity_id}@"
    if "/" not in name:
        return name
    first = name.find("/")
    second = name.find("/", first + 1)
    if second == -1:
        return name.replace("/", "").strip()
    before = name[:first].strip()
    surname = name[first + 1 : second].strip()
    after = name[second + 1 :].strip()
    given = " ".join(part for part in (before, after) if part)
    return " ".join(part for part in (given, surname) if part)


def _format_shared_anchors(shared: NeighborSharedAnchors) -> str:
    anchors: list[str] = []
    anchors.extend(_format_witness_anchor(anchor) for anchor in shared.witness)
    anchors.extend(shared.source)
    for anchor in shared.event:
        if anchor.kind == "family":
            anchors.append(f"FAM {anchor.family_id} {anchor.event}")
        else:
            anchors.append(f"{anchor.place} {anchor.year} ({anchor.event}/{anchor.other_event})")
    anchors.extend(f"RESI {anchor.place} {anchor.year}" for anchor in shared.address)
    return "; ".join(anchors)


def _witness_sort_key(anchor: NeighborWitnessAnchor) -> tuple[str, str, str]:
    return (anchor.of, anchor.event or "", anchor.role or "")


def _event_sort_key(
    anchor: NeighborEventAnchor,
) -> tuple[str, str, str, int, str, str]:
    return (
        anchor.kind,
        anchor.family_id or "",
        anchor.place or "",
        anchor.year or -1,
        anchor.event,
        anchor.other_event or "",
    )


def _decode(value: bytes | None) -> str | None:
    return None if value is None else value.decode("utf-8")


def _add_witness_anchor(
    subject_id: str,
    owner_id: str,
    people: dict[str, EntityRecord],
    accumulators: dict[str, _NeighborAccumulator],
    association: AssociationRecord,
    *,
    event_tag: str | None = None,
) -> None:
    target_id = normalize_entity_id(association.target_id)
    if target_id not in people:
        return
    if owner_id == subject_id:
        neighbor_id = target_id
    elif target_id == subject_id:
        neighbor_id = owner_id
    else:
        return
    if neighbor_id == subject_id:
        return
    role, parsed_event = _association_role_and_event(association.role, default_event=event_tag)
    _accumulator(accumulators, neighbor_id).witness.add(
        NeighborWitnessAnchor(
            role=role,
            event=parsed_event,
            of=owner_id,
        )
    )


def _association_role_and_event(
    value: bytes | None,
    *,
    default_event: str | None,
) -> tuple[str | None, str | None]:
    decoded = _decode(value)
    if decoded is None:
        return None, default_event
    stripped = decoded.strip()
    match = _INDI_ROLE_EVENT_PATTERN.fullmatch(stripped)
    if match is None:
        return stripped or None, default_event
    role = match.group("role").strip() or None
    return role, match.group("event")


def _format_witness_anchor(anchor: NeighborWitnessAnchor) -> str:
    base = f"{anchor.role or 'associate'} at {anchor.of}"
    if anchor.event is None:
        return base
    return f"{base} {anchor.event}"
