"""Implementation for the anniversary command."""

from __future__ import annotations

from pathlib import Path

import typer

from gedq.cli.commands._common import (
    cache_dir_option,
    emit_payload,
    open_handle,
    resolve_cache_base,
    resolve_output_mode,
    run_command,
)
from gedq.errors import UserError
from gedq.service.anniversary import (
    build_anniversary_all_days_report,
    build_anniversary_report,
    format_anniversary_all_days_report,
    format_anniversary_report,
    parse_event_selection,
    resolve_query_date,
)


def run(
    ged_path: Path,
    cache_dir: str | None = cache_dir_option(),
    date: str | None = typer.Option(
        None,
        "--date",
        help="Query date as YYYY-MM-DD or 'DD MON'; mutually exclusive with --today.",
    ),
    today: bool = typer.Option(
        False,
        "--today",
        help="Use the current day and month; default when --date is omitted.",
    ),
    events: str | None = typer.Option(
        None,
        "--events",
        help="Comma-separated subset of birth,marriage,death; defaults to birth.",
    ),
    all_days: bool = typer.Option(
        False,
        "--all-days",
        help=(
            "Return every populated month-day in one invocation; "
            "cannot be combined with --date or --today."
        ),
    ),
    json_output: bool = typer.Option(False, "--json", help="Emit anniversary output as JSON."),
    human_output: bool = typer.Option(False, "--human", help="Emit human-readable output."),
) -> None:
    """Report deterministic anniversaries for one calendar day or a whole year."""

    def handler() -> None:
        cache_base = resolve_cache_base(cache_dir)
        handle = open_handle(ged_path, cache_base=cache_base)
        selected_events = parse_event_selection(events)
        if all_days:
            if date is not None or today:
                raise UserError("--all-days cannot be combined with --date or --today")
            all_days_report = build_anniversary_all_days_report(
                handle,
                selected_events=selected_events,
            )
            if resolve_output_mode(json_output=json_output, human_output=human_output) == "json":
                emit_payload(all_days_report, json_output=json_output, human_output=human_output)
                return
            typer.echo(format_anniversary_all_days_report(all_days_report))
            return
        query_date = resolve_query_date(explicit_date=date, use_today=today)
        single_day_report = build_anniversary_report(
            handle,
            query_date=query_date,
            selected_events=selected_events,
        )
        if resolve_output_mode(json_output=json_output, human_output=human_output) == "json":
            emit_payload(single_day_report, json_output=json_output, human_output=human_output)
            return
        typer.echo(format_anniversary_report(single_day_report))

    run_command(handler, json_output=json_output, human_output=human_output)
