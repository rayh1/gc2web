"""Implementation for the gaps command."""

from __future__ import annotations

from pathlib import Path

import typer

from gedq.cli.commands._common import (
    cache_dir_option,
    emit_payload,
    open_handle,
    resolve_cache_base,
    resolve_output_mode,
    run_command,
)
from gedq.service.gaps import GapsRequest, build_gaps_report, format_gaps_report


def run(
    ged_path: Path,
    cache_dir: str | None = cache_dir_option(),
    check: str | None = typer.Option(
        None,
        "--check",
        help=(
            "Comma-separated subset of marriage-no-children,couple-no-marriage,"
            "death-no-burial,overdue-death,birth-no-baptism."
        ),
    ),
    as_of: str | None = typer.Option(
        None,
        "--as-of",
        help="Reference year as YYYY or ISO date; defaults to the latest resolvable year in-file.",
    ),
    json_output: bool = typer.Option(False, "--json", help="Emit gaps output as JSON."),
    human_output: bool = typer.Option(False, "--human", help="Emit human-readable output."),
) -> None:
    """Report deterministic structural research leads without acting as a validation gate."""

    def handler() -> None:
        cache_base = resolve_cache_base(cache_dir)
        handle = open_handle(ged_path, cache_base=cache_base)
        request = GapsRequest.from_cli(checks=check, as_of=as_of)
        report = build_gaps_report(handle, request)
        if resolve_output_mode(json_output=json_output, human_output=human_output) == "json":
            emit_payload(report, json_output=json_output, human_output=human_output)
            return
        typer.echo(format_gaps_report(report))

    run_command(handler, json_output=json_output, human_output=human_output)
