"""Implementation for the neighbors command."""

from __future__ import annotations

from pathlib import Path

import typer

from gedq.cli.commands._common import (
    cache_dir_option,
    emit_payload,
    open_handle,
    resolve_cache_base,
    resolve_output_overrides,
    run_command,
)
from gedq.errors import UserError
from gedq.log import redacted_resource_context
from gedq.service.neighbors import (
    DEFAULT_NEIGHBOR_CHANNELS,
    NEIGHBOR_CHANNELS,
    NeighborChannel,
    NeighborsRequest,
    build_neighbors_report,
    format_neighbors_report,
)
from gedq.service.read import lookup_entity_or_error
from gedq.service.validate import load_strict_document


def run(
    ged_path: Path,
    entity_id: str,
    cache_dir: str | None = cache_dir_option(),
    via: str | None = typer.Option(
        None,
        "--via",
        help="Comma-separated subset of witness,source,event,address.",
    ),
    exclude_kin: bool = typer.Option(
        False,
        "--exclude-kin",
        help="Exclude parents, children, spouses, and siblings.",
    ),
    json_output: bool = typer.Option(False, "--json", help="Emit neighbors output as JSON."),
) -> None:
    """Report deterministic structural co-occurrences for one person.

    Args:
        ged_path: GEDCOM file to query without modifying it.
        entity_id: Individual identifier at the center of the report.
        cache_dir: Optional base directory for derived query-cache artifacts.
        via: Optional comma-separated lowercase channel selection. Omission selects
            witness, source, and event.
        exclude_kin: Whether to remove immediate relatives from the report.
        json_output: Whether to emit the stable JSON report envelope.

    Returns:
        None. The report is emitted to standard output.

    Raises:
        typer.Exit: After a handled input, data, or internal error is rendered.
    """

    def handler() -> None:
        request = NeighborsRequest(
            subject_id=entity_id,
            channels=_parse_channel_selection(via),
            exclude_kin=exclude_kin,
        )
        cache_base = resolve_cache_base(cache_dir)
        handle = open_handle(ged_path, cache_base=cache_base)
        report = build_neighbors_report(handle, request)
        json_requested, _ = resolve_output_overrides(
            json_output=json_output,
            human_output=False,
        )
        if json_requested:
            emit_payload(report, json_output=True, human_output=False)
            return
        _, projection = load_strict_document(handle.source_path)
        subject = lookup_entity_or_error(
            handle,
            request.subject_id,
            expected_kind="INDI",
            projection=projection,
        )
        typer.echo(format_neighbors_report(report, subject_name=subject.name))

    with redacted_resource_context(entity_id):
        run_command(handler, json_output=json_output, human_output=False)


def _parse_channel_selection(raw: str | None) -> tuple[NeighborChannel, ...]:
    if raw is None:
        return DEFAULT_NEIGHBOR_CHANNELS
    parts = tuple(part.strip() for part in raw.split(","))
    if not parts or any(not part for part in parts):
        raise UserError("--via requires one or more literal channel values")
    if any(part not in NEIGHBOR_CHANNELS for part in parts):
        valid = ", ".join(NEIGHBOR_CHANNELS)
        raise UserError(f"unsupported neighbor channel; valid values: {valid}")
    selected = set(parts)
    return tuple(channel for channel in NEIGHBOR_CHANNELS if channel in selected)
