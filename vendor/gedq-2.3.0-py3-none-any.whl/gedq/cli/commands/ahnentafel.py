"""Implementation for the ahnentafel command."""

from __future__ import annotations

from pathlib import Path

import typer

from gedq.cli.commands._common import (
    cache_dir_option,
    emit_payload,
    open_handle,
    resolve_cache_base,
    resolve_output_mode,
    run_command,
)
from gedq.service.numbered_reports import (
    NumberedReportRequest,
    build_ahnentafel_report,
    format_numbered_report,
)


def run(
    ged_path: Path,
    entity_id: str,
    cache_dir: str | None = cache_dir_option(),
    generations: int | None = typer.Option(
        None,
        "--generations",
        min=1,
        help="Limit the report depth, counting the subject as generation 1.",
    ),
    json_output: bool = typer.Option(False, "--json", help="Emit report output as JSON."),
    human_output: bool = typer.Option(False, "--human", help="Emit human-readable output."),
) -> None:
    """Render a deterministic numbered ancestor report."""

    def handler() -> None:
        cache_base = resolve_cache_base(cache_dir)
        handle = open_handle(ged_path, cache_base=cache_base)
        report = build_ahnentafel_report(
            handle,
            NumberedReportRequest.ahnentafel(entity_id=entity_id, generations=generations),
        )
        if resolve_output_mode(json_output=json_output, human_output=human_output) == "json":
            emit_payload(report, json_output=json_output, human_output=human_output)
            return
        typer.echo(format_numbered_report(report))

    run_command(handler, json_output=json_output, human_output=human_output)
