"""Implementation for the batch command."""

from __future__ import annotations

import shlex
from pathlib import Path

import typer

from gedq.cli.commands._common import (
    cache_dir_option,
    resolve_cache_base,
    resolve_output_mode,
    run_command,
)
from gedq.errors import UserError
from gedq.model.batch import BatchOpStatus, BatchReport, BatchSummary
from gedq.service.write import (
    BatchOpLine,
    BatchPlan,
    BatchRequest,
    EditRequest,
    WriteService,
    build_operations,
)

_FLAG_FIELD_NAMES = {
    "--set": "set_fields",
    "--clear": "clear_fields",
    "--add": "add_fields",
    "--remove": "remove_fields",
}


def run(
    ged_path: Path,
    ops_file: Path,
    cache_dir: str | None = cache_dir_option(),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Plan and report every operation without writing GED_PATH.",
    ),
    json_output: bool = typer.Option(
        False, "--json", help="Emit the full per-operation batch report as JSON on stdout."
    ),
    human_output: bool = typer.Option(False, "--human", help="Force human-readable output."),
) -> None:
    """Apply many edit operations from OPS_FILE to GED_PATH in one all-or-nothing batch."""

    def handler() -> None:
        cache_base = resolve_cache_base(cache_dir)
        lines = read_ops_file(ops_file, ged_path, cache_base=cache_base)
        service = WriteService()
        plan = service.plan_batch(
            BatchRequest(ged_path=ged_path, cache_base=cache_base, lines=lines)
        )
        if not plan.blocked and not dry_run:
            plan = service.apply_batch_plan(plan)

        report = _build_report(plan, dry_run=dry_run)
        _emit_report(report, json_output=json_output, human_output=human_output)

        if plan.blocked:
            raise typer.Exit(code=_failing_exit_code(report))

    run_command(handler, json_output=json_output, human_output=human_output)


def read_ops_file(
    ops_path: Path,
    ged_path: Path,
    *,
    cache_base: Path | None = None,
) -> tuple[BatchOpLine, ...]:
    """Read, tokenize, and compile OPS_FILE into ready-to-fold batch op lines.

    Blank lines and lines whose first non-whitespace character is `#` are
    skipped. Every other line is tokenized with POSIX `shlex` rules; token 0
    must be an xref, and the remaining tokens are grouped into the existing
    `--set/--clear/--add/--remove` grammar and compiled by the unmodified
    `build_operations` (ADR-0045). This reader holds no planning logic: it
    never touches a GEDCOM document, only the ops-file text.

    Args:
        ops_path: Path to the plain-text ops file.
        ged_path: The GEDCOM file each compiled line's edit will target.
        cache_base: Optional base directory for derived cache artifacts,
            threaded onto each compiled line's `EditRequest`.

    Returns:
        The compiled lines, in file order.

    Raises:
        UserError: If the file cannot be read as UTF-8, or any line is
            malformed (missing xref, unknown flag, flag without a value,
            a `shlex` quote error, or invalid field grammar).
    """
    try:
        text = ops_path.read_text(encoding="utf-8")
    except OSError as error:
        raise UserError(f"ops file not readable: {ops_path}") from error
    except UnicodeDecodeError as error:
        raise UserError(f"ops file is not valid UTF-8: {ops_path}") from error

    lines: list[BatchOpLine] = []
    for line_number, raw_line in enumerate(text.splitlines(), start=1):
        stripped = raw_line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        lines.append(_compile_line(line_number, raw_line, ged_path, cache_base))
    return tuple(lines)


def _compile_line(
    line_number: int,
    raw_line: str,
    ged_path: Path,
    cache_base: Path | None,
) -> BatchOpLine:
    tokens = _tokenize_line(line_number, raw_line)
    if not tokens or not _looks_like_xref(tokens[0]):
        raise _line_error(line_number, raw_line, "missing or malformed xref token")

    xref, flag_tokens = tokens[0], tokens[1:]
    grouped = _group_flags(line_number, raw_line, flag_tokens)

    try:
        operations = build_operations(
            set_fields=grouped["set_fields"],
            clear_fields=grouped["clear_fields"],
            add_fields=grouped["add_fields"],
            remove_fields=grouped["remove_fields"],
        )
    except UserError as error:
        raise _line_error(line_number, raw_line, str(error)) from error

    if not operations:
        raise _line_error(line_number, raw_line, "no field operations")

    return BatchOpLine(
        line=line_number,
        xref=xref,
        edit_request=EditRequest(
            ged_path=ged_path,
            cache_base=cache_base,
            entity_id=xref,
            operations=operations,
        ),
    )


def _tokenize_line(line_number: int, raw_line: str) -> list[str]:
    try:
        return shlex.split(raw_line, comments=False, posix=True)
    except ValueError as error:
        raise _line_error(line_number, raw_line, str(error)) from error


def _looks_like_xref(token: str) -> bool:
    return len(token) >= 3 and token.startswith("@") and token.endswith("@")


def _group_flags(line_number: int, raw_line: str, tokens: list[str]) -> dict[str, list[str]]:
    grouped: dict[str, list[str]] = {name: [] for name in _FLAG_FIELD_NAMES.values()}
    index = 0
    while index < len(tokens):
        flag = tokens[index]
        field_name = _FLAG_FIELD_NAMES.get(flag)
        if field_name is None:
            raise _line_error(line_number, raw_line, f"unknown flag: {flag}")
        if index + 1 >= len(tokens):
            raise _line_error(line_number, raw_line, f"{flag} requires a value")
        grouped[field_name].append(tokens[index + 1])
        index += 2
    return grouped


def _line_error(line_number: int, raw_line: str, detail: str) -> UserError:
    return UserError(f"line {line_number}: {detail}: {raw_line.strip()}")


def _build_report(plan: BatchPlan, *, dry_run: bool) -> BatchReport:
    counted: dict[BatchOpStatus, int] = dict.fromkeys(BatchOpStatus, 0)
    for result in plan.results:
        counted[result.status] += 1
    summary = BatchSummary(
        total=len(plan.results),
        applied=counted[BatchOpStatus.APPLIED] + counted[BatchOpStatus.WOULD_APPLY],
        failed=counted[BatchOpStatus.FAILED],
        not_applied=counted[BatchOpStatus.NOT_APPLIED],
        not_reached=counted[BatchOpStatus.NOT_REACHED],
    )
    return BatchReport(ops=plan.results, summary=summary, dry_run=dry_run)


def _emit_report(report: BatchReport, *, json_output: bool, human_output: bool) -> None:
    mode = resolve_output_mode(json_output=json_output, human_output=human_output)
    if mode == "json":
        typer.echo(report.model_dump_json(exclude_none=True))
        return

    typer.echo(_human_summary(report))
    for op in report.ops:
        if op.error is not None:
            typer.echo(f"line {op.line} ({op.xref}): {op.error.message}", err=True)


def _human_summary(report: BatchReport) -> str:
    summary = report.summary
    success_label = "would_apply" if report.dry_run else "applied"
    return (
        f"batch: total={summary.total} {success_label}={summary.applied} "
        f"failed={summary.failed} not_applied={summary.not_applied} "
        f"not_reached={summary.not_reached}"
    )


def _failing_exit_code(report: BatchReport) -> int:
    for op in report.ops:
        if op.error is not None:
            return op.error.code
    raise AssertionError("blocked batch report expected exactly one failed op with an error")
