"""Report helpers for the anniversary command."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date as calendar_date
from calendar import isleap
from typing import Literal

from gedq.errors import UserError
from gedq.model.dates import MONTH_NUMBERS
from gedq.model.entity_ids import canonical_entity_xref, normalize_entity_id
from gedq.model.output import (
    AnniversaryAnchor,
    AnniversaryEventRow,
    AnniversaryLifespan,
    AnniversaryReport,
    OutputRecord,
)
from gedq.model.records import EntityRecord
from gedq.parser.projection import Projection
from gedq.query.properties import build_record_raw_fields
from gedq.service.read import lookup_entity
from gedq.service.tree import _compose_lifespan_label, _display_name
from gedq.service.validate import load_strict_document
from gedq.storage.ladybug_index import QueryHandle

ANNIVERSARY_EVENTS = ("birth", "marriage", "death")
_EVENT_TAGS: dict[str, Literal["BIRT", "MARR", "DEAT"]] = {
    "birth": "BIRT",
    "marriage": "MARR",
    "death": "DEAT",
}
_EVENT_ORDER = {"BIRT": 0, "MARR": 1, "DEAT": 2}
_ORDINAL_KINDS: dict[
    Literal["BIRT", "MARR", "DEAT"],
    Literal["birthday", "anniversary", "years_ago"],
] = {
    "BIRT": "birthday",
    "MARR": "anniversary",
    "DEAT": "years_ago",
}
_AnniversaryEventTag = Literal["BIRT", "MARR", "DEAT"]


@dataclass(frozen=True)
class _ParsedAnniversaryDate:
    day: int
    month: int
    year: int | None


@dataclass(frozen=True)
class AnniversaryQueryDate:
    year: int
    month: int
    day: int
    display: str
    allows_feb29_match: bool = True


def parse_event_selection(raw: str | None) -> tuple[str, ...]:
    """Normalize the outward anniversary event selection."""
    if raw is None:
        return ("birth",)
    parts = tuple(part.strip().lower() for part in raw.split(",") if part.strip())
    if not parts:
        raise UserError("--events requires one or more values")
    invalid = [part for part in parts if part not in ANNIVERSARY_EVENTS]
    if invalid:
        valid = ", ".join(ANNIVERSARY_EVENTS)
        raise UserError(
            f"unsupported anniversary event(s): {', '.join(invalid)}; valid events: {valid}"
        )
    return tuple(dict.fromkeys(parts))


def resolve_query_date(*, explicit_date: str | None, use_today: bool) -> AnniversaryQueryDate:
    """Resolve the effective anniversary query date."""
    if explicit_date is not None and use_today:
        raise UserError("--date and --today are mutually exclusive")
    if explicit_date is None:
        today = calendar_date.today()
        return AnniversaryQueryDate(
            year=today.year,
            month=today.month,
            day=today.day,
            display=today.isoformat(),
        )
    try:
        parsed = calendar_date.fromisoformat(explicit_date)
        return AnniversaryQueryDate(
            year=parsed.year,
            month=parsed.month,
            day=parsed.day,
            display=parsed.isoformat(),
        )
    except ValueError:
        pass
    tokens = explicit_date.strip().upper().split()
    if len(tokens) == 2 and tokens[0].isdigit() and tokens[1] in MONTH_NUMBERS:
        year = calendar_date.today().year
        month = MONTH_NUMBERS[tokens[1]]
        day = int(tokens[0])
        allows_feb29_match = not (month == 2 and day == 29 and not isleap(year))
        return AnniversaryQueryDate(
            year=year,
            month=month,
            day=day,
            display=f"{year:04d}-{month:02d}-{day:02d}",
            allows_feb29_match=allows_feb29_match,
        )
    raise UserError("--date must be YYYY-MM-DD or 'DD MON'")


def build_anniversary_report(
    handle: QueryHandle,
    *,
    query_date: AnniversaryQueryDate | calendar_date,
    selected_events: tuple[str, ...],
) -> AnniversaryReport:
    """Build the outward anniversary report for one GEDCOM file."""
    normalized_query_date = _normalize_query_date(query_date)
    _, projection = load_strict_document(handle.source_path)
    output_cache: dict[str, OutputRecord] = {}
    rows: list[AnniversaryEventRow] = []
    for record in projection.records:
        if record.entity_id is None:
            continue
        if record.kind == "INDI":
            for event_name in ("birth", "death"):
                if event_name not in selected_events:
                    continue
                rows.extend(
                    _individual_rows(
                        handle,
                        projection,
                        record,
                        tag=_EVENT_TAGS[event_name],
                        query_date=normalized_query_date,
                        output_cache=output_cache,
                    )
                )
        elif record.kind == "FAM" and "marriage" in selected_events:
            rows.extend(
                _marriage_rows(
                    handle,
                    projection,
                    record,
                    query_date=normalized_query_date,
                    output_cache=output_cache,
                )
            )
    return AnniversaryReport(
        query_date=normalized_query_date.display,
        events=tuple(sorted(rows, key=_anniversary_sort_key)),
    )


def _normalize_query_date(value: AnniversaryQueryDate | calendar_date) -> AnniversaryQueryDate:
    if isinstance(value, AnniversaryQueryDate):
        return value
    return AnniversaryQueryDate(
        year=value.year,
        month=value.month,
        day=value.day,
        display=value.isoformat(),
        allows_feb29_match=not (value.month == 2 and value.day == 29 and not isleap(value.year)),
    )


def format_anniversary_report(report: AnniversaryReport) -> str:
    """Render anniversary rows in the outward human-readable format."""
    if not report.events:
        return f"no anniversaries on {report.query_date}"
    return "\n".join(_format_anniversary_row(row) for row in report.events)


def _individual_rows(
    handle: QueryHandle,
    projection: Projection,
    record: EntityRecord,
    *,
    tag: _AnniversaryEventTag,
    query_date: AnniversaryQueryDate,
    output_cache: dict[str, OutputRecord],
) -> list[AnniversaryEventRow]:
    owner = _lookup_output(handle, projection, record.entity_id, output_cache)
    if owner is None:
        return []
    rows: list[AnniversaryEventRow] = []
    for event in record.events:
        if event.tag != tag or event.date_raw is None:
            continue
        parsed = _parse_anniversary_event_date(event.date_raw.decode("utf-8"))
        if parsed is None or not _matches_query_date(parsed, query_date):
            continue
        anchor = _parent_anchor(handle, projection, record, output_cache)
        rows.append(
            AnniversaryEventRow(
                event=tag,
                entity_id=normalize_entity_id(record.entity_id),
                name=owner.name,
                date=event.date_raw.decode("utf-8"),
                day=parsed.day,
                month=parsed.month,
                year=parsed.year,
                ordinal=_ordinal_value(parsed.year, query_date.year),
                ordinal_kind=_ORDINAL_KINDS[tag],
                lifespan=_lifespan(owner),
                anchor=anchor,
            )
        )
    return rows


def _marriage_rows(
    handle: QueryHandle,
    projection: Projection,
    record: EntityRecord,
    *,
    query_date: AnniversaryQueryDate,
    output_cache: dict[str, OutputRecord],
) -> list[AnniversaryEventRow]:
    rows: list[AnniversaryEventRow] = []
    raw_fields = build_record_raw_fields(record, projection)
    spouse_ids = tuple(_string_values(raw_fields.get(tag)) for tag in ("HUSB", "WIFE"))
    flattened_ids = tuple(value for values in spouse_ids for value in values)
    spouse_records = tuple(
        owner
        for spouse_id in flattened_ids
        if (owner := _lookup_output(handle, projection, spouse_id, output_cache)) is not None
    )
    for event in record.events:
        if event.tag != "MARR" or event.date_raw is None:
            continue
        parsed = _parse_anniversary_event_date(event.date_raw.decode("utf-8"))
        if parsed is None or not _matches_query_date(parsed, query_date):
            continue
        rows.append(
            AnniversaryEventRow(
                event="MARR",
                entity_id=normalize_entity_id(record.entity_id),
                names=tuple(owner.name for owner in spouse_records if owner.name is not None)
                or None,
                spouse_ids=flattened_ids or None,
                date=event.date_raw.decode("utf-8"),
                day=parsed.day,
                month=parsed.month,
                year=parsed.year,
                ordinal=_ordinal_value(parsed.year, query_date.year),
                ordinal_kind=_ORDINAL_KINDS["MARR"],
            )
        )
    return rows


def _lookup_output(
    handle: QueryHandle,
    projection: Projection,
    entity_id: str | None,
    output_cache: dict[str, OutputRecord],
) -> OutputRecord | None:
    if entity_id is None:
        return None
    if entity_id not in output_cache:
        output = lookup_entity(handle, entity_id, projection=projection)
        if output is None:
            return None
        output_cache[entity_id] = output
    return output_cache[entity_id]


def _parent_anchor(
    handle: QueryHandle,
    projection: Projection,
    record: EntityRecord,
    output_cache: dict[str, OutputRecord],
) -> AnniversaryAnchor | None:
    raw_fields = build_record_raw_fields(record, projection)
    family_ids = _string_values(raw_fields.get("FAMC"))
    if not family_ids:
        return None
    family_record = projection.get_record(canonical_entity_xref(family_ids[0]))
    if family_record is None:
        return None
    family_fields = build_record_raw_fields(family_record, projection)
    parent_ids = tuple(
        value
        for tag in ("HUSB", "WIFE")
        for value in _string_values(family_fields.get(tag))
    )
    parent_names = tuple(
        owner.name
        for parent_id in parent_ids
        if (owner := _lookup_output(handle, projection, parent_id, output_cache)) is not None
        and owner.name is not None
    )
    return AnniversaryAnchor(
        role="child",
        of=tuple(normalize_entity_id(value) for value in parent_ids),
        names=parent_names or None,
    )


def _parse_anniversary_event_date(raw: str) -> _ParsedAnniversaryDate | None:
    tokens = raw.strip().upper().split()
    if len(tokens) == 2 and tokens[0].isdigit() and tokens[1] in MONTH_NUMBERS:
        return _ParsedAnniversaryDate(
            day=int(tokens[0]),
            month=MONTH_NUMBERS[tokens[1]],
            year=None,
        )
    if (
        len(tokens) == 3
        and tokens[0].isdigit()
        and tokens[1] in MONTH_NUMBERS
        and tokens[2].isdigit()
    ):
        return _ParsedAnniversaryDate(
            day=int(tokens[0]),
            month=MONTH_NUMBERS[tokens[1]],
            year=int(tokens[2]),
        )
    return None


def _matches_query_date(value: _ParsedAnniversaryDate, query_date: AnniversaryQueryDate) -> bool:
    if value.day != query_date.day or value.month != query_date.month:
        return False
    if value.day == 29 and value.month == 2 and not query_date.allows_feb29_match:
        return False
    return True


def _ordinal_value(year: int | None, query_year: int) -> int | None:
    if year is None:
        return None
    return query_year - year


def _lifespan(record: OutputRecord) -> AnniversaryLifespan | None:
    birth = _event_year(record, "BIRT")
    death = _event_year(record, "DEAT")
    if birth is None and death is None:
        return None
    return AnniversaryLifespan(birth=birth, death=death)


def _event_year(record: OutputRecord, tag: str) -> int | None:
    for event in record.events:
        if event.tag != tag or event.date is None:
            continue
        parsed = _parse_anniversary_event_date(event.date)
        if parsed is not None:
            return parsed.year
        tokens = event.date.upper().split()
        if tokens and tokens[-1].isdigit():
            return int(tokens[-1])
    return None


def _format_anniversary_row(row: AnniversaryEventRow) -> str:
    names = _human_names(row)
    parts = [row.event, names, f"[{row.entity_id}]", _date_label(row)]
    ordinal = _human_ordinal(row)
    if ordinal is not None:
        parts.append(f"→ {ordinal}")
    lifespan = _human_lifespan(row)
    if lifespan is not None:
        parts.append(lifespan)
    anchor = _human_anchor(row.anchor)
    if anchor is not None:
        parts.append(anchor)
    return "  ".join(part for part in parts if part)


def _human_names(row: AnniversaryEventRow) -> str:
    if row.event == "MARR":
        return " & ".join(_display_name(_record_from_name(value)) for value in (row.names or ()))
    return _display_name(_record_from_name(row.name))


def _date_label(row: AnniversaryEventRow) -> str:
    prefix = {"BIRT": "b.", "MARR": "m.", "DEAT": "d."}[row.event]
    return f"{prefix} {row.date}"


def _human_ordinal(row: AnniversaryEventRow) -> str | None:
    if row.ordinal is None or row.ordinal_kind is None:
        return None
    if row.ordinal_kind == "years_ago":
        return f"{row.ordinal} yrs ago"
    return _ordinal_suffix(row.ordinal)


def _ordinal_suffix(value: int) -> str:
    absolute = abs(value)
    if 10 <= absolute % 100 <= 20:
        suffix = "th"
    else:
        suffix = {1: "st", 2: "nd", 3: "rd"}.get(absolute % 10, "th")
    return f"{value}{suffix}"


def _human_lifespan(row: AnniversaryEventRow) -> str | None:
    if row.event == "MARR":
        return f"({row.year if row.year is not None else '?'}– )"
    if row.lifespan is None:
        return None
    birth = "?" if row.lifespan.birth is None else str(row.lifespan.birth)
    death = "?" if row.lifespan.death is None else str(row.lifespan.death)
    return _compose_lifespan_label(birth, death)


def _human_anchor(anchor: AnniversaryAnchor | None) -> str | None:
    if anchor is None:
        return None
    if anchor.names:
        return "child of " + " & ".join(
            _display_name(_record_from_name(value)) for value in anchor.names
        )
    if anchor.of:
        return f"child of {' & '.join(anchor.of)}"
    return "child of"


def _anniversary_sort_key(row: AnniversaryEventRow) -> tuple[int, int, str]:
    return (_EVENT_ORDER[row.event], row.year if row.year is not None else 9999, row.entity_id)


def _record_from_name(value: str | None) -> OutputRecord:
    return OutputRecord(kind="INDI", name=value)


def _string_values(value: object | None) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, str):
        return (value,)
    if isinstance(value, tuple):
        return tuple(item for item in value if isinstance(item, str))
    if isinstance(value, list):
        return tuple(item for item in value if isinstance(item, str))
    return ()
