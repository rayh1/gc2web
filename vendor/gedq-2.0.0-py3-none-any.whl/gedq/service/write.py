"""File-first GEDCOM mutation services for top-level write commands."""

from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass
from datetime import datetime
from difflib import unified_diff
from pathlib import Path
from typing import Literal

from gedq.errors import UserError
from gedq.model.entity_ids import canonical_entity_xref, normalize_entity_id
from gedq.model.output_keys import (
    event_redirect_message,
    record_redirect_message,
    resolve_event_child_write_alias,
    resolve_record_write_alias,
)
from gedq.model.tags import (
    PERSONAL_NAME_PIECE_TAGS,
    resolve_event_tag_alias,
    resolve_registered_parent_alias,
    supports_event_tag,
    supports_registered_child_field,
    supports_registered_parent_field,
)
from gedq.parser.document import GedDocument, GedNode, parse_document
from gedq.parser.projection import project_document
from gedq.parser.serializer import write_atomic_bytes
from gedq.service.validate import load_strict_document
from gedq.storage.cache import cache_dir_for
from gedq.storage.metadata import MetadataStore, SourceSnapshot

FIELD_TAG_ALIASES = {
    "addr": "ADDR",
    "address": "ADDR",
    "chil": "CHIL",
    "date": "DATE",
    "famc": "FAMC",
    "fams": "FAMS",
    "file": "FILE",
    "husb": "HUSB",
    "name": "NAME",
    "note": "NOTE",
    "occup": "OCCU",
    "occupation": "OCCU",
    "plac": "PLAC",
    "place": "PLAC",
    "sex": "SEX",
    "sour": "SOUR",
    "source": "SOUR",
    "text": "TEXT",
    "titl": "TITL",
    "title": "TITL",
    "wife": "WIFE",
}
CANONICAL_ADD_KINDS = (
    "person",
    "family",
    "source",
    "note",
    "repo",
    "object",
    "submitter",
)
KIND_TAGS = {
    "person": ("INDI", "I"),
    "indi": ("INDI", "I"),
    "family": ("FAM", "F"),
    "fam": ("FAM", "F"),
    "source": ("SOUR", "S"),
    "sour": ("SOUR", "S"),
    "note": ("NOTE", "N"),
    "repo": ("REPO", "R"),
    "object": ("OBJE", "O"),
    "obje": ("OBJE", "O"),
    "submitter": ("SUBM", "U"),
    "subm": ("SUBM", "U"),
}
REFERENCE_TAGS = {"CHIL", "FAMC", "FAMS", "HUSB", "SOUR", "WIFE"}
NON_DUPLICATING_FAMILY_LINK_TAGS = {"CHIL", "FAMC", "FAMS", "HUSB", "WIFE"}
_SIBLING_SELECTOR_PATTERN = re.compile(r"^(?P<tag>[^.\[\]]+?)(?:\[(?P<index>[1-9][0-9]*)\])?$")


@dataclass(frozen=True)
class MutationOperation:
    """One field-oriented write operation."""

    action: str
    field: str
    value: str | None = None


@dataclass(frozen=True)
class PlannedMutationOperation:
    """One mutation with its field path and indexed target bound up front."""

    mutation: MutationOperation
    parent_tag: str | None
    field_tag: str
    sibling_index: int | None
    child_sibling_index: int | None = None
    target_line_indexes: tuple[int, ...] | None = None
    child_target_line_indexes: tuple[int, ...] | None = None
    coalesce_add_group: bool = False


@dataclass(frozen=True)
class AddRequest:
    """Request to create a new top-level GEDCOM entity."""

    ged_path: Path
    kind: str
    entity_id: str | None
    operations: tuple[MutationOperation, ...]
    cache_base: Path | None = None


@dataclass(frozen=True)
class EditRequest:
    """Request to mutate one existing top-level GEDCOM entity."""

    ged_path: Path
    entity_id: str
    operations: tuple[MutationOperation, ...]
    cache_base: Path | None = None


@dataclass(frozen=True)
class DeleteRequest:
    """Request to delete one existing top-level GEDCOM entity."""

    ged_path: Path
    entity_id: str
    cascade: bool = False
    cache_base: Path | None = None


@dataclass(frozen=True)
class MutationResult:
    """Result emitted by a successful mutation."""

    changed_ids: tuple[str, ...]
    cache_dir: Path
    updated_snapshot: SourceSnapshot
    changed_records: tuple[ChangedRecord, ...]
    warnings: tuple[str, ...] = ()


@dataclass(frozen=True)
class ChangedRecord:
    """Changed record context for downstream cache maintenance."""

    entity_id: str
    kind: str
    action: Literal["upsert", "delete"]


@dataclass(frozen=True)
class WritePlan:
    """Immutable planned write result shared by preview and apply paths."""

    ged_path: Path
    cache_base: Path | None
    operation: str
    changed_ids: tuple[str, ...]
    changed_records: tuple[ChangedRecord, ...]
    updated_bytes: bytes | None
    changed: bool
    warnings: tuple[str, ...] = ()
    snapshot: SourceSnapshot | None = None
    blocked_error: UserError | None = None


@dataclass(frozen=True)
class InboundReference:
    """One surviving reference that points at a delete target."""

    owner_id: str
    path: tuple[str, ...]

    def render(self, target_id: str) -> str:
        """Render this reference in the user-facing blocker format."""
        return f"{self.owner_id} -> {'.'.join(self.path)} -> {target_id}"


@dataclass(frozen=True)
class IdConvention:
    """Detected xref-prefix and width convention for one record kind."""

    prefix: str
    width: int
    next_value: int


def render_write_plan_preview(plan: WritePlan) -> str:
    """Render one write plan as a unified diff or `(no changes)` preview."""
    if plan.blocked_error is not None:
        raise plan.blocked_error
    if not plan.changed or plan.updated_bytes is None:
        return "(no changes)\n"

    current_lines = plan.ged_path.read_bytes().decode("utf-8").splitlines(keepends=True)
    updated_lines = plan.updated_bytes.decode("utf-8").splitlines(keepends=True)
    diff = "".join(
        unified_diff(
            current_lines,
            updated_lines,
            fromfile="(current)",
            tofile=f"(after {plan.operation})",
            n=5,
        )
    )
    if not plan.warnings:
        return diff
    return diff + "\n" + render_write_warnings(plan.warnings)


def render_write_warnings(warnings: tuple[str, ...]) -> str:
    """Render planner warnings for preview/apply command output."""
    if not warnings:
        return ""
    warning_lines = ["warnings:", *warnings, ""]
    return "\n".join(warning_lines)


def supported_add_kinds_text() -> str:
    """Return the canonical user-facing add-kind vocabulary."""
    return ", ".join(CANONICAL_ADD_KINDS)


class WriteService:
    """Apply guarded file-first mutations to GEDCOM documents."""

    def __init__(self, metadata_store: MetadataStore | None = None) -> None:
        """Initialize the write service with optional metadata-store override."""
        self.metadata_store = metadata_store or MetadataStore()

    def add(self, request: AddRequest) -> MutationResult:
        """Create a new GEDCOM entity and atomically replace the source file."""
        return self.apply_plan(self.plan_add(request))

    def edit(self, request: EditRequest) -> MutationResult:
        """Mutate one GEDCOM entity and atomically replace the source file."""
        return self.apply_plan(self.plan_edit(request))

    def delete(self, request: DeleteRequest) -> MutationResult:
        """Delete one GEDCOM entity and atomically replace the source file."""
        return self.apply_plan(self.plan_delete(request))

    def plan_add(self, request: AddRequest) -> WritePlan:
        """Plan a new GEDCOM entity creation without mutating the source file."""
        operation = "add"
        try:
            document, original_bytes, snapshot = self._load_guarded_state(
                request.ged_path,
                cache_base=request.cache_base,
            )
            entity_tag, prefix = _resolve_kind(request.kind)
            entity_id = request.entity_id or _next_entity_id(document, entity_tag, prefix)
            normalized_id = _normalize_id(entity_id)
            if _find_root(document, normalized_id) is not None:
                raise UserError(f"entity already exists: {normalized_id}")

            root = GedNode(
                tag=entity_tag,
                xref=_xref(normalized_id),
                value=None,
                line_indexes=(),
                children=[],
            )
            planned_operations = _plan_mutation_operations(root, request.operations)
            add_groups: dict[str, GedNode] = {}
            for planned_mutation in planned_operations:
                _apply_planned_operation(root, planned_mutation, add_groups=add_groups)

            replacements: dict[str, GedNode | None] = {}
            inserts = [root]
            changed_ids = _dedupe_ids(
                (normalized_id, *_apply_mutation_guards(document, replacements, inserts))
            )
            _refresh_chan_metadata(document, replacements, inserts)
            updated_bytes = _render_updated_bytes(
                document,
                replacements=replacements,
                inserts=inserts,
            )
            return _build_write_plan(
                ged_path=request.ged_path,
                cache_base=request.cache_base,
                operation=operation,
                changed_ids=changed_ids,
                original_bytes=original_bytes,
                updated_bytes=updated_bytes,
                snapshot=snapshot,
            )
        except UserError as error:
            return _blocked_write_plan(
                ged_path=request.ged_path,
                cache_base=request.cache_base,
                operation=operation,
                changed_ids=(),
                error=error,
            )

    def plan_edit(self, request: EditRequest) -> WritePlan:
        """Plan an entity mutation without mutating the source file."""
        operation = "edit"
        normalized_id = _normalize_id(request.entity_id)
        try:
            document, original_bytes, snapshot = self._load_guarded_state(
                request.ged_path,
                cache_base=request.cache_base,
            )
            root = _find_root(document, normalized_id)
            if root is None:
                raise UserError(f"entity not found: {normalized_id}")

            planned_operations = _plan_mutation_operations(root, request.operations)
            updated_root = _clone_node(root)
            add_groups: dict[str, GedNode] = {}
            for planned_mutation in planned_operations:
                _apply_planned_operation(updated_root, planned_mutation, add_groups=add_groups)

            replacements: dict[str, GedNode | None] = {normalized_id: updated_root}
            changed_ids = _dedupe_ids(
                (normalized_id, *_apply_mutation_guards(document, replacements, []))
            )
            _refresh_chan_metadata(document, replacements, [])
            updated_bytes = _render_updated_bytes(
                document,
                replacements=replacements,
                inserts=[],
            )
            return _build_write_plan(
                ged_path=request.ged_path,
                cache_base=request.cache_base,
                operation=operation,
                changed_ids=changed_ids,
                original_bytes=original_bytes,
                updated_bytes=updated_bytes,
                snapshot=snapshot,
                warnings=_duplicate_event_warning_messages(root, updated_root, planned_operations),
            )
        except UserError as error:
            return _blocked_write_plan(
                ged_path=request.ged_path,
                cache_base=request.cache_base,
                operation=operation,
                changed_ids=(normalized_id,),
                error=error,
            )

    def plan_delete(self, request: DeleteRequest) -> WritePlan:
        """Plan an entity deletion without mutating the source file."""
        operation = "delete"
        normalized_id = _normalize_id(request.entity_id)
        try:
            document, original_bytes, snapshot = self._load_guarded_state(
                request.ged_path,
                cache_base=request.cache_base,
            )
            root = _find_root(document, normalized_id)
            if root is None:
                raise UserError(f"entity not found: {normalized_id}")

            inbound_references = _collect_inbound_references(document, normalized_id)
            if inbound_references and not request.cascade:
                raise UserError(_delete_blocked_message(normalized_id, inbound_references))

            replacements: dict[str, GedNode | None] = {normalized_id: None}
            changed_ids: list[str] = [normalized_id]
            if request.cascade:
                for surviving_root in document.roots:
                    if surviving_root.xref is None:
                        continue
                    surviving_id = _normalize_id(surviving_root.xref)
                    if surviving_id == normalized_id:
                        continue
                    updated_root = _clone_node(surviving_root)
                    if not _remove_references_to_entity(updated_root, normalized_id):
                        continue
                    replacements[surviving_id] = updated_root
                    changed_ids.append(surviving_id)

            changed_ids.extend(_apply_mutation_guards(document, replacements, []))
            _refresh_chan_metadata(document, replacements, [])

            updated_bytes = _render_updated_bytes(
                document,
                replacements=replacements,
                inserts=[],
            )
            return _build_write_plan(
                ged_path=request.ged_path,
                cache_base=request.cache_base,
                operation=operation,
                changed_ids=_dedupe_ids(changed_ids),
                original_bytes=original_bytes,
                updated_bytes=updated_bytes,
                snapshot=snapshot,
            )
        except UserError as error:
            return _blocked_write_plan(
                ged_path=request.ged_path,
                cache_base=request.cache_base,
                operation=operation,
                changed_ids=(normalized_id,),
                error=error,
            )

    def apply_plan(self, plan: WritePlan) -> MutationResult:
        """Apply one previously planned write using the exact candidate bytes."""
        if plan.blocked_error is not None:
            raise plan.blocked_error
        if not plan.changed or plan.updated_bytes is None:
            return MutationResult(
                changed_ids=plan.changed_ids,
                cache_dir=cache_dir_for(plan.ged_path, cache_base=plan.cache_base),
                updated_snapshot=SourceSnapshot.capture(plan.ged_path),
                changed_records=plan.changed_records,
                warnings=plan.warnings,
            )
        if plan.snapshot is not None and SourceSnapshot.capture(plan.ged_path) != plan.snapshot:
            raise UserError("file modified externally, reload first")

        write_atomic_bytes(plan.ged_path, plan.updated_bytes)
        updated_snapshot = SourceSnapshot.capture(plan.ged_path)
        self.metadata_store.invalidate(plan.ged_path, cache_base=plan.cache_base)
        return MutationResult(
            changed_ids=plan.changed_ids,
            cache_dir=cache_dir_for(plan.ged_path, cache_base=plan.cache_base),
            updated_snapshot=updated_snapshot,
            changed_records=plan.changed_records,
            warnings=plan.warnings,
        )

    def _load_guarded_document(self, ged_path: Path) -> GedDocument:
        """Load a guarded document for legacy call sites."""
        document, _, _ = self._load_guarded_state(ged_path)
        return document

    def _load_guarded_state(
        self,
        ged_path: Path,
        *,
        cache_base: Path | None = None,
    ) -> tuple[GedDocument, bytes, SourceSnapshot]:
        metadata = self.metadata_store.load(ged_path, cache_base=cache_base)
        current = SourceSnapshot.capture(ged_path)
        if metadata is not None and metadata.snapshot != current:
            raise UserError("file modified externally, reload first")
        document, _ = load_strict_document(ged_path)
        return document, ged_path.read_bytes(), current


def build_operations(
    *,
    set_fields: list[str] | None,
    clear_fields: list[str] | None,
    add_fields: list[str] | None,
    remove_fields: list[str] | None,
) -> tuple[MutationOperation, ...]:
    """Parse CLI mutation flags into the shared mutation model."""
    operations: list[MutationOperation] = []

    for field in set_fields or []:
        operations.append(
            MutationOperation(
                action="set",
                field=_assignment_field(field),
                value=_assignment_value(field),
            )
        )
    for field in clear_fields or []:
        normalized = field.strip()
        if not normalized:
            raise UserError("mutation field cannot be blank")
        operations.append(MutationOperation(action="clear", field=normalized))
    for field in add_fields or []:
        operations.append(
            MutationOperation(
                action="add",
                field=_assignment_field(field),
                value=_assignment_value(field),
            )
        )
    for field in remove_fields or []:
        operations.append(
            MutationOperation(
                action="remove",
                field=_assignment_field(field),
                value=_assignment_value(field),
            )
        )

    return tuple(operations)


def _assignment_field(text: str) -> str:
    field, separator, _ = text.partition("=")
    if separator != "=" or not field.strip():
        raise UserError(f"invalid assignment: {text}")
    return field.strip()


def _assignment_value(text: str) -> str:
    _, separator, value = text.partition("=")
    if separator != "=" or value == "":
        raise UserError(f"invalid assignment: {text}")
    return value


def _resolve_kind(kind: str) -> tuple[str, str]:
    resolved = KIND_TAGS.get(kind.strip().lower())
    if resolved is None:
        raise UserError(
            f"unsupported add kind: {kind}. supported kinds: {supported_add_kinds_text()}"
        )
    return resolved


def _next_entity_id(document: GedDocument, entity_tag: str, default_prefix: str) -> str:
    convention = _detect_id_convention(document, entity_tag, default_prefix)
    return f"{convention.prefix}{convention.next_value:0{convention.width}d}"


def _find_root(document: GedDocument, entity_id: str) -> GedNode | None:
    for root in document.roots:
        if root.xref is not None and _normalize_id(root.xref) == entity_id:
            return root
    return None


def _clone_node(node: GedNode) -> GedNode:
    return GedNode(
        tag=node.tag,
        xref=node.xref,
        value=node.value,
        line_indexes=node.line_indexes,
        children=[_clone_node(child) for child in node.children],
    )


def _apply_operation(
    root: GedNode,
    operation: MutationOperation,
    *,
    add_groups: dict[str, GedNode],
) -> None:
    parent_tag, field_tag, sibling_index, child_sibling_index = _resolve_field(
        root.tag, operation.field
    )
    _apply_planned_operation(
        root,
        PlannedMutationOperation(
            mutation=operation,
            parent_tag=parent_tag,
            field_tag=field_tag,
            sibling_index=sibling_index,
            child_sibling_index=child_sibling_index,
        ),
        add_groups=add_groups,
    )


def _plan_mutation_operations(
    root: GedNode,
    operations: tuple[MutationOperation, ...],
) -> tuple[PlannedMutationOperation, ...]:
    resolved_operations: list[
        tuple[MutationOperation, str | None, str, int | None, int | None]
    ] = []
    grouped_add_parent_tags: set[str] = set()
    parent_add_counts: dict[str, int] = {}
    same_command_parent_add_counts: dict[str, int] = {}

    for operation in operations:
        parent_tag, field_tag, sibling_index, child_sibling_index = _resolve_field(
            root.tag, operation.field
        )
        resolved_operations.append(
            (operation, parent_tag, field_tag, sibling_index, child_sibling_index)
        )

        if operation.action not in {"add", "set"} or sibling_index is not None:
            continue

        if parent_tag is None:
            if not any(child.tag == field_tag for child in root.children):
                same_command_parent_add_counts[field_tag] = (
                    same_command_parent_add_counts.get(field_tag, 0) + 1
                )
            if operation.action != "add":
                continue
            if supports_event_tag(root.tag, field_tag):
                parent_add_counts[field_tag] = parent_add_counts.get(field_tag, 0) + 1
            continue

        if not supports_registered_child_field(root.tag, parent_tag, field_tag):
            grouped_add_parent_tags.add(parent_tag)

    coalescible_parent_tags = {
        parent_tag
        for parent_tag in grouped_add_parent_tags
        if parent_add_counts.get(parent_tag) == 1
    }

    planned_operations: list[PlannedMutationOperation] = []
    for operation, parent_tag, field_tag, sibling_index, child_sibling_index in resolved_operations:
        target_line_indexes: tuple[int, ...] | None = None
        child_target_line_indexes: tuple[int, ...] | None = None
        if sibling_index is not None or child_sibling_index is not None:
            target_line_indexes, child_target_line_indexes = _resolve_indexed_target_line_indexes(
                root,
                operation=operation,
                parent_tag=parent_tag,
                field_tag=field_tag,
                sibling_index=sibling_index,
                child_sibling_index=child_sibling_index,
                same_command_parent_add_counts=same_command_parent_add_counts,
            )
        planned_operations.append(
            PlannedMutationOperation(
                mutation=operation,
                parent_tag=parent_tag,
                field_tag=field_tag,
                sibling_index=sibling_index,
                child_sibling_index=child_sibling_index,
                target_line_indexes=target_line_indexes,
                child_target_line_indexes=child_target_line_indexes,
                coalesce_add_group=(
                    operation.action == "add"
                    and parent_tag is None
                    and sibling_index is None
                    and field_tag in coalescible_parent_tags
                ),
            )
        )
    return tuple(planned_operations)


def _resolve_indexed_target_line_indexes(
    root: GedNode,
    *,
    operation: MutationOperation,
    parent_tag: str | None,
    field_tag: str,
    sibling_index: int | None,
    child_sibling_index: int | None,
    same_command_parent_add_counts: dict[str, int],
) -> tuple[tuple[int, ...] | None, tuple[int, ...] | None]:
    if parent_tag is None:
        if sibling_index is None:
            raise UserError(f"sibling index out of range: {operation.field}")
        matches = [child for child in root.children if child.tag == field_tag]
        selected = _resolve_sibling_position(matches, operation, sibling_index)
        return matches[selected].line_indexes, None

    event_matches = [child for child in root.children if child.tag == parent_tag]
    if sibling_index is not None:
        if sibling_index > len(event_matches):
            if same_command_parent_add_counts.get(parent_tag) == 1:
                raise UserError(_same_command_index_hint(operation.field, parent_tag))
            raise UserError(f"sibling index out of range: {operation.field}")
        selected_event = event_matches[
            _resolve_sibling_position(event_matches, operation, sibling_index)
        ]
    else:
        if len(event_matches) > 1:
            raise UserError(
                f"ambiguous mutation field: {operation.field} requires an explicit sibling index"
            )
        if not event_matches:
            if same_command_parent_add_counts.get(parent_tag) == 1:
                raise UserError(_same_command_index_hint(operation.field, parent_tag))
            raise UserError(f"sibling index out of range: {operation.field}")
        selected_event = event_matches[0]

    if child_sibling_index is None:
        return selected_event.line_indexes, None

    child_matches = [child for child in selected_event.children if child.tag == field_tag]
    selected_child = child_matches[
        _resolve_sibling_position(child_matches, operation, child_sibling_index)
    ]
    return selected_event.line_indexes, selected_child.line_indexes


def _apply_planned_operation(
    root: GedNode,
    planned: PlannedMutationOperation,
    *,
    add_groups: dict[str, GedNode],
) -> None:
    if planned.parent_tag is None:
        if planned.coalesce_add_group:
            _apply_grouped_parent_value_add(root, planned.mutation, planned.field_tag, add_groups)
            return
        _apply_top_level_operation(
            root,
            planned.mutation,
            planned.field_tag,
            planned.sibling_index,
            planned.target_line_indexes,
        )
        return
    _apply_event_operation(
        root,
        planned.mutation,
        planned.parent_tag,
        planned.field_tag,
        planned.sibling_index,
        planned.child_sibling_index,
        add_groups,
        planned.target_line_indexes,
        planned.child_target_line_indexes,
    )


def _resolve_field(owner_kind: str, field: str) -> tuple[str | None, str, int | None, int | None]:
    normalized = field.strip()
    if not normalized:
        raise UserError("mutation field cannot be blank")

    if "." not in normalized:
        tag_name, sibling_index = _split_sibling_selector(normalized, field)
        outward_alias = resolve_record_write_alias(owner_kind, tag_name)
        if outward_alias is not None:
            if (
                sibling_index is None
                and outward_alias.parent_tag == "NAME"
                and outward_alias.field_tag == "NICK"
            ):
                sibling_index = 1
            return outward_alias.parent_tag, outward_alias.field_tag, sibling_index, None
        redirect = record_redirect_message(tag_name)
        if redirect is not None:
            raise UserError(redirect)
        field_tag = _canonical_field_tag(tag_name)
        if owner_kind.strip().upper() == "INDI" and field_tag in PERSONAL_NAME_PIECE_TAGS:
            raise UserError(_flat_name_piece_error(field_tag))
        return None, field_tag, sibling_index, None

    event_name, _, child_name = normalized.partition(".")
    event_token, sibling_index = _split_sibling_selector(event_name, field)
    child_token, child_sibling_index = _split_sibling_selector(child_name, field)

    parent_tag = resolve_registered_parent_alias(owner_kind, event_token)
    if parent_tag is not None:
        child_tag = _canonical_field_tag(child_token)
        if sibling_index is not None and not (
            (owner_kind.strip().upper() == "INDI" and parent_tag == "NAME") or parent_tag == "ASSO"
        ):
            raise UserError(f"unsupported mutation field: {field}")
        if not supports_registered_child_field(owner_kind, parent_tag, child_tag):
            raise UserError(f"unsupported mutation field: {field}")
        return parent_tag, child_tag, sibling_index, child_sibling_index

    event_tag = resolve_event_tag_alias(owner_kind, event_token)
    if event_tag is None and supports_event_tag(owner_kind, event_token):
        event_tag = event_token.strip().upper()
    if event_tag is None or not child_name.strip():
        raise UserError(f"unsupported mutation field: {field}")
    child_alias = resolve_event_child_write_alias(child_token)
    if child_alias is not None:
        return event_tag, child_alias, sibling_index, child_sibling_index
    redirect = event_redirect_message(event_tag, child_token)
    if redirect is not None:
        raise UserError(redirect)
    child_tag = _canonical_field_tag(child_token)
    return event_tag, child_tag, sibling_index, child_sibling_index


def _split_sibling_selector(segment: str, field: str) -> tuple[str, int | None]:
    match = _SIBLING_SELECTOR_PATTERN.fullmatch(segment.strip())
    if match is None:
        raise UserError(f"invalid sibling selector: {field}")
    index = match.group("index")
    return match.group("tag"), None if index is None else int(index)


def _flat_name_piece_error(field_tag: str) -> str:
    return (
        f"{field_tag} is a name piece and cannot be a record-level tag; "
        f"write it under a NAME with 'NAME.{field_tag}=...' "
        f"(or 'NAME[i].{field_tag}=...' to address an existing variant)"
    )


def _same_command_index_hint(field: str, parent_tag: str) -> str:
    _, _, child_path = field.partition(".")
    unindexed_path = parent_tag if not child_path else f"{parent_tag}.{child_path}"
    return (
        f"sibling index out of range: {field} - there is no existing {parent_tag}[1] to address; "
        f"to write under a {parent_tag} created in this same command, use '{unindexed_path}' "
        "(indexes resolve against the record before this edit)"
    )


def _canonical_field_tag(field: str) -> str:
    normalized = field.strip()
    if not normalized:
        raise UserError("mutation field cannot be blank")

    if normalized.startswith("_"):
        return normalized.upper()

    alias = FIELD_TAG_ALIASES.get(normalized.lower())
    if alias is not None:
        return alias

    if normalized.isupper():
        return normalized

    raise UserError(f"unsupported mutation field: {field}")


def _apply_grouped_parent_value_add(
    root: GedNode,
    operation: MutationOperation,
    field_tag: str,
    add_groups: dict[str, GedNode],
) -> None:
    encoded_value = _encode_value(field_tag, operation.value)
    if encoded_value is None:
        raise UserError(f"missing value for {operation.field}")

    grouped_parent = add_groups.get(field_tag)
    if grouped_parent is None:
        grouped_parent = GedNode(field_tag, None, encoded_value, (), [])
        root.children.append(grouped_parent)
        add_groups[field_tag] = grouped_parent
        return

    grouped_parent.value = encoded_value


def _apply_top_level_operation(
    root: GedNode,
    operation: MutationOperation,
    field_tag: str,
    sibling_index: int | None,
    target_line_indexes: tuple[int, ...] | None = None,
) -> None:
    encoded_value = _encode_value(field_tag, operation.value)
    matches = [index for index, child in enumerate(root.children) if child.tag == field_tag]
    selected_index = _resolve_bound_sibling_match(
        root.children,
        field_tag,
        operation,
        sibling_index,
        target_line_indexes,
        matches,
    )

    if operation.action == "set":
        if encoded_value is None:
            raise UserError(f"missing value for {operation.field}")
        existing_children = []
        if selected_index is not None and supports_registered_parent_field(root.tag, field_tag):
            existing_children = [
                _clone_node(child) for child in root.children[selected_index].children
            ]
        replacement = GedNode(
            field_tag,
            None,
            encoded_value,
            () if selected_index is None else root.children[selected_index].line_indexes,
            existing_children,
        )
        if selected_index is not None:
            root.children[selected_index] = replacement
        else:
            root.children.append(replacement)
        return

    if operation.action == "add":
        if encoded_value is None:
            raise UserError(f"missing value for {operation.field}")
        if field_tag in NON_DUPLICATING_FAMILY_LINK_TAGS and any(
            child.tag == field_tag and child.value == encoded_value for child in root.children
        ):
            return
        root.children.append(GedNode(field_tag, None, encoded_value, (), []))
        return

    if operation.action == "clear":
        if selected_index is not None:
            root.children = [
                child for index, child in enumerate(root.children) if index != selected_index
            ]
            return
        root.children = [child for child in root.children if child.tag != field_tag]
        return

    if operation.action == "remove":
        if encoded_value is None:
            raise UserError(f"missing value for {operation.field}")
        if selected_index is not None:
            target = root.children[selected_index]
            if target.tag == field_tag and _logical_node_value(target) == encoded_value:
                root.children = [
                    child for index, child in enumerate(root.children) if index != selected_index
                ]
            return
        root.children = [
            child
            for child in root.children
            if not (child.tag == field_tag and _logical_node_value(child) == encoded_value)
        ]
        return

    raise UserError(f"unsupported mutation action: {operation.action}")


def _apply_event_operation(
    root: GedNode,
    operation: MutationOperation,
    parent_tag: str,
    field_tag: str,
    sibling_index: int | None,
    child_sibling_index: int | None,
    add_groups: dict[str, GedNode],
    target_line_indexes: tuple[int, ...] | None = None,
    child_target_line_indexes: tuple[int, ...] | None = None,
) -> None:
    event_matches = [child for child in root.children if child.tag == parent_tag]
    event: GedNode | None = None
    registered_child_path = supports_registered_child_field(root.tag, parent_tag, field_tag)

    if target_line_indexes is not None:
        event = _find_bound_sibling(root.children, parent_tag, target_line_indexes)
        if event is None:
            return
    elif sibling_index is not None:
        event = event_matches[_resolve_sibling_position(event_matches, operation, sibling_index)]
    elif operation.action == "add":
        if registered_child_path:
            if len(event_matches) > 1:
                raise UserError(
                    "ambiguous mutation field: "
                    f"{operation.field} requires an explicit sibling index"
                )
            if event_matches:
                event = event_matches[0]
            else:
                event = GedNode(parent_tag, None, None, (), [])
                root.children.append(event)
        else:
            event = add_groups.get(parent_tag)
            if event is None:
                event = GedNode(parent_tag, None, None, (), [])
                root.children.append(event)
                add_groups[parent_tag] = event
    else:
        if len(event_matches) > 1:
            raise UserError(
                f"ambiguous mutation field: {operation.field} requires an explicit sibling index"
            )
        if event_matches:
            event = event_matches[0]
        elif operation.action == "set":
            event = GedNode(parent_tag, None, None, (), [])
            root.children.append(event)
        else:
            return

    encoded_value = _encode_value(field_tag, operation.value)
    matches = [index for index, child in enumerate(event.children) if child.tag == field_tag]
    selected_index: int | None = None
    if child_sibling_index is not None or child_target_line_indexes is not None:
        selected_index = _resolve_bound_sibling_match(
            event.children,
            field_tag,
            operation,
            child_sibling_index,
            child_target_line_indexes,
            matches,
        )
    elif operation.action != "remove":
        selected_index = _resolve_bound_sibling_match(
            event.children,
            field_tag,
            operation,
            child_sibling_index,
            child_target_line_indexes,
            matches,
        )

    if operation.action == "set":
        if encoded_value is None:
            raise UserError(f"missing value for {operation.field}")
        replacement = GedNode(
            field_tag,
            None,
            encoded_value,
            () if selected_index is None else event.children[selected_index].line_indexes,
            [],
        )
        if selected_index is not None:
            event.children[selected_index] = replacement
        else:
            event.children.append(replacement)
    elif operation.action == "add":
        if encoded_value is None:
            raise UserError(f"missing value for {operation.field}")
        event.children.append(GedNode(field_tag, None, encoded_value, (), []))
    elif operation.action == "clear":
        if selected_index is not None:
            event.children = [
                child for index, child in enumerate(event.children) if index != selected_index
            ]
        else:
            event.children = [child for child in event.children if child.tag != field_tag]
    elif operation.action == "remove":
        if encoded_value is None:
            raise UserError(f"missing value for {operation.field}")
        if selected_index is not None:
            target = event.children[selected_index]
            if target.tag == field_tag and _logical_node_value(target) == encoded_value:
                event.children = [
                    child for index, child in enumerate(event.children) if index != selected_index
                ]
        else:
            event.children = [
                child
                for child in event.children
                if not (child.tag == field_tag and _logical_node_value(child) == encoded_value)
            ]
    else:
        raise UserError(f"unsupported mutation action: {operation.action}")

    if not event.children and event.value is None:
        root.children = [child for child in root.children if child is not event]


def _resolve_sibling_match(
    matches: list[int],
    operation: MutationOperation,
    sibling_index: int | None,
) -> int | None:
    if sibling_index is not None:
        if sibling_index > len(matches):
            raise UserError(f"sibling index out of range: {operation.field}")
        return matches[sibling_index - 1]

    if operation.action in {"set", "clear", "remove"} and len(matches) > 1:
        raise UserError(
            f"ambiguous mutation field: {operation.field} requires an explicit sibling index"
        )

    if matches:
        return matches[0]
    return None


def _resolve_bound_sibling_match(
    children: list[GedNode],
    field_tag: str,
    operation: MutationOperation,
    sibling_index: int | None,
    target_line_indexes: tuple[int, ...] | None,
    matches: list[int],
) -> int | None:
    if target_line_indexes is not None:
        bound_match = _find_bound_sibling(children, field_tag, target_line_indexes)
        if bound_match is None:
            return None
        return children.index(bound_match)
    return _resolve_sibling_match(matches, operation, sibling_index)


def _find_bound_sibling(
    children: list[GedNode],
    field_tag: str,
    target_line_indexes: tuple[int, ...],
) -> GedNode | None:
    for child in children:
        if child.tag == field_tag and child.line_indexes == target_line_indexes:
            return child
    return None


def _resolve_sibling_position(
    matches: list[GedNode],
    operation: MutationOperation,
    sibling_index: int,
) -> int:
    if sibling_index > len(matches):
        raise UserError(f"sibling index out of range: {operation.field}")
    return sibling_index - 1


def _encode_value(field_tag: str, value: str | None) -> bytes | None:
    if value is None:
        return None
    if field_tag in REFERENCE_TAGS:
        normalized = _normalize_id(value)
        return _xref(normalized).encode("utf-8")
    return value.encode("utf-8")


def _logical_node_value(node: GedNode) -> bytes | None:
    value = node.value
    for child in node.children:
        if child.tag == "CONC":
            value = (value or b"") + (child.value or b"")
        elif child.tag == "CONT":
            if value is None:
                value = child.value or b""
            else:
                value = value + b"\n" + (child.value or b"")
    return value


def _render_updated_bytes(
    document: GedDocument,
    *,
    replacements: dict[str, GedNode | None],
    inserts: list[GedNode],
) -> bytes:
    eol = _default_eol(document)
    chunks: list[bytes] = []
    inserted = False

    for root in document.roots:
        if root.tag == "TRLR" and inserts and not inserted:
            chunks.extend(_render_node_chunk(node, eol) for node in inserts)
            inserted = True

        if root.xref is None:
            chunks.append(_original_root_chunk(document, root))
            continue

        normalized_id = _normalize_id(root.xref)
        if normalized_id not in replacements:
            chunks.append(_original_root_chunk(document, root))
            continue

        replacement = replacements[normalized_id]
        if replacement is not None:
            chunks.append(_render_node_chunk(replacement, eol))

    if inserts and not inserted:
        chunks.extend(_render_node_chunk(node, eol) for node in inserts)

    return b"".join(chunks)


def _build_write_plan(
    *,
    ged_path: Path,
    cache_base: Path | None,
    operation: str,
    changed_ids: tuple[str, ...],
    original_bytes: bytes,
    updated_bytes: bytes,
    snapshot: SourceSnapshot,
    warnings: tuple[str, ...] = (),
) -> WritePlan:
    original_document = parse_document(original_bytes)
    updated_document = parse_document(updated_bytes)
    combined_warnings = (
        *warnings,
        *_dangling_warning_messages(original_document, updated_document),
    )
    return WritePlan(
        ged_path=ged_path,
        cache_base=cache_base,
        operation=operation,
        changed_ids=changed_ids,
        changed_records=_changed_records_for_ids(
            original_document,
            updated_document,
            changed_ids,
        ),
        updated_bytes=updated_bytes,
        changed=updated_bytes != original_bytes,
        warnings=combined_warnings,
        snapshot=snapshot,
    )


def _blocked_write_plan(
    *,
    ged_path: Path,
    cache_base: Path | None,
    operation: str,
    changed_ids: tuple[str, ...],
    error: UserError,
) -> WritePlan:
    return WritePlan(
        ged_path=ged_path,
        cache_base=cache_base,
        operation=operation,
        changed_ids=changed_ids,
        changed_records=(),
        updated_bytes=None,
        changed=False,
        blocked_error=error,
    )


def _changed_records_for_ids(
    original_document: GedDocument,
    updated_document: GedDocument,
    changed_ids: tuple[str, ...],
) -> tuple[ChangedRecord, ...]:
    changed_records: list[ChangedRecord] = []
    for entity_id in changed_ids:
        updated_root = _find_root(updated_document, entity_id)
        original_root = _find_root(original_document, entity_id)
        root = updated_root or original_root
        if root is None:
            continue
        changed_records.append(
            ChangedRecord(
                entity_id=entity_id,
                kind=root.tag,
                action="upsert" if updated_root is not None else "delete",
            )
        )
    return tuple(changed_records)


def _dangling_warning_messages(
    original_document: GedDocument,
    updated_document: GedDocument,
) -> tuple[str, ...]:
    original_messages = set(_dangling_messages_for_document(original_document))
    updated_messages = _dangling_messages_for_document(updated_document)
    return tuple(message for message in updated_messages if message not in original_messages)


def _duplicate_event_warning_messages(
    original_root: GedNode,
    updated_root: GedNode,
    planned_operations: tuple[PlannedMutationOperation, ...],
) -> tuple[str, ...]:
    warning_fields_by_tag: dict[str, str] = {}
    original_counts = Counter(child.tag for child in original_root.children)

    for planned in planned_operations:
        if planned.mutation.action != "add" or planned.parent_tag is None:
            continue
        if planned.sibling_index is not None:
            continue
        if supports_registered_child_field(
            original_root.tag,
            planned.parent_tag,
            planned.field_tag,
        ):
            continue
        if original_counts[planned.parent_tag] == 0:
            continue
        warning_fields_by_tag.setdefault(planned.parent_tag, planned.mutation.field)

    warnings: list[str] = []
    for parent_tag, field in warning_fields_by_tag.items():
        original_count = original_counts[parent_tag]
        updated_matches = [child for child in updated_root.children if child.tag == parent_tag]
        if len(updated_matches) <= original_count:
            continue
        added_matches = updated_matches[original_count:]
        if any(_is_hazardous_duplicate_event(event) for event in added_matches):
            warnings.append(
                "bare add "
                f"{field} created a new {parent_tag} sibling without line value, DATE, or PLAC; "
                f"use {_indexed_field(parent_tag, field, original_count + 1)} "
                "to target it explicitly "
                f"if a new {parent_tag} structure is intentional"
            )
    return tuple(warnings)


def _is_hazardous_duplicate_event(event: GedNode) -> bool:
    return (
        event.value is None
        and not any(child.tag == "DATE" for child in event.children)
        and not any(child.tag == "PLAC" for child in event.children)
    )


def _indexed_field(parent_tag: str, field: str, index: int) -> str:
    _, separator, child_path = field.partition(".")
    if separator != ".":
        return f"{parent_tag}[{index}]"
    return f"{parent_tag}[{index}].{child_path}"


def _collect_inbound_references(
    document: GedDocument,
    target_id: str,
) -> tuple[InboundReference, ...]:
    references: list[InboundReference] = []
    for root in document.roots:
        if root.xref is None:
            continue
        owner_id = _normalize_id(root.xref)
        if owner_id == target_id:
            continue
        references.extend(_collect_node_inbound_references(root, owner_id, target_id, path=()))
    return tuple(references)


def _collect_node_inbound_references(
    node: GedNode,
    owner_id: str,
    target_id: str,
    *,
    path: tuple[str, ...],
) -> list[InboundReference]:
    references: list[InboundReference] = []
    for child in node.children:
        child_path = (*path, child.tag)
        if _reference_value(child.value) == target_id:
            references.append(InboundReference(owner_id=owner_id, path=child_path))
        references.extend(
            _collect_node_inbound_references(child, owner_id, target_id, path=child_path)
        )
    return references


def _delete_blocked_message(target_id: str, references: tuple[InboundReference, ...]) -> str:
    lines = [f"delete blocked by inbound references to {target_id}:"]
    lines.extend(f"- {reference.render(target_id)}" for reference in references)
    return "\n".join(lines)


def _apply_mutation_guards(
    document: GedDocument,
    replacements: dict[str, GedNode | None],
    inserts: list[GedNode],
) -> tuple[str, ...]:
    candidate = _materialize_candidate_document(document, replacements, inserts)
    _raise_on_new_missing_pointer_targets(document, candidate)
    synchronized_ids = _synchronize_reciprocal_family_links(document, replacements, inserts)
    if synchronized_ids:
        candidate = _materialize_candidate_document(document, replacements, inserts)
        _raise_on_new_missing_pointer_targets(document, candidate)
    return synchronized_ids


def _materialize_candidate_document(
    document: GedDocument,
    replacements: dict[str, GedNode | None],
    inserts: list[GedNode],
) -> GedDocument:
    roots: list[GedNode] = []
    inserted = False

    for root in document.roots:
        if root.tag == "TRLR" and inserts and not inserted:
            roots.extend(inserts)
            inserted = True

        if root.xref is None:
            roots.append(root)
            continue

        normalized_id = _normalize_id(root.xref)
        if normalized_id not in replacements:
            roots.append(root)
            continue

        replacement = replacements[normalized_id]
        if replacement is not None:
            roots.append(replacement)

    if inserts and not inserted:
        roots.extend(inserts)

    return GedDocument(lines=document.lines, roots=tuple(roots))


def _raise_on_new_missing_pointer_targets(
    original_document: GedDocument,
    updated_document: GedDocument,
) -> None:
    messages = _new_missing_pointer_messages(original_document, updated_document)
    if not messages:
        return
    lines = ["write blocked by missing pointer targets:"]
    lines.extend(f"- {message}" for message in messages)
    raise UserError("\n".join(lines))


def _new_missing_pointer_messages(
    original_document: GedDocument,
    updated_document: GedDocument,
) -> tuple[str, ...]:
    original_messages = set(_dangling_pointer_messages_for_document(original_document))
    updated_messages = _dangling_pointer_messages_for_document(updated_document)
    return tuple(message for message in updated_messages if message not in original_messages)


def _dangling_pointer_messages_for_document(document: GedDocument) -> tuple[str, ...]:
    known_ids = {_normalize_id(root.xref) for root in document.roots if root.xref is not None}
    messages: list[str] = []
    for root in document.roots:
        if root.xref is None:
            continue
        owner_id = _normalize_id(root.xref)
        messages.extend(_collect_missing_pointer_messages(root, owner_id, known_ids, path=()))
    return tuple(messages)


def _collect_missing_pointer_messages(
    node: GedNode,
    owner_id: str,
    known_ids: set[str],
    *,
    path: tuple[str, ...],
) -> list[str]:
    messages: list[str] = []
    for child in node.children:
        child_path = (*path, child.tag)
        reference = _reference_value(child.value)
        if reference is not None and reference not in known_ids:
            messages.append(f"{owner_id} -> {'.'.join(child_path)} -> {reference}")
        messages.extend(
            _collect_missing_pointer_messages(child, owner_id, known_ids, path=child_path)
        )
    return messages


def _synchronize_reciprocal_family_links(
    document: GedDocument,
    replacements: dict[str, GedNode | None],
    inserts: list[GedNode],
) -> tuple[str, ...]:
    candidate = _materialize_candidate_document(document, replacements, inserts)
    affected_family_ids = _affected_family_ids(document, replacements, inserts)
    affected_person_ids = _affected_person_ids(document, replacements, inserts)
    if not affected_family_ids and not affected_person_ids:
        return ()

    roots_by_id = {
        _normalize_id(root.xref): root for root in candidate.roots if root.xref is not None
    }
    synchronized_ids: list[str] = []

    for family_id in affected_family_ids:
        family_root = roots_by_id.get(family_id)
        desired_spouse_ids = set(_family_reference_targets(family_root, {"HUSB", "WIFE"}))
        desired_child_ids = set(_family_reference_targets(family_root, {"CHIL"}))
        actual_spouse_ids, actual_child_ids = _person_family_links(candidate, family_id)

        for person_id in sorted(actual_spouse_ids | desired_spouse_ids):
            person_root = _ensure_mutable_root(document, replacements, inserts, person_id)
            if person_root is None:
                continue
            if _sync_person_family_link(
                person_root,
                "FAMS",
                family_id,
                person_id in desired_spouse_ids,
            ):
                synchronized_ids.append(person_id)

        for person_id in sorted(actual_child_ids | desired_child_ids):
            person_root = _ensure_mutable_root(document, replacements, inserts, person_id)
            if person_root is None:
                continue
            if _sync_person_family_link(
                person_root,
                "FAMC",
                family_id,
                person_id in desired_child_ids,
            ):
                synchronized_ids.append(person_id)

    for person_id in affected_person_ids:
        updated_person = roots_by_id.get(person_id)
        if updated_person is None or updated_person.tag != "INDI":
            continue
        original_person = _find_root(document, person_id)
        original_spouse_ids, original_child_ids = _family_links_for_person(original_person)
        desired_spouse_ids, desired_child_ids = _family_links_for_person(updated_person)

        for family_id in sorted(original_child_ids | desired_child_ids):
            family_root = _ensure_mutable_root(document, replacements, inserts, family_id)
            if family_root is None:
                continue
            if _sync_family_member_link(
                family_root,
                "CHIL",
                person_id,
                family_id in desired_child_ids,
            ):
                synchronized_ids.append(family_id)

        for family_id in sorted(original_spouse_ids | desired_spouse_ids):
            family_root = _ensure_mutable_root(document, replacements, inserts, family_id)
            if family_root is None:
                continue
            if family_id in desired_spouse_ids:
                role_tag = _family_spouse_role_for_person(updated_person)
                changed = _sync_family_spouse_role(family_root, person_id, role_tag)
            else:
                changed = _remove_family_spouse_links(family_root, person_id)
            if changed:
                synchronized_ids.append(family_id)

    return tuple(synchronized_ids)


def _affected_family_ids(
    document: GedDocument,
    replacements: dict[str, GedNode | None],
    inserts: list[GedNode],
) -> set[str]:
    family_ids = {
        _normalize_id(root.xref) for root in inserts if root.xref is not None and root.tag == "FAM"
    }

    for entity_id, root in replacements.items():
        if root is not None:
            if root.tag == "FAM":
                family_ids.add(entity_id)
            continue
        original_root = _find_root(document, entity_id)
        if original_root is not None and original_root.tag == "FAM":
            family_ids.add(entity_id)

    return family_ids


def _affected_person_ids(
    document: GedDocument,
    replacements: dict[str, GedNode | None],
    inserts: list[GedNode],
) -> set[str]:
    person_ids = {
        _normalize_id(root.xref) for root in inserts if root.xref is not None and root.tag == "INDI"
    }

    for entity_id, root in replacements.items():
        if root is not None:
            if root.tag == "INDI":
                person_ids.add(entity_id)
            continue
        original_root = _find_root(document, entity_id)
        if original_root is not None and original_root.tag == "INDI":
            person_ids.add(entity_id)

    return person_ids


def _family_reference_targets(root: GedNode | None, tags: set[str]) -> tuple[str, ...]:
    if root is None:
        return ()
    targets: list[str] = []
    for child in root.children:
        if child.tag not in tags:
            continue
        reference = _reference_value(child.value)
        if reference is not None:
            targets.append(reference)
    return tuple(targets)


def _person_family_links(candidate: GedDocument, family_id: str) -> tuple[set[str], set[str]]:
    spouse_ids: set[str] = set()
    child_ids: set[str] = set()
    family_xref = _xref(family_id).encode("utf-8")

    for root in candidate.roots:
        if root.xref is None or root.tag != "INDI":
            continue
        owner_id = _normalize_id(root.xref)
        for child in root.children:
            if child.tag == "FAMS" and child.value == family_xref:
                spouse_ids.add(owner_id)
            if child.tag == "FAMC" and child.value == family_xref:
                child_ids.add(owner_id)

    return spouse_ids, child_ids


def _family_links_for_person(root: GedNode | None) -> tuple[set[str], set[str]]:
    if root is None or root.tag != "INDI":
        return set(), set()

    spouse_ids: set[str] = set()
    child_ids: set[str] = set()
    for child in root.children:
        reference = _reference_value(child.value)
        if reference is None:
            continue
        if child.tag == "FAMS":
            spouse_ids.add(reference)
        if child.tag == "FAMC":
            child_ids.add(reference)
    return spouse_ids, child_ids


def _ensure_mutable_root(
    document: GedDocument,
    replacements: dict[str, GedNode | None],
    inserts: list[GedNode],
    entity_id: str,
) -> GedNode | None:
    if entity_id in replacements:
        return replacements[entity_id]

    for root in inserts:
        if root.xref is not None and _normalize_id(root.xref) == entity_id:
            return root

    original_root = _find_root(document, entity_id)
    if original_root is None:
        return None
    replacement = _clone_node(original_root)
    replacements[entity_id] = replacement
    return replacement


def _sync_person_family_link(root: GedNode, tag: str, family_id: str, should_have: bool) -> bool:
    family_xref = _xref(family_id).encode("utf-8")
    matches = [child for child in root.children if child.tag == tag and child.value == family_xref]

    if should_have:
        if matches:
            return False
        root.children.append(
            GedNode(tag=tag, xref=None, value=family_xref, line_indexes=(), children=[])
        )
        return True

    if not matches:
        return False
    root.children = [
        child for child in root.children if not (child.tag == tag and child.value == family_xref)
    ]
    return True


def _sync_family_member_link(root: GedNode, tag: str, entity_id: str, should_have: bool) -> bool:
    entity_xref = _xref(entity_id).encode("utf-8")
    matches = [child for child in root.children if child.tag == tag and child.value == entity_xref]

    if should_have:
        if matches:
            return False
        root.children.append(
            GedNode(tag=tag, xref=None, value=entity_xref, line_indexes=(), children=[])
        )
        return True

    if not matches:
        return False
    root.children = [
        child for child in root.children if not (child.tag == tag and child.value == entity_xref)
    ]
    return True


def _family_spouse_role_for_person(root: GedNode) -> str:
    for child in root.children:
        if child.tag != "SEX" or child.value is None:
            continue
        sex = child.value.decode("utf-8").strip().upper()
        if sex == "M":
            return "HUSB"
        if sex == "F":
            return "WIFE"
        break
    raise UserError(
        "FAMS on an individual requires a definite SEX; use the family-side HUSB/WIFE form instead"
    )


def _sync_family_spouse_role(root: GedNode, entity_id: str, role_tag: str) -> bool:
    entity_xref = _xref(entity_id).encode("utf-8")
    opposite_tag = "WIFE" if role_tag == "HUSB" else "HUSB"
    changed = False
    if not any(child.tag == role_tag and child.value == entity_xref for child in root.children):
        root.children.append(
            GedNode(tag=role_tag, xref=None, value=entity_xref, line_indexes=(), children=[])
        )
        changed = True
    filtered_children = [
        child
        for child in root.children
        if not (child.tag == opposite_tag and child.value == entity_xref)
    ]
    if len(filtered_children) != len(root.children):
        changed = True
        root.children = filtered_children
    return changed


def _remove_family_spouse_links(root: GedNode, entity_id: str) -> bool:
    entity_xref = _xref(entity_id).encode("utf-8")
    filtered_children = [
        child
        for child in root.children
        if not (child.tag in {"HUSB", "WIFE"} and child.value == entity_xref)
    ]
    if len(filtered_children) == len(root.children):
        return False
    root.children = filtered_children
    return True


def _dedupe_ids(entity_ids: list[str] | tuple[str, ...]) -> tuple[str, ...]:
    return tuple(dict.fromkeys(entity_ids))


def _detect_id_convention(
    document: GedDocument,
    entity_tag: str,
    default_prefix: str,
) -> IdConvention:
    matched_ids: list[tuple[str, str]] = []
    for root in document.roots:
        if root.tag != entity_tag or root.xref is None:
            continue
        match = re.match(r"^([^0-9]+)(\d+)$", _normalize_id(root.xref))
        if match is None:
            continue
        matched_ids.append((match.group(1), match.group(2)))

    if not matched_ids:
        return IdConvention(prefix=default_prefix, width=1, next_value=1)

    prefix_counts = Counter(prefix for prefix, _ in matched_ids)
    dominant_prefix = max(prefix_counts, key=lambda prefix: (prefix_counts[prefix], prefix))
    digits_for_prefix = [digits for prefix, digits in matched_ids if prefix == dominant_prefix]
    width_counts = Counter(len(digits) for digits in digits_for_prefix)
    width = max(width_counts, key=lambda value: (width_counts[value], value))
    next_value = max(int(digits) for digits in digits_for_prefix) + 1
    return IdConvention(prefix=dominant_prefix, width=width, next_value=next_value)


def _refresh_chan_metadata(
    document: GedDocument,
    replacements: dict[str, GedNode | None],
    inserts: list[GedNode],
) -> None:
    changed_ids = _materially_changed_ids(document, replacements, inserts)
    if not changed_ids:
        return

    timestamp = datetime.now().astimezone()
    for entity_id in changed_ids:
        root = _ensure_mutable_root(document, replacements, inserts, entity_id)
        if root is None:
            continue
        _set_chan_block(root, timestamp)


def _materially_changed_ids(
    document: GedDocument,
    replacements: dict[str, GedNode | None],
    inserts: list[GedNode],
) -> tuple[str, ...]:
    eol = _default_eol(document)
    changed_ids = [_normalize_id(root.xref) for root in inserts if root.xref is not None]

    for entity_id, replacement in replacements.items():
        if replacement is None:
            continue
        original_root = _find_root(document, entity_id)
        if original_root is None:
            changed_ids.append(entity_id)
            continue
        if _render_node_chunk(replacement, eol) != _original_root_chunk(document, original_root):
            changed_ids.append(entity_id)

    return _dedupe_ids(changed_ids)


def _set_chan_block(root: GedNode, timestamp: datetime) -> None:
    chan_node = GedNode(
        tag="CHAN",
        xref=None,
        value=None,
        line_indexes=(),
        children=[
            GedNode(
                tag="DATE",
                xref=None,
                value=_format_chan_date(timestamp).encode("utf-8"),
                line_indexes=(),
                children=[
                    GedNode(
                        tag="TIME",
                        xref=None,
                        value=timestamp.strftime("%H:%M:%S").encode("utf-8"),
                        line_indexes=(),
                        children=[],
                    )
                ],
            )
        ],
    )
    root.children = [child for child in root.children if child.tag != "CHAN"]
    root.children.append(chan_node)


def _format_chan_date(timestamp: datetime) -> str:
    month = (
        "JAN",
        "FEB",
        "MAR",
        "APR",
        "MAY",
        "JUN",
        "JUL",
        "AUG",
        "SEP",
        "OCT",
        "NOV",
        "DEC",
    )[timestamp.month - 1]
    return f"{timestamp.day:02d} {month} {timestamp.year:04d}"


def _remove_references_to_entity(node: GedNode, target_id: str) -> bool:
    changed = False
    updated_children: list[GedNode] = []

    for child in node.children:
        if _reference_value(child.value) == target_id:
            changed = True
            continue

        child_changed = _remove_references_to_entity(child, target_id)
        if child_changed:
            changed = True
            if child.value is None and not child.children:
                continue

        updated_children.append(child)

    node.children = updated_children
    return changed


def _dangling_messages_for_document(document: GedDocument) -> list[str]:
    messages: list[str] = []
    known_ids = {_normalize_id(root.xref) for root in document.roots if root.xref is not None}

    for root in document.roots:
        if root.xref is None:
            continue
        owner_id = _normalize_id(root.xref)
        for child in root.children:
            reference = _reference_value(child.value)
            if reference is not None and reference not in known_ids:
                messages.append(f"dangling ref: {owner_id} -> {child.tag} -> {reference}")
            for grandchild in child.children:
                nested_reference = _reference_value(grandchild.value)
                if nested_reference is not None and nested_reference not in known_ids:
                    messages.append(
                        f"dangling ref: {owner_id} -> {child.tag}.{grandchild.tag} -> "
                        f"{nested_reference}"
                    )

    projection = project_document(document)
    known_projection_ids = {
        record.entity_id for record in projection.records if record.entity_id is not None
    }
    seen_note_refs: set[tuple[str, str, str]] = set()
    for record in projection.records:
        if record.entity_id is None:
            continue
        owner_id = _normalize_id(record.entity_id)
        for event in record.events:
            for note_ref in event.note_refs:
                if note_ref in known_projection_ids:
                    continue
                normalized_ref = _normalize_id(note_ref)
                key = (owner_id, event.tag, normalized_ref)
                if key in seen_note_refs:
                    continue
                seen_note_refs.add(key)
                messages.append(f"dangling ref: {owner_id} -> {event.tag}.NOTE -> {normalized_ref}")

    return messages


def _reference_value(value: bytes | None) -> str | None:
    if value is None:
        return None
    text = value.decode("utf-8").strip()
    if len(text) >= 3 and text.startswith("@") and text.endswith("@"):
        return _normalize_id(text)
    return None


def _original_root_chunk(document: GedDocument, root: GedNode) -> bytes:
    return b"".join(
        document.lines[index].raw + document.lines[index].eol
        for index in sorted(_collect_line_indexes(root))
    )


def _collect_line_indexes(node: GedNode) -> set[int]:
    indexes = set(node.line_indexes)
    for child in node.children:
        indexes.update(_collect_line_indexes(child))
    return indexes


def _render_node_chunk(node: GedNode, eol: bytes) -> bytes:
    return b"".join(_render_node_lines(node, level=0, eol=eol))


def _render_node_lines(node: GedNode, *, level: int, eol: bytes) -> list[bytes]:
    rendered = [
        _render_line(render_level, render_xref, render_tag, render_value, eol)
        for render_level, render_xref, render_tag, render_value in _wrapped_value_lines(node, level)
    ]
    for child in node.children:
        rendered.extend(_render_node_lines(child, level=level + 1, eol=eol))
    return rendered


def _wrapped_value_lines(
    node: GedNode,
    level: int,
) -> list[tuple[int, str | None, str, bytes | None]]:
    if node.value is None:
        return [(level, node.xref, node.tag, None)]

    text = _normalized_text_value(node.tag, node.value)
    logical_segments = text.split("\n")
    wrapped: list[tuple[int, str | None, str, bytes | None]] = []

    for index, segment in enumerate(logical_segments):
        line_level = level if index == 0 else level + 1
        line_xref = node.xref if index == 0 else None
        line_tag = node.tag if index == 0 else "CONT"
        chunks = _chunk_text_for_line(segment, level=line_level, xref=line_xref, tag=line_tag)
        wrapped.append((line_level, line_xref, line_tag, chunks[0]))
        for extra_chunk in chunks[1:]:
            wrapped.append((level + 1, None, "CONC", extra_chunk))

    return wrapped


def _render_line(
    level: int,
    xref: str | None,
    tag: str,
    value: bytes | None,
    eol: bytes,
) -> bytes:
    parts = [str(level).encode("ascii")]
    if xref is not None:
        parts.extend((b" ", xref.encode("ascii")))
    parts.extend((b" ", tag.encode("ascii")))
    if value is not None and value != b"":
        parts.extend((b" ", value))
    return b"".join(parts) + eol


def _normalized_text_value(tag: str, value: bytes) -> str:
    text = value.decode("utf-8")
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    for character in text:
        if ord(character) < 32 and character != "\n":
            raise UserError(f"unsafe control character in value for {tag}")
    return text


def _chunk_text_for_line(
    text: str,
    *,
    level: int,
    xref: str | None,
    tag: str,
) -> tuple[bytes, ...]:
    if text == "":
        return (b"",)

    first_chunk, remaining = _take_text_chunk(
        text,
        _max_value_bytes(level=level, xref=xref, tag=tag),
        tag=tag,
    )
    chunks = [first_chunk.encode("utf-8")]

    while remaining:
        next_chunk, remaining = _take_text_chunk(
            remaining,
            _max_value_bytes(level=level + 1, xref=None, tag="CONC"),
            tag="CONC",
        )
        chunks.append(next_chunk.encode("utf-8"))

    return tuple(chunks)


def _max_value_bytes(*, level: int, xref: str | None, tag: str) -> int:
    prefix = _render_line_prefix(level, xref, tag)
    return 255 - len(prefix) - 1


def _render_line_prefix(level: int, xref: str | None, tag: str) -> bytes:
    parts = [str(level).encode("ascii")]
    if xref is not None:
        parts.extend((b" ", xref.encode("ascii")))
    parts.extend((b" ", tag.encode("ascii")))
    return b"".join(parts)


def _take_text_chunk(text: str, limit: int, *, tag: str) -> tuple[str, str]:
    if limit <= 0:
        raise UserError(f"value too long to encode for {tag}")

    current: list[str] = []
    current_width = 0
    for index, character in enumerate(text):
        character_width = len(character.encode("utf-8"))
        if current_width + character_width > limit:
            if not current:
                raise UserError(f"value too long to encode for {tag}")
            return "".join(current), text[index:]
        current.append(character)
        current_width += character_width

    return "".join(current), ""


def _default_eol(document: GedDocument) -> bytes:
    for line in document.lines:
        if line.eol:
            return line.eol
    return b"\n"


def _normalize_id(entity_id: str) -> str:
    return normalize_entity_id(entity_id)


def _xref(entity_id: str) -> str:
    return canonical_entity_xref(entity_id)
