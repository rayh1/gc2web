"""Aggregate report helpers for the analyze command."""

from __future__ import annotations

from collections import Counter, defaultdict, deque
from dataclasses import dataclass
from typing import Any

from gedq.config import Settings
from gedq.errors import UserError
from gedq.model.entity_ids import normalize_entity_id
from gedq.model.records import EntityRecord
from gedq.parser.projection import Projection
from gedq.query.properties import build_record_raw_fields
from gedq.service.validate import _collect_unsourced_event_issues, load_strict_document
from gedq.storage.ladybug_index import QueryHandle, query_rows_as_dicts

REPORTS = ("census", "coverage", "structure", "duplicates")


@dataclass(frozen=True)
class _PersonSummary:
    entity_id: str
    surname: str | None
    birth_year: int | None
    parents: frozenset[str]


def parse_report_selection(raw: str | None) -> tuple[str, ...]:
    """Normalize the outward `--report` selection."""
    if raw is None:
        return ("census", "coverage")
    parts = tuple(part.strip().lower() for part in raw.split(",") if part.strip())
    if not parts:
        raise UserError("--report requires one or more report names")
    invalid = [part for part in parts if part not in REPORTS]
    if invalid:
        valid_reports = ", ".join(REPORTS)
        raise UserError(
            f"unsupported analyze report(s): {', '.join(invalid)}; "
            f"valid reports: {valid_reports}"
        )
    return tuple(dict.fromkeys(parts))


def analyze_file(handle: QueryHandle, reports: tuple[str, ...]) -> dict[str, object]:
    """Build the selected aggregate reports for one GEDCOM file."""
    _, projection = load_strict_document(handle.source_path)
    builders = {
        "census": lambda: _build_census_report(projection),
        "coverage": lambda: _build_coverage_report(handle, projection),
        "structure": lambda: _build_structure_report(projection),
        "duplicates": lambda: _build_duplicates_report(projection),
    }
    return {name: builders[name]() for name in reports}


def format_analyze_reports(payload: dict[str, object]) -> str:
    """Render analyze results in the outward human-readable format."""
    sections: list[str] = []
    if "census" in payload:
        census = payload["census"]
        if isinstance(census, dict):
            entity_bits = "  ".join(
                f"{kind} {count}" for kind, count in sorted(_dict(census, "entities").items())
            )
            event_total = int(_dict(census, "events").get("total", 0))
            by_tag = ", ".join(
                f"{tag} {count}"
                for tag, count in sorted(_dict(_dict(census, "events"), "by_tag").items())
            )
            sections.append(
                "\n".join(
                    [
                        "census",
                        f"  entities   {entity_bits}".rstrip(),
                        f"  events     {event_total} total" + (f" — {by_tag}" if by_tag else ""),
                    ]
                )
            )
    if "coverage" in payload:
        coverage = payload["coverage"]
        if isinstance(coverage, dict):
            events = _dict(coverage, "events")
            total = int(events.get("total", 0))
            substantive = int(events.get("substantive_uncited", 0))
            raw_uncited = int(events.get("raw_uncited", 0))
            cited = max(total - raw_uncited, 0)
            percent = 0 if total == 0 else round((cited / total) * 100)
            by_layer = "  ".join(
                f"{layer} {count}"
                for layer, count in sorted(_dict(coverage, "by_subject_kind").items())
            )
            names = _dict(coverage, "names")
            events_summary = (
                f"  events     {cited}/{total} cited ({percent}%); {raw_uncited} raw uncited; "
                f"{substantive} substantive uncited"
            )
            names_summary = (
                f"  names      {names.get('name_cited', 0)}/{names.get('total', 0)} "
                "INDI name-cited"
            )
            sections.append(
                "\n".join(
                    [
                        "coverage",
                        events_summary,
                        f"  by layer   {by_layer}".rstrip(),
                        names_summary,
                    ]
                )
            )
    if "structure" in payload:
        structure = payload["structure"]
        if isinstance(structure, dict):
            sections.append(
                "\n".join(
                    [
                        "structure",
                        f"  components {structure.get('connected_components', 0)}",
                        f"  frontier   {structure.get('frontier_count', 0)}",
                        f"  max depth  {structure.get('max_depth', 0)}",
                    ]
                )
            )
    if "duplicates" in payload:
        duplicates = payload["duplicates"]
        if isinstance(duplicates, dict):
            pairs = duplicates.get("pairs", [])
            sections.append(
                "\n".join(
                    [
                        "duplicates",
                        f"  pairs      {len(pairs)} candidate pair(s)",
                    ]
                )
            )
    return "\n\n".join(section for section in sections if section)


def _build_census_report(projection: Projection) -> dict[str, object]:
    entity_counts = Counter(record.kind for record in projection.records)
    event_counts = Counter(event.tag for record in projection.records for event in record.events)
    years = [
        year
        for record in projection.records
        for event in record.events
        for year in [_year_from_raw(event.date_raw)]
        if year is not None
    ]
    return {
        "entities": dict(sorted(entity_counts.items())),
        "events": {
            "total": sum(event_counts.values()),
            "by_tag": dict(sorted(event_counts.items())),
        },
        "span": {
            "earliest": min(years) if years else None,
            "latest": max(years) if years else None,
        },
    }


def _build_coverage_report(handle: QueryHandle, projection: Projection) -> dict[str, object]:
    settings = Settings()
    total_events = 0
    raw_uncited = 0
    for record in projection.records:
        for event in record.events:
            total_events += 1
            if not event.source_ids:
                raw_uncited += 1
    substantive_uncited = len(_collect_unsourced_event_issues(projection, settings))
    by_subject_kind = Counter(
        str(row.get("subject_kind", ""))
        for row in query_rows_as_dicts(
            handle.connection.execute(
                "MATCH (e:entities)-[r:cites]->(s:entities) RETURN r.subject_kind AS subject_kind;"
            )
        )
        if row.get("subject_kind") is not None
    )
    indi_records = [record for record in projection.records if record.kind == "INDI"]
    name_cited = 0
    for record in indi_records:
        if any(field.tag == "NAME" and field.source_ids for field in record.fields):
            name_cited += 1
    return {
        "events": {
            "total": total_events,
            "raw_uncited": raw_uncited,
            "substantive_uncited": substantive_uncited,
        },
        "by_subject_kind": dict(sorted(by_subject_kind.items())),
        "names": {"total": len(indi_records), "name_cited": name_cited},
    }


def _build_structure_report(projection: Projection) -> dict[str, object]:
    graph: dict[str, set[str]] = defaultdict(set)
    fam_children: dict[str, list[str]] = {}
    for record in projection.records:
        record_id = normalize_entity_id(record.entity_id) if record.entity_id else None
        if record.kind != "FAM" or record_id is None:
            continue
        raw_fields = build_record_raw_fields(record, projection)
        parents = [
            value
            for tag in ("HUSB", "WIFE")
            for value in _string_values(raw_fields.get(tag))
        ]
        children = list(_string_values(raw_fields.get("CHIL")))
        fam_children[record_id] = children
        for child_id in children:
            for parent_id in parents:
                graph[parent_id].add(child_id)
                graph[child_id].add(parent_id)
    indi_ids = [
        normalize_entity_id(record.entity_id)
        for record in projection.records
        if record.kind == "INDI" and record.entity_id
    ]
    components = _connected_components(graph, indi_ids)
    frontier_ids = sorted(
        person_id
        for person_id in indi_ids
        if not any(person_id in children for children in fam_children.values())
    )
    return {
        "connected_components": len(components),
        "largest_component": max((len(component) for component in components), default=0),
        "frontier_count": len(frontier_ids),
        "frontier_ids": frontier_ids,
        "max_depth": _max_depth(graph, frontier_ids),
    }


def _build_duplicates_report(projection: Projection) -> dict[str, object]:
    people = [
        _person_summary(record, projection)
        for record in projection.records
        if record.kind == "INDI" and record.entity_id
    ]
    pairs: list[dict[str, object]] = []
    for index, left in enumerate(people):
        if left.surname is None or left.birth_year is None:
            continue
        for right in people[index + 1 :]:
            if right.surname != left.surname or right.birth_year != left.birth_year:
                continue
            shared_parents = sorted(left.parents & right.parents)
            if not shared_parents:
                continue
            score = 2 + len(shared_parents)
            pairs.append(
                {
                    "left_id": left.entity_id,
                    "right_id": right.entity_id,
                    "surname": left.surname,
                    "birth_year": left.birth_year,
                    "shared_parents": shared_parents,
                    "score": score,
                }
            )
    pairs.sort(key=_duplicate_pair_sort_key)
    return {"pairs": pairs}


def _duplicate_pair_sort_key(pair: dict[str, object]) -> tuple[int, str, str]:
    score = pair.get("score")
    left_id = pair.get("left_id")
    right_id = pair.get("right_id")
    return (
        -(score if isinstance(score, int) else 0),
        str(left_id or ""),
        str(right_id or ""),
    )


def _person_summary(record: EntityRecord, projection: Projection) -> _PersonSummary:
    raw_fields = build_record_raw_fields(record, projection)
    parents: set[str] = set()
    for family_id in _string_values(raw_fields.get("FAMC")):
        family = projection.get_record(f"@{family_id}@")
        if family is None:
            continue
        family_fields = build_record_raw_fields(family, projection)
        parents.update(_string_values(family_fields.get("HUSB")))
        parents.update(_string_values(family_fields.get("WIFE")))
    return _PersonSummary(
        entity_id=normalize_entity_id(record.entity_id),
        surname=_surname(raw_fields.get("NAME")),
        birth_year=_birth_year(record),
        parents=frozenset(parents),
    )


def _birth_year(record: EntityRecord) -> int | None:
    for event in record.events:
        if event.tag == "BIRT":
            return _year_from_raw(event.date_raw)
    return None


def _year_from_raw(raw: bytes | None) -> int | None:
    if raw is None:
        return None
    text = raw.decode("utf-8")
    digits = [token for token in text.split() if token.isdigit() and len(token) == 4]
    return None if not digits else int(digits[-1])


def _surname(value: object | None) -> str | None:
    names = _string_values(value)
    if not names:
        return None
    name = names[0]
    if "/" not in name:
        return None
    first = name.find("/")
    second = name.find("/", first + 1)
    if second == -1:
        return None
    surname = name[first + 1 : second].strip().lower()
    return surname or None


def _connected_components(graph: dict[str, set[str]], nodes: list[str]) -> list[set[str]]:
    seen: set[str] = set()
    components: list[set[str]] = []
    for node in nodes:
        if node in seen:
            continue
        queue: deque[str] = deque([node])
        component: set[str] = set()
        while queue:
            current = queue.popleft()
            if current in seen:
                continue
            seen.add(current)
            component.add(current)
            queue.extend(graph.get(current, set()) - seen)
        components.append(component)
    return components


def _max_depth(graph: dict[str, set[str]], frontier_ids: list[str]) -> int:
    max_depth = 0
    for start in frontier_ids:
        queue: deque[tuple[str, int]] = deque([(start, 0)])
        seen: set[str] = set()
        while queue:
            current, depth = queue.popleft()
            if current in seen:
                continue
            seen.add(current)
            max_depth = max(max_depth, depth)
            for neighbor in graph.get(current, set()):
                queue.append((neighbor, depth + 1))
    return max_depth


def _dict(payload: dict[str, object], key: str) -> dict[str, Any]:
    value = payload.get(key)
    return value if isinstance(value, dict) else {}


def _string_values(value: object | None) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, str):
        return (value,)
    if isinstance(value, list):
        return tuple(item for item in value if isinstance(item, str))
    return ()
