"""Service-layer helpers for gedq."""
