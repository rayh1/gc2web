"""Schema metadata for GEDCOM-derived cache artifacts."""

SCHEMA_VERSION = 11
