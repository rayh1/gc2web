"""Metadata persistence for GEDCOM cache snapshots."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from gedq.storage.cache import (
    cache_dir_for,
    ensure_cache_dir,
    ensure_resolved_cache_dir,
    metadata_path_in,
)


@dataclass(frozen=True)
class SourceSnapshot:
    """File snapshot used to detect stale cache or write state."""

    mtime_ns: int
    size: int
    sha256: str

    @classmethod
    def capture(cls, path: Path) -> SourceSnapshot:
        """Capture the current snapshot for a GEDCOM file.

        Args:
            path: The GEDCOM file to inspect.

        Returns:
            The current source snapshot.
        """
        stat = path.stat()
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        return cls(mtime_ns=stat.st_mtime_ns, size=stat.st_size, sha256=digest)

    def to_dict(self) -> dict[str, int | str]:
        """Serialize the snapshot for JSON persistence."""
        return {"mtime_ns": self.mtime_ns, "size": self.size, "sha256": self.sha256}

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SourceSnapshot:
        """Rebuild a snapshot from persisted JSON data."""
        return cls(
            mtime_ns=int(data["mtime_ns"]),
            size=int(data["size"]),
            sha256=str(data["sha256"]),
        )


@dataclass(frozen=True)
class CacheMetadata:
    """Persisted metadata describing a derived GEDCOM cache."""

    schema_version: int
    snapshot: SourceSnapshot

    def matches_schema(self, schema_version: int) -> bool:
        """Return whether the cache schema is compatible with the expected version."""
        return self.schema_version == schema_version

    def matches(self, snapshot: SourceSnapshot, schema_version: int) -> bool:
        """Return whether the cache still matches the current source state."""
        return self.matches_schema(schema_version) and self.snapshot == snapshot

    def to_dict(self) -> dict[str, object]:
        """Serialize the metadata for JSON persistence."""
        return {"schema_version": self.schema_version, "snapshot": self.snapshot.to_dict()}

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CacheMetadata:
        """Rebuild metadata from persisted JSON data."""
        return cls(
            schema_version=int(data["schema_version"]),
            snapshot=SourceSnapshot.from_dict(dict(data["snapshot"])),
        )


class MetadataStore:
    """Persist and retrieve GEDCOM cache metadata."""

    def load_from_cache_dir(self, cache_dir: Path) -> CacheMetadata | None:
        """Load cache metadata from a resolved cache directory."""
        path = metadata_path_in(cache_dir)
        if not path.exists():
            return None
        return CacheMetadata.from_dict(json.loads(path.read_text(encoding="utf-8")))

    def save_to_cache_dir(self, cache_dir: Path, metadata: CacheMetadata) -> None:
        """Persist cache metadata into a resolved cache directory."""
        ensure_resolved_cache_dir(cache_dir)
        metadata_path_in(cache_dir).write_text(
            json.dumps(metadata.to_dict(), indent=2, sort_keys=True), encoding="utf-8"
        )

    def invalidate_cache_dir(self, cache_dir: Path) -> None:
        """Invalidate cache metadata in a resolved cache directory."""
        path = metadata_path_in(cache_dir)
        if path.exists():
            path.unlink()

    def load(self, ged_path: Path, *, cache_base: Path | None = None) -> CacheMetadata | None:
        """Load cache metadata if it exists for the source file."""
        return self.load_from_cache_dir(cache_dir_for(ged_path, cache_base=cache_base))

    def save(
        self,
        ged_path: Path,
        metadata: CacheMetadata,
        *,
        cache_base: Path | None = None,
    ) -> None:
        """Persist cache metadata beside the source file."""
        ensure_cache_dir(ged_path, cache_base=cache_base)
        self.save_to_cache_dir(cache_dir_for(ged_path, cache_base=cache_base), metadata)

    def invalidate(self, ged_path: Path, *, cache_base: Path | None = None) -> None:
        """Invalidate cache metadata so the next read must rebuild it."""
        self.invalidate_cache_dir(cache_dir_for(ged_path, cache_base=cache_base))

    def require_snapshot(self, ged_path: Path, *, cache_base: Path | None = None) -> SourceSnapshot:
        """Return the recorded source snapshot or raise if none exists."""
        metadata = self.load(ged_path, cache_base=cache_base)
        if metadata is None:
            raise FileNotFoundError(f"No cache metadata for {ged_path}")
        return metadata.snapshot
