"""Ladybug-derived index lifecycle helpers."""

from __future__ import annotations

import json
import shutil
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Literal, TextIO

from ladybug import Connection, Database, QueryResult

from gedq.model.entity_ids import normalize_entity_id
from gedq.model.events import EventRecord
from gedq.model.records import EntityRecord
from gedq.parser.projection import Projection
from gedq.query.properties import (
    build_entity_scalar_query_values,
    build_single_file_object_media_values,
    entity_scalar_properties,
)
from gedq.service.validate import load_strict_document
from gedq.storage.cache import (
    CacheCoordinator,
    cache_dir_for,
    database_path_for,
    database_path_in,
    ensure_cache_dir,
    ensure_resolved_cache_dir,
    index_path_for,
    index_path_in,
)
from gedq.storage.metadata import CacheMetadata, MetadataStore, SourceSnapshot
from gedq.storage.schema import SCHEMA_VERSION

if TYPE_CHECKING:
    from gedq.service.write import ChangedRecord

STANDARD_ENTITY_KINDS = {"INDI", "FAM", "SOUR", "REPO", "OBJE", "NOTE", "SUBM"}
_ENTITY_SEARCH_COLUMNS = (
    ("id", "STRING"),
    ("kind", "STRING"),
    ("name", "STRING"),
    ("name_search", "STRING"),
    ("nickname", "STRING"),
    ("note", "STRING"),
    ("media_path", "STRING"),
    ("media_form", "STRING"),
    ("media_title", "STRING"),
    ("sex", "STRING"),
    ("occupation", "STRING"),
    ("famc", "STRING"),
    ("fams", "STRING"),
)
_EVENT_ORACLE_COLUMNS = (
    "id",
    "owner_id",
    "tag",
    "date_raw",
    "year",
    "place",
    "address",
    "note_text",
)
_CITES_ORACLE_COLUMNS = (
    "owner_id",
    "source_id",
    "subject_kind",
    "event_tag",
    "association_target_id",
    "association_role",
    "name_index",
)
_CITES_REL_COLUMNS = _CITES_ORACLE_COLUMNS[1:]
_SPOUSE_ORACLE_COLUMNS = ("family_id", "parent_id", "spouse_id")
_PARENT_ORACLE_COLUMNS = ("family_id", "parent_id", "child_id")


@dataclass
class _GraphBatchRows:
    entities: list[dict[str, object | None]] = field(default_factory=list)
    events: list[dict[str, object | None]] = field(default_factory=list)
    has_event: list[dict[str, object | None]] = field(default_factory=list)
    cites: list[dict[str, object | None]] = field(default_factory=list)
    spouse_of: list[dict[str, object | None]] = field(default_factory=list)
    parent_of: list[dict[str, object | None]] = field(default_factory=list)


@dataclass(frozen=True)
class QueryHandle:
    """Handle describing the derived index opened for query."""

    cache_dir: Path
    index_path: Path
    metadata: CacheMetadata
    source_path: Path
    database_path: Path = field(compare=False)
    database: Database = field(compare=False, repr=False)
    connection: Connection = field(compare=False, repr=False)
    cache_status: Literal["reused", "built", "rebuilt"] = "reused"


class IndexWriter:
    """Write the derived cache representation for a GEDCOM file."""

    def __init__(self, metadata_store: MetadataStore) -> None:
        """Initialize the index writer.

        Args:
            metadata_store: Store used to persist cache metadata.
        """
        self.metadata_store = metadata_store

    def rebuild(
        self,
        ged_path: Path,
        projection: Projection,
        snapshot: SourceSnapshot,
        schema_version: int,
        *,
        cache_base: Path | None = None,
        cache_dir: Path | None = None,
    ) -> None:
        """Rebuild the derived cache for a GEDCOM file."""
        if cache_dir is None:
            target_cache_dir = ensure_cache_dir(ged_path, cache_base=cache_base)
            database_path = database_path_for(ged_path, cache_base=cache_base)
            index_path = index_path_for(ged_path, cache_base=cache_base)
        else:
            target_cache_dir = ensure_resolved_cache_dir(cache_dir)
            database_path = database_path_in(target_cache_dir)
            index_path = index_path_in(target_cache_dir)
        _reset_database_path(database_path)
        database = Database(str(database_path))
        connection = Connection(database)
        _create_schema(connection)
        _populate_graph(connection, projection)
        _write_index_payload(index_path, projection, schema_version)
        connection.close()
        database.close()
        self.metadata_store.save_to_cache_dir(
            target_cache_dir,
            CacheMetadata(schema_version=schema_version, snapshot=snapshot),
        )


class IndexReader:
    """Open the derived cache representation for queries."""

    def __init__(self, metadata_store: MetadataStore) -> None:
        """Initialize the index reader.

        Args:
            metadata_store: Store used to retrieve cache metadata.
        """
        self.metadata_store = metadata_store

    def open(
        self,
        ged_path: Path,
        *,
        cache_base: Path | None = None,
        cache_dir: Path | None = None,
    ) -> QueryHandle:
        """Open the derived cache for a GEDCOM file."""
        resolved_cache_dir = cache_dir or cache_dir_for(ged_path, cache_base=cache_base)
        metadata = self.metadata_store.load_from_cache_dir(resolved_cache_dir)
        if metadata is None:
            raise FileNotFoundError(f"No cache metadata for {ged_path}")
        database_path = database_path_in(resolved_cache_dir)
        database = Database(str(database_path), read_only=True)
        connection = Connection(database)
        return QueryHandle(
            cache_dir=resolved_cache_dir,
            index_path=index_path_in(resolved_cache_dir),
            metadata=metadata,
            source_path=ged_path,
            database_path=database_path,
            database=database,
            connection=connection,
        )


class GraphIndexService:
    """Manage the derived Ladybug-style cache lifecycle for GEDCOM queries."""

    def __init__(
        self,
        metadata_store: MetadataStore | None = None,
        *,
        cache_base: Path | None = None,
        status_stream: TextIO | None = None,
    ) -> None:
        """Initialize the graph index lifecycle service.

        Args:
            metadata_store: Optional metadata store override for tests.
            cache_base: Optional base directory for derived cache artifacts.
            status_stream: Optional stream for interactive cache-build notices.
        """
        store = metadata_store or MetadataStore()
        self.metadata_store = store
        self.index_writer = IndexWriter(store)
        self.index_reader = IndexReader(store)
        self.cache_base = cache_base
        self.status_stream = status_stream

    def open_for_query(self, ged_path: Path) -> QueryHandle:
        """Open or rebuild the derived cache for a GEDCOM file.

        Args:
            ged_path: The source GEDCOM file.

        Returns:
            A query handle for the fresh or reused derived cache.
        """
        snapshot = SourceSnapshot.capture(ged_path)
        coordinator = CacheCoordinator.for_source(ged_path, cache_base=self.cache_base)

        with coordinator.acquire_build_lease():
            metadata, metadata_error = self._load_active_metadata(coordinator)
            stale_artifacts = coordinator.stale_artifact_paths()
            if (
                not stale_artifacts
                and metadata_error is None
                and metadata is not None
                and metadata.matches(snapshot, SCHEMA_VERSION)
            ):
                try:
                    handle = self.index_reader.open(
                        ged_path,
                        cache_base=self.cache_base,
                        cache_dir=coordinator.active_dir,
                    )
                except Exception:
                    handle = self._recover_and_open(
                        ged_path,
                        snapshot,
                        coordinator,
                        cache_status="rebuilt",
                    )
                else:
                    return QueryHandle(
                        cache_dir=handle.cache_dir,
                        index_path=handle.index_path,
                        metadata=handle.metadata,
                        source_path=handle.source_path,
                        cache_status="reused",
                        database_path=handle.database_path,
                        database=handle.database,
                        connection=handle.connection,
                    )
            else:
                cache_status: Literal["reused", "built", "rebuilt"]
                cache_status = (
                    "built"
                    if (
                        metadata is None
                        and metadata_error is None
                        and not stale_artifacts
                        and not coordinator.active_dir.exists()
                    )
                    else "rebuilt"
                )
                handle = self._recover_and_open(
                    ged_path,
                    snapshot,
                    coordinator,
                    cache_status=cache_status,
                )

        return QueryHandle(
            cache_dir=handle.cache_dir,
            index_path=handle.index_path,
            metadata=handle.metadata,
            source_path=handle.source_path,
            cache_status=handle.cache_status,
            database_path=handle.database_path,
            database=handle.database,
            connection=handle.connection,
        )

    def publish_rebuilt_cache(
        self,
        ged_path: Path,
        projection: Projection,
        snapshot: SourceSnapshot,
    ) -> None:
        """Rebuild a staged cache directory and publish it atomically."""
        coordinator = CacheCoordinator.for_source(ged_path, cache_base=self.cache_base)

        with coordinator.acquire_build_lease():
            if not coordinator.active_dir.exists():
                return

            staged_dir = coordinator.create_staging_dir()
            try:
                self.index_writer.rebuild(
                    ged_path,
                    projection,
                    snapshot,
                    SCHEMA_VERSION,
                    cache_base=self.cache_base,
                    cache_dir=staged_dir,
                )
                validation_handle = self.index_reader.open(
                    ged_path,
                    cache_base=self.cache_base,
                    cache_dir=staged_dir,
                )
                validation_handle.connection.close()
                validation_handle.database.close()
                quarantined_dir = coordinator.quarantine_active_cache()
                coordinator.publish(staged_dir)
                if quarantined_dir is not None and quarantined_dir.exists():
                    shutil.rmtree(quarantined_dir, ignore_errors=True)
            except Exception:
                if staged_dir.exists():
                    shutil.rmtree(staged_dir, ignore_errors=True)
                raise

    def _load_active_metadata(
        self, coordinator: CacheCoordinator
    ) -> tuple[CacheMetadata | None, Exception | None]:
        try:
            return (
                self.metadata_store.load_from_cache_dir(coordinator.active_dir),
                None,
            )
        except Exception as exc:
            return None, exc

    def _recover_and_open(
        self,
        ged_path: Path,
        snapshot: SourceSnapshot,
        coordinator: CacheCoordinator,
        *,
        cache_status: Literal["built", "rebuilt"],
    ) -> QueryHandle:
        quarantined_dir: Path | None = None
        if coordinator.active_dir.exists():
            quarantined_dir = coordinator.quarantine_active_cache()
        _, projection = load_strict_document(ged_path)
        staged_dir = coordinator.create_staging_dir()
        try:
            self.index_writer.rebuild(
                ged_path,
                projection,
                snapshot,
                SCHEMA_VERSION,
                cache_base=self.cache_base,
                cache_dir=staged_dir,
            )
            coordinator.publish(staged_dir)
            if quarantined_dir is not None and quarantined_dir.exists():
                shutil.rmtree(quarantined_dir, ignore_errors=True)
        except Exception:
            if staged_dir.exists():
                shutil.rmtree(staged_dir, ignore_errors=True)
            raise
        handle = self.index_reader.open(
            ged_path,
            cache_base=self.cache_base,
            cache_dir=coordinator.active_dir,
        )
        return QueryHandle(
            cache_dir=handle.cache_dir,
            index_path=handle.index_path,
            metadata=handle.metadata,
            source_path=handle.source_path,
            cache_status=cache_status,
            database_path=handle.database_path,
            database=handle.database,
            connection=handle.connection,
        )


def query_rows_as_dicts(result: QueryResult | list[QueryResult]) -> list[dict[str, object]]:
    """Normalize Ladybug query results into a list of row dictionaries."""
    if isinstance(result, list):
        rows: list[dict[str, object]] = []
        for partial in result:
            rows.extend(dict(row) for row in partial.rows_as_dict())
        return rows
    return [dict(row) for row in result.rows_as_dict()]


def _reset_database_path(database_path: Path) -> None:
    if database_path.is_file():
        database_path.unlink()
    elif database_path.exists():
        shutil.rmtree(database_path)


def _create_schema(connection: Connection) -> None:
    entity_columns = ", ".join(
        f"{column_name} {storage_type}" for column_name, storage_type in _entity_node_columns()
    )
    connection.execute(f"CREATE NODE TABLE entities({entity_columns}, PRIMARY KEY(id));")
    connection.execute(
        "CREATE NODE TABLE events(id STRING, owner_id STRING, tag STRING, date_raw STRING, "
        "year INT64, place STRING, address STRING, note_text STRING, PRIMARY KEY(id));"
    )
    connection.execute("CREATE REL TABLE has_event(FROM entities TO events, tag STRING);")
    connection.execute("CREATE REL TABLE parent_of(FROM entities TO entities, family_id STRING);")
    connection.execute("CREATE REL TABLE spouse_of(FROM entities TO entities, family_id STRING);")
    connection.execute(
        "CREATE REL TABLE cites(FROM entities TO entities, source_id STRING, "
        "subject_kind STRING, event_tag STRING, association_target_id STRING, "
        "association_role STRING, name_index INT64);"
    )


def _populate_graph(connection: Connection, projection: Projection) -> None:
    records_by_id = _standard_records_by_normalized_id(projection)
    normalized_ids = set(records_by_id)
    rows = _collect_graph_batch_rows(records_by_id.values(), projection, normalized_ids)

    _batch_insert_entities(connection, rows.entities)
    _batch_insert_events(connection, rows.events)
    _batch_insert_has_event(connection, rows.has_event)
    _batch_insert_citation_edges(connection, rows.cites)
    _batch_insert_spouse_relationships(connection, rows.spouse_of)
    _batch_insert_parent_relationships(connection, rows.parent_of)


def _collect_graph_batch_rows(
    records: Iterable[EntityRecord],
    projection: Projection,
    normalized_record_ids: set[str],
) -> _GraphBatchRows:
    rows = _GraphBatchRows()

    for record in records:
        rows.entities.append(_entity_row(record, projection))
        _append_record_batch_rows(rows, record, normalized_record_ids)

    return rows


def _entity_row(record: EntityRecord, projection: Projection) -> dict[str, object | None]:
    values: dict[str, object | None] = {
        column_name: None for column_name, _ in _entity_node_columns()
    }
    values.update(_entity_properties(record, projection))
    return values


def _event_row(event_id: str, owner_id: str, event: EventRecord) -> dict[str, object | None]:
    values: dict[str, object | None] = {column_name: None for column_name in _EVENT_ORACLE_COLUMNS}
    values.update(_event_properties(event_id, owner_id, event))
    return values


def _append_record_batch_rows(
    rows: _GraphBatchRows,
    record: EntityRecord,
    normalized_record_ids: set[str],
) -> None:
    normalized_id = _normalize_id(record.entity_id)

    for index, event in enumerate(record.events):
        event_id = f"{normalized_id}:{index}:{event.tag}"
        rows.events.append(_event_row(event_id, normalized_id, event))
        rows.has_event.append(
            {
                "owner_id": normalized_id,
                "event_id": event_id,
                "tag": event.tag,
            }
        )
        for source_id in event.source_ids:
            normalized_source = _normalize_id(source_id)
            if normalized_source in normalized_record_ids:
                rows.cites.append(
                    _citation_row(
                        owner_id=normalized_id,
                        source_id=normalized_source,
                        subject_kind="event",
                        event_tag=event.tag,
                    )
                )

        for association in event.associations:
            for source_id in association.source_ids:
                normalized_source = _normalize_id(source_id)
                if normalized_source in normalized_record_ids:
                    rows.cites.append(
                        _citation_row(
                            owner_id=normalized_id,
                            source_id=normalized_source,
                            subject_kind="association",
                            event_tag=event.tag,
                            association_target_id=_normalize_id(association.target_id),
                            association_role=_decode_bytes(association.role),
                        )
                    )

    for association in record.associations:
        for source_id in association.source_ids:
            normalized_source = _normalize_id(source_id)
            if normalized_source in normalized_record_ids:
                rows.cites.append(
                    _citation_row(
                        owner_id=normalized_id,
                        source_id=normalized_source,
                        subject_kind="association",
                        association_target_id=_normalize_id(association.target_id),
                        association_role=_decode_bytes(association.role),
                    )
                )

    if record.kind == "FAM":
        _append_family_relationship_rows(rows, record, normalized_record_ids)

    for record_field in record.fields:
        if record.kind == "INDI" and record_field.tag == "NAME":
            for source_id in record_field.source_ids:
                normalized_source = _normalize_id(source_id)
                if normalized_source in normalized_record_ids:
                    rows.cites.append(
                        _citation_row(
                            owner_id=normalized_id,
                            source_id=normalized_source,
                            subject_kind="name",
                            name_index=record_field.name_index,
                        )
                    )
        if record_field.tag == "SOUR":
            for source_id in record_field.references:
                normalized_source = _normalize_id(source_id)
                if normalized_source in normalized_record_ids:
                    rows.cites.append(
                        _citation_row(
                            owner_id=normalized_id,
                            source_id=normalized_source,
                            subject_kind="record",
                        )
                    )


def _append_family_relationship_rows(
    rows: _GraphBatchRows,
    record: EntityRecord,
    normalized_ids: set[str],
) -> None:
    family_id = _normalize_id(record.entity_id)
    husband = _first_reference(record, "HUSB")
    wife = _first_reference(record, "WIFE")
    children = _all_references(record, "CHIL")

    if (
        husband is not None
        and wife is not None
        and husband in normalized_ids
        and wife in normalized_ids
    ):
        rows.spouse_of.append({"family_id": family_id, "parent_id": husband, "spouse_id": wife})
        rows.spouse_of.append({"family_id": family_id, "parent_id": wife, "spouse_id": husband})

    for child in children:
        if child not in normalized_ids:
            continue
        for parent in (husband, wife):
            if parent is None or parent not in normalized_ids:
                continue
            rows.parent_of.append({"family_id": family_id, "parent_id": parent, "child_id": child})


def _citation_row(
    *,
    owner_id: str,
    source_id: str,
    subject_kind: str,
    event_tag: str | None = None,
    association_target_id: str | None = None,
    association_role: str | None = None,
    name_index: int | None = None,
) -> dict[str, object | None]:
    return {
        "owner_id": owner_id,
        "source_id": source_id,
        "subject_kind": subject_kind,
        "event_tag": event_tag,
        "association_target_id": association_target_id,
        "association_role": association_role,
        "name_index": name_index,
    }


def _batch_insert_entities(
    connection: Connection,
    rows: Sequence[dict[str, object | None]],
) -> None:
    _execute_batched_rows(
        connection,
        (
            "UNWIND $rows AS row "
            f"CREATE (e:entities {{{_batch_property_assignments(_entity_column_names())}}});"
        ),
        rows,
    )


def _batch_insert_events(
    connection: Connection,
    rows: Sequence[dict[str, object | None]],
) -> None:
    _execute_batched_rows(
        connection,
        (
            "UNWIND $rows AS row "
            f"CREATE (event:events {{{_batch_property_assignments(_EVENT_ORACLE_COLUMNS)}}});"
        ),
        rows,
    )


def _batch_insert_has_event(
    connection: Connection,
    rows: Sequence[dict[str, object | None]],
) -> None:
    _execute_batched_rows(
        connection,
        "UNWIND $rows AS row "
        "MATCH (e:entities {id: row.owner_id}), (event:events {id: row.event_id}) "
        "CREATE (e)-[:has_event {tag: row.tag}]->(event);",
        rows,
    )


def _batch_insert_citation_edges(
    connection: Connection,
    rows: Sequence[dict[str, object | None]],
) -> None:
    grouped = _group_rows_by_present_keys(rows, _CITES_REL_COLUMNS)
    for property_keys, grouped_rows in grouped.items():
        properties = _relationship_property_map(property_keys)
        _execute_batched_rows(
            connection,
            "UNWIND $rows AS row "
            "MATCH (e:entities {id: row.owner_id}), (s:entities {id: row.source_id}) "
            f"CREATE (e)-[:cites{properties}]->(s);",
            grouped_rows,
        )


def _batch_insert_spouse_relationships(
    connection: Connection,
    rows: Sequence[dict[str, object | None]],
) -> None:
    _execute_batched_rows(
        connection,
        "UNWIND $rows AS row "
        "MATCH (a:entities {id: row.parent_id}), (b:entities {id: row.spouse_id}) "
        "CREATE (a)-[:spouse_of {family_id: row.family_id}]->(b);",
        rows,
    )


def _batch_insert_parent_relationships(
    connection: Connection,
    rows: Sequence[dict[str, object | None]],
) -> None:
    _execute_batched_rows(
        connection,
        "UNWIND $rows AS row "
        "MATCH (p:entities {id: row.parent_id}), (c:entities {id: row.child_id}) "
        "CREATE (p)-[:parent_of {family_id: row.family_id}]->(c);",
        rows,
    )


def _execute_batched_rows(
    connection: Connection,
    query: str,
    rows: Sequence[dict[str, object | None]],
) -> None:
    if not rows:
        return
    connection.execute(query, parameters={"rows": list(rows)})


def _batch_property_assignments(keys: Sequence[str]) -> str:
    return ", ".join(f"{key}: row.{key}" for key in keys)


def _relationship_property_map(keys: Sequence[str]) -> str:
    if not keys:
        return ""
    return f" {{{_batch_property_assignments(keys)}}}"


def _group_rows_by_present_keys(
    rows: Sequence[dict[str, object | None]],
    candidate_keys: Sequence[str],
) -> dict[tuple[str, ...], list[dict[str, object | None]]]:
    grouped: dict[tuple[str, ...], list[dict[str, object | None]]] = {}
    for row in rows:
        present_keys = tuple(key for key in candidate_keys if row.get(key) is not None)
        grouped.setdefault(present_keys, []).append(row)
    return grouped


def _entity_column_names() -> tuple[str, ...]:
    return tuple(column_name for column_name, _ in _entity_node_columns())


def _standard_records_by_normalized_id(projection: Projection) -> dict[str, EntityRecord]:
    return {
        _normalize_id(record.entity_id): record
        for record in projection.records
        if record.entity_id is not None and record.kind in STANDARD_ENTITY_KINDS
    }


def _expand_changed_records_for_dependents(
    projection: Projection,
    changed_records: tuple[ChangedRecord, ...],
) -> tuple[ChangedRecord, ...]:
    from gedq.service.write import ChangedRecord as WriteChangedRecord

    records_by_id = _standard_records_by_normalized_id(projection)
    expanded_records: list[WriteChangedRecord] = list(changed_records)
    seen_ids = {_normalize_id(changed_record.entity_id) for changed_record in changed_records}

    for record_id, record in records_by_id.items():
        if record_id in seen_ids:
            continue
        if not _record_depends_on_changed_records(record, seen_ids):
            continue
        expanded_records.append(
            WriteChangedRecord(entity_id=record_id, kind=record.kind, action="upsert")
        )
        seen_ids.add(record_id)

    return tuple(expanded_records)


def _record_depends_on_changed_records(record: EntityRecord, changed_ids: set[str]) -> bool:
    for event in record.events:
        if any(_normalize_id(source_id) in changed_ids for source_id in event.source_ids):
            return True
        for association in event.associations:
            if any(_normalize_id(source_id) in changed_ids for source_id in association.source_ids):
                return True

    for association in record.associations:
        if any(_normalize_id(source_id) in changed_ids for source_id in association.source_ids):
            return True

    for record_field in record.fields:
        if record.kind == "INDI" and record_field.tag == "NAME":
            if any(
                _normalize_id(source_id) in changed_ids for source_id in record_field.source_ids
            ):
                return True
        if record_field.tag == "SOUR":
            if any(
                _normalize_id(reference) in changed_ids for reference in record_field.references
            ):
                return True
        if record_field.tag in {"HUSB", "WIFE", "CHIL", "FAMC", "FAMS"}:
            if any(
                _normalize_id(reference) in changed_ids for reference in record_field.references
            ):
                return True

    return False


def _write_index_payload(index_path: Path, projection: Projection, schema_version: int) -> None:
    payload = {
        "schema_version": schema_version,
        "records": [
            {
                "entity_id": record.entity_id,
                "kind": record.kind,
                "events": [event.tag for event in record.events],
            }
            for record in projection.records
        ],
    }
    index_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _entity_properties(
    record: EntityRecord,
    projection: Projection,
) -> dict[str, object | None]:
    values: dict[str, object | None] = {
        "id": _normalize_id(record.entity_id),
        "kind": record.kind,
        "name": _decode_field(record, "NAME"),
        "name_search": _join_fields(record, "NAME"),
        "nickname": _decode_field(record, "NICK"),
        "note": _decode_field(record, "NOTE"),
        "media_path": _decode_field(record, "FILE"),
        **build_single_file_object_media_values(record),
        "sex": _decode_field(record, "SEX"),
        "occupation": _event_value(record, "OCCU"),
        "famc": _decode_reference(record, "FAMC"),
        "fams": _decode_reference(record, "FAMS"),
    }
    existing_keys = {key.lower() for key in values}
    for key, value in build_entity_scalar_query_values(record, projection).items():
        if key.lower() in existing_keys:
            continue
        values[key] = value
        existing_keys.add(key.lower())
    return values


def _entity_node_columns() -> tuple[tuple[str, str], ...]:
    columns = list(_ENTITY_SEARCH_COLUMNS)
    seen = {column_name.lower() for column_name, _ in columns}
    for kind in ("INDI", "FAM", "SOUR", "OBJE", "REPO"):
        for property_spec in entity_scalar_properties(kind):
            if property_spec.query_name.lower() in seen:
                continue
            columns.append((property_spec.query_name, property_spec.storage_type))
            seen.add(property_spec.query_name.lower())
    return tuple(columns)


def _event_properties(event_id: str, owner_id: str, event: EventRecord) -> dict[str, str | int]:
    values: dict[str, str | int] = {"id": event_id, "owner_id": owner_id, "tag": event.tag}
    if event.date_raw is not None:
        values["date_raw"] = event.date_raw.decode("utf-8")
    if event.date is not None and event.date.year is not None:
        values["year"] = event.date.year
    if event.place is not None:
        values["place"] = event.place.decode("utf-8")
    if event.address is not None:
        values["address"] = event.address.decode("utf-8")
    if event.notes:
        values["note_text"] = "\n".join(note.decode("utf-8") for note in event.notes)
    return values


def _first_reference(record: EntityRecord, tag: str) -> str | None:
    for record_field in record.fields:
        if record_field.tag == tag and record_field.references:
            return _normalize_id(record_field.references[0])
    return None


def _all_references(record: EntityRecord, tag: str) -> list[str]:
    references: list[str] = []
    for record_field in record.fields:
        if record_field.tag == tag:
            references.extend(_normalize_id(reference) for reference in record_field.references)
    return references


def _decode_field(record: EntityRecord, tag: str) -> str | None:
    for record_field in record.fields:
        if record_field.tag == tag and record_field.value is not None:
            return record_field.value.decode("utf-8")
    return None


def _join_fields(record: EntityRecord, tag: str) -> str | None:
    values = [
        record_field.value.decode("utf-8")
        for record_field in record.fields
        if record_field.tag == tag and record_field.value is not None
    ]
    if not values:
        return None
    return " ".join(values)


def _decode_reference(record: EntityRecord, tag: str) -> str | None:
    for record_field in record.fields:
        if record_field.tag == tag and record_field.references:
            return _normalize_id(record_field.references[0])
    return None


def _event_value(record: EntityRecord, tag: str) -> str | None:
    for event in record.events:
        if event.tag == tag and event.value is not None:
            return event.value.decode("utf-8")
    return None


def _decode_bytes(value: bytes | None) -> str | None:
    return None if value is None else value.decode("utf-8")


def _scoped_cache_state_from_connection(
    connection: Connection,
    target_ids: set[str],
    touched_source_ids: set[str],
) -> dict[str, list[dict[str, object]]]:
    return {
        "entities": _actual_entity_rows(connection, target_ids),
        "events": _actual_event_rows(connection, target_ids),
        "cites": _actual_citation_rows(connection, target_ids, touched_source_ids),
        "spouse_of": _actual_spouse_rows(connection, target_ids),
        "parent_of": _actual_parent_rows(connection, target_ids),
    }


def _expected_scoped_cache_state(
    projection: Projection,
    target_ids: set[str],
    touched_source_ids: set[str],
) -> dict[str, list[dict[str, object]]]:
    records_by_id = _standard_records_by_normalized_id(projection)
    normalized_record_ids = set(records_by_id)

    entity_rows = [
        _row_with_columns(_entity_properties(record, projection), _entity_oracle_columns())
        for record_id, record in records_by_id.items()
        if record_id in target_ids
    ]
    entity_rows.sort(key=lambda row: _row_sort_key(row, _entity_oracle_columns()))

    event_rows: list[dict[str, object]] = []
    citation_rows: list[dict[str, object]] = []
    spouse_rows: list[dict[str, object]] = []
    parent_rows: list[dict[str, object]] = []

    for record_id, record in records_by_id.items():
        if record_id in target_ids:
            for index, event in enumerate(record.events):
                event_rows.append(
                    _row_with_columns(
                        _event_properties(f"{record_id}:{index}:{event.tag}", record_id, event),
                        _EVENT_ORACLE_COLUMNS,
                    )
                )

        for citation_row in _expected_citation_rows(record, normalized_record_ids):
            if (
                str(citation_row["owner_id"]) in target_ids
                or str(citation_row["source_id"]) in touched_source_ids
            ):
                citation_rows.append(citation_row)

        if record.kind != "FAM":
            continue
        for spouse_row in _expected_spouse_rows(record, normalized_record_ids):
            if (
                str(spouse_row["parent_id"]) in target_ids
                or str(spouse_row["spouse_id"]) in target_ids
            ):
                spouse_rows.append(spouse_row)
        for parent_row in _expected_parent_rows(record, normalized_record_ids):
            if (
                str(parent_row["parent_id"]) in target_ids
                or str(parent_row["child_id"]) in target_ids
            ):
                parent_rows.append(parent_row)

    event_rows.sort(key=lambda row: _row_sort_key(row, _EVENT_ORACLE_COLUMNS))
    citation_rows.sort(key=lambda row: _row_sort_key(row, _CITES_ORACLE_COLUMNS))
    spouse_rows.sort(key=lambda row: _row_sort_key(row, _SPOUSE_ORACLE_COLUMNS))
    parent_rows.sort(key=lambda row: _row_sort_key(row, _PARENT_ORACLE_COLUMNS))

    return {
        "entities": entity_rows,
        "events": event_rows,
        "cites": citation_rows,
        "spouse_of": spouse_rows,
        "parent_of": parent_rows,
    }


def _actual_entity_rows(connection: Connection, target_ids: set[str]) -> list[dict[str, object]]:
    if not target_ids:
        return []
    columns = _entity_oracle_columns()
    select = ", ".join(f"e.{column} AS {column}" for column in columns)
    rows = query_rows_as_dicts(
        connection.execute(
            f"MATCH (e:entities) WHERE {_cypher_id_predicate('e.id', target_ids)} RETURN {select};"
        )
    )
    return sorted(rows, key=lambda row: _row_sort_key(row, columns))


def _actual_event_rows(connection: Connection, target_ids: set[str]) -> list[dict[str, object]]:
    if not target_ids:
        return []
    select = ", ".join(f"event.{column} AS {column}" for column in _EVENT_ORACLE_COLUMNS)
    rows = query_rows_as_dicts(
        connection.execute(
            "MATCH (event:events) "
            f"WHERE {_cypher_id_predicate('event.owner_id', target_ids)} RETURN {select};"
        )
    )
    return sorted(rows, key=lambda row: _row_sort_key(row, _EVENT_ORACLE_COLUMNS))


def _actual_citation_rows(
    connection: Connection,
    target_ids: set[str],
    touched_source_ids: set[str],
) -> list[dict[str, object]]:
    if not target_ids and not touched_source_ids:
        return []
    conditions = []
    if target_ids:
        conditions.append(_cypher_id_predicate("e.id", target_ids))
    if touched_source_ids:
        conditions.append(_cypher_id_predicate("s.id", touched_source_ids))
    where_clause = " OR ".join(conditions)
    select = ", ".join(f"c.{column} AS {column}" for column in _CITES_ORACLE_COLUMNS[2:])
    rows = query_rows_as_dicts(
        connection.execute(
            "MATCH (e:entities)-[c:cites]->(s:entities) "
            f"WHERE {where_clause} RETURN e.id AS owner_id, s.id AS source_id, {select};"
        )
    )
    return sorted(rows, key=lambda row: _row_sort_key(row, _CITES_ORACLE_COLUMNS))


def _actual_spouse_rows(connection: Connection, target_ids: set[str]) -> list[dict[str, object]]:
    if not target_ids:
        return []
    rows = query_rows_as_dicts(
        connection.execute(
            "MATCH (a:entities)-[r:spouse_of]->(b:entities) "
            f"WHERE {_cypher_id_predicate('a.id', target_ids)} "
            f"OR {_cypher_id_predicate('b.id', target_ids)} "
            "RETURN r.family_id AS family_id, a.id AS parent_id, b.id AS spouse_id;"
        )
    )
    return sorted(rows, key=lambda row: _row_sort_key(row, _SPOUSE_ORACLE_COLUMNS))


def _actual_parent_rows(connection: Connection, target_ids: set[str]) -> list[dict[str, object]]:
    if not target_ids:
        return []
    rows = query_rows_as_dicts(
        connection.execute(
            "MATCH (p:entities)-[r:parent_of]->(c:entities) "
            f"WHERE {_cypher_id_predicate('p.id', target_ids)} "
            f"OR {_cypher_id_predicate('c.id', target_ids)} "
            "RETURN r.family_id AS family_id, p.id AS parent_id, c.id AS child_id;"
        )
    )
    return sorted(rows, key=lambda row: _row_sort_key(row, _PARENT_ORACLE_COLUMNS))


def _expected_citation_rows(
    record: EntityRecord,
    normalized_record_ids: set[str],
) -> list[dict[str, object]]:
    owner_id = _normalize_id(record.entity_id)
    rows: list[dict[str, object]] = []

    for event in record.events:
        for source_id in event.source_ids:
            normalized_source = _normalize_id(source_id)
            if normalized_source in normalized_record_ids:
                rows.append(
                    _row_with_columns(
                        {
                            "owner_id": owner_id,
                            "source_id": normalized_source,
                            "subject_kind": "event",
                            "event_tag": event.tag,
                        },
                        _CITES_ORACLE_COLUMNS,
                    )
                )
        for association in event.associations:
            for source_id in association.source_ids:
                normalized_source = _normalize_id(source_id)
                if normalized_source in normalized_record_ids:
                    rows.append(
                        _row_with_columns(
                            {
                                "owner_id": owner_id,
                                "source_id": normalized_source,
                                "subject_kind": "association",
                                "event_tag": event.tag,
                                "association_target_id": _normalize_id(association.target_id),
                                "association_role": _decode_bytes(association.role),
                            },
                            _CITES_ORACLE_COLUMNS,
                        )
                    )

    for association in record.associations:
        for source_id in association.source_ids:
            normalized_source = _normalize_id(source_id)
            if normalized_source in normalized_record_ids:
                rows.append(
                    _row_with_columns(
                        {
                            "owner_id": owner_id,
                            "source_id": normalized_source,
                            "subject_kind": "association",
                            "association_target_id": _normalize_id(association.target_id),
                            "association_role": _decode_bytes(association.role),
                        },
                        _CITES_ORACLE_COLUMNS,
                    )
                )

    for record_field in record.fields:
        if record.kind == "INDI" and record_field.tag == "NAME":
            for source_id in record_field.source_ids:
                normalized_source = _normalize_id(source_id)
                if normalized_source in normalized_record_ids:
                    rows.append(
                        _row_with_columns(
                            {
                                "owner_id": owner_id,
                                "source_id": normalized_source,
                                "subject_kind": "name",
                                "name_index": record_field.name_index,
                            },
                            _CITES_ORACLE_COLUMNS,
                        )
                    )
        if record_field.tag == "SOUR":
            for source_id in record_field.references:
                normalized_source = _normalize_id(source_id)
                if normalized_source in normalized_record_ids:
                    rows.append(
                        _row_with_columns(
                            {
                                "owner_id": owner_id,
                                "source_id": normalized_source,
                                "subject_kind": "record",
                            },
                            _CITES_ORACLE_COLUMNS,
                        )
                    )

    return rows


def _expected_spouse_rows(
    record: EntityRecord,
    normalized_record_ids: set[str],
) -> list[dict[str, object]]:
    family_id = _normalize_id(record.entity_id)
    husband = _first_reference(record, "HUSB")
    wife = _first_reference(record, "WIFE")
    if (
        husband is None
        or wife is None
        or husband not in normalized_record_ids
        or wife not in normalized_record_ids
    ):
        return []
    return [
        _row_with_columns(
            {"family_id": family_id, "parent_id": husband, "spouse_id": wife},
            _SPOUSE_ORACLE_COLUMNS,
        ),
        _row_with_columns(
            {"family_id": family_id, "parent_id": wife, "spouse_id": husband},
            _SPOUSE_ORACLE_COLUMNS,
        ),
    ]


def _expected_parent_rows(
    record: EntityRecord,
    normalized_record_ids: set[str],
) -> list[dict[str, object]]:
    family_id = _normalize_id(record.entity_id)
    husband = _first_reference(record, "HUSB")
    wife = _first_reference(record, "WIFE")
    children = _all_references(record, "CHIL")
    rows: list[dict[str, object]] = []

    for child in children:
        if child not in normalized_record_ids:
            continue
        for parent in (husband, wife):
            if parent is None or parent not in normalized_record_ids:
                continue
            rows.append(
                _row_with_columns(
                    {"family_id": family_id, "parent_id": parent, "child_id": child},
                    _PARENT_ORACLE_COLUMNS,
                )
            )

    return rows


def _entity_oracle_columns() -> tuple[str, ...]:
    return tuple(column_name for column_name, _ in _entity_node_columns())


def _row_with_columns(
    values: Mapping[str, object | None],
    columns: Sequence[str],
) -> dict[str, object | None]:
    return {column: values.get(column) for column in columns}


def _row_sort_key(row: Mapping[str, object], columns: Sequence[str]) -> tuple[str, ...]:
    return tuple("" if row.get(column) is None else str(row.get(column)) for column in columns)


def _cypher_id_predicate(column_name: str, values: set[str]) -> str:
    joined_values = ", ".join(f"'{value}'" for value in sorted(values))
    return f"{column_name} IN [{joined_values}]"


def _normalize_id(entity_id: str | None) -> str:
    return normalize_entity_id(entity_id)
