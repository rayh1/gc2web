"""Cache-path helpers for GEDCOM-derived artifacts."""

from __future__ import annotations

import fcntl
import hashlib
import shutil
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from uuid import uuid4

from gedq.errors import UserError

METADATA_FILENAME = "metadata.json"
INDEX_FILENAME = "index.json"
DATABASE_FILENAME = "graph.ladybug"
STALE_CACHE_SUFFIXES = (".wal", ".checkpoint")


def resolve_cache_base(cache_base: Path) -> Path:
    """Normalize and validate an explicit cache base path."""
    resolved_base = cache_base.expanduser().resolve(strict=False)
    if resolved_base.exists() and not resolved_base.is_dir():
        raise UserError(f"Cache base is not a directory: {cache_base}")
    return resolved_base


def cache_dir_for(ged_path: Path, cache_base: Path | None = None) -> Path:
    """Return the cache directory for a GEDCOM source path.

    Args:
        ged_path: The source GEDCOM path.
        cache_base: Optional base directory for relocatable caches.

    Returns:
        The cache directory stored beside the GEDCOM file or under a custom base.
    """
    if cache_base is not None:
        resolved_ged = ged_path.expanduser().resolve(strict=False)
        base_dir = resolve_cache_base(cache_base)
        path_hash = hashlib.sha256(str(resolved_ged).encode("utf-8")).hexdigest()[:16]
        return base_dir / f"{resolved_ged.name}-{path_hash}"
    return ged_path.with_name(f"{ged_path.name}.ladybug")


def metadata_path_for(ged_path: Path, cache_base: Path | None = None) -> Path:
    """Return the metadata path for a GEDCOM source path."""
    return metadata_path_in(cache_dir_for(ged_path, cache_base=cache_base))


def index_path_for(ged_path: Path, cache_base: Path | None = None) -> Path:
    """Return the derived index path for a GEDCOM source path."""
    return index_path_in(cache_dir_for(ged_path, cache_base=cache_base))


def database_path_for(ged_path: Path, cache_base: Path | None = None) -> Path:
    """Return the Ladybug database path for a GEDCOM source path."""
    return database_path_in(cache_dir_for(ged_path, cache_base=cache_base))


def metadata_path_in(cache_dir: Path) -> Path:
    """Return the metadata path inside a resolved cache directory."""
    return cache_dir / METADATA_FILENAME


def index_path_in(cache_dir: Path) -> Path:
    """Return the derived index path inside a resolved cache directory."""
    return cache_dir / INDEX_FILENAME


def database_path_in(cache_dir: Path) -> Path:
    """Return the Ladybug database path inside a resolved cache directory."""
    return cache_dir / DATABASE_FILENAME


def stale_artifact_paths_in(cache_dir: Path) -> tuple[Path, ...]:
    """Return stale sidecar artifact paths that force directory-scoped recovery."""
    database_path = database_path_in(cache_dir)
    return tuple(
        path
        for path in (
            database_path.with_name(f"{database_path.name}{suffix}")
            for suffix in STALE_CACHE_SUFFIXES
        )
        if path.exists()
    )


def ensure_resolved_cache_dir(cache_dir: Path) -> Path:
    """Create a resolved cache directory if it does not already exist."""
    try:
        cache_dir.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        message = exc.strerror or str(exc)
        raise UserError(f"Unable to create cache directory {cache_dir}: {message}") from exc
    return cache_dir


def ensure_cache_dir(ged_path: Path, cache_base: Path | None = None) -> Path:
    """Create the cache directory if it does not already exist."""
    cache_dir = cache_dir_for(ged_path, cache_base=cache_base)
    return ensure_resolved_cache_dir(cache_dir)


@dataclass(frozen=True)
class CacheCoordinator:
    """Manage active, staging, and quarantine cache directories."""

    active_dir: Path

    @classmethod
    def for_source(cls, ged_path: Path, *, cache_base: Path | None = None) -> CacheCoordinator:
        """Build a coordinator for the resolved cache directory of a GEDCOM source."""
        return cls(active_dir=cache_dir_for(ged_path, cache_base=cache_base))

    def create_staging_dir(self) -> Path:
        """Allocate a private sibling staging directory for a new cache build."""
        ensure_resolved_cache_dir(self.active_dir.parent)
        staging_dir = self.active_dir.parent / f".{self.active_dir.name}.staging-{uuid4().hex}"
        return ensure_resolved_cache_dir(staging_dir)

    def clone_active_cache_to_staging(self) -> Path:
        """Copy the published cache into a private staging directory for mutation."""
        if not self.active_dir.is_dir():
            raise UserError(f"Active cache directory is not readable: {self.active_dir}")
        staging_dir = self.create_staging_dir()
        try:
            shutil.copytree(self.active_dir, staging_dir, dirs_exist_ok=True)
        except OSError as exc:
            message = exc.strerror or str(exc)
            raise UserError(
                f"Unable to stage active cache directory {self.active_dir}: {message}"
            ) from exc
        return staging_dir

    def stale_artifact_paths(self) -> tuple[Path, ...]:
        """Return stale sidecars in the active cache directory, if any."""
        return stale_artifact_paths_in(self.active_dir)

    @property
    def lease_path(self) -> Path:
        """Return the filesystem lock path for this cache directory."""
        return self.active_dir.parent / f".{self.active_dir.name}.lease"

    @contextmanager
    def acquire_build_lease(self) -> Iterator[None]:
        """Serialize staged publish and recovery work for one cache directory."""
        ensure_resolved_cache_dir(self.active_dir.parent)
        with self.lease_path.open("a+b") as handle:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)

    def quarantine_active_cache(self) -> Path | None:
        """Move the active cache directory aside for recovery, if it exists."""
        if not self.active_dir.exists():
            return None
        quarantine_dir = (
            self.active_dir.parent / f".{self.active_dir.name}.quarantine-{uuid4().hex}"
        )
        try:
            self.active_dir.replace(quarantine_dir)
        except OSError as exc:
            message = exc.strerror or str(exc)
            raise UserError(
                f"Unable to quarantine cache directory {self.active_dir}: {message}"
            ) from exc
        return quarantine_dir

    def publish(self, staged_dir: Path) -> Path:
        """Publish a finished staging directory as the active cache directory."""
        if staged_dir.parent != self.active_dir.parent:
            raise UserError("Staging directory must be a sibling of the active cache directory")
        if not staged_dir.is_dir():
            raise UserError(f"Staging directory is not readable: {staged_dir}")
        if self.active_dir.exists():
            raise UserError(
                "Active cache directory already exists and must be quarantined first: "
                f"{self.active_dir}"
            )
        try:
            staged_dir.replace(self.active_dir)
        except OSError as exc:
            message = exc.strerror or str(exc)
            raise UserError(f"Unable to publish staged cache {staged_dir}: {message}") from exc
        return self.active_dir
