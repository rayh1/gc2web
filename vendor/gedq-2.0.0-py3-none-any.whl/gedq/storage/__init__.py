"""Storage and cache helpers for gedq."""
