"""Explicit coverage threshold checks for repository verification."""

from __future__ import annotations

import argparse
import json
import sys
from collections.abc import Sequence
from pathlib import Path


def load_totals(report_path: Path) -> tuple[float, float]:
    """Load statement and branch coverage totals from one JSON report."""
    payload = json.loads(report_path.read_text())
    totals = payload["totals"]
    return float(totals["percent_statements_covered"]), float(totals["percent_branches_covered"])


def evaluate_thresholds(
    *,
    line_coverage: float,
    branch_coverage: float,
    line_min: float = 90.0,
    branch_min: float = 85.0,
) -> list[str]:
    """Return any threshold failures for the provided coverage totals."""
    failures: list[str] = []
    if line_coverage < line_min:
        failures.append(f"line coverage {line_coverage:.2f}% is below required {line_min:.2f}%")
    if branch_coverage < branch_min:
        failures.append(
            f"branch coverage {branch_coverage:.2f}% is below required {branch_min:.2f}%"
        )
    return failures


def main(argv: Sequence[str] | None = None) -> None:
    """Check line and branch coverage totals from a JSON report."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("report_path", help="Path to a coverage JSON report file")
    parser.add_argument("--line-min", type=float, default=90.0)
    parser.add_argument("--branch-min", type=float, default=85.0)
    args = parser.parse_args(list(argv) if argv is not None else None)

    line_coverage, branch_coverage = load_totals(Path(args.report_path))
    failures = evaluate_thresholds(
        line_coverage=line_coverage,
        branch_coverage=branch_coverage,
        line_min=args.line_min,
        branch_min=args.branch_min,
    )
    if failures:
        raise SystemExit("\n".join(failures))

    sys.stdout.write(f"line coverage {line_coverage:.2f}% >= {args.line_min:.2f}%\n")
    sys.stdout.write(f"branch coverage {branch_coverage:.2f}% >= {args.branch_min:.2f}%\n")
