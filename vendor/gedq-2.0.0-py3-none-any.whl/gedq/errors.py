"""Typed application errors and JSON error payloads for gedq."""

from __future__ import annotations

from typing import ClassVar

from pydantic import BaseModel, ConfigDict


class ErrorLocation(BaseModel):
    """Structured source location metadata for an error."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    path: str | None = None
    line: int | None = None
    column: int | None = None


class ErrorDetail(BaseModel):
    """Structured user-facing error payload."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    code: int
    message: str
    location: ErrorLocation | None = None


class ErrorEnvelope(BaseModel):
    """Top-level JSON error envelope for CLI failures."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    error: ErrorDetail


class AppError(Exception):
    """Base class for application-level failures.

    Args:
        message: Human-readable failure description.
        location: Optional structured location metadata.
    """

    code: ClassVar[int] = 3

    def __init__(self, message: str, location: ErrorLocation | None = None) -> None:
        """Initialize an application-level failure.

        Args:
            message: Human-readable failure description.
            location: Optional structured location metadata.
        """
        super().__init__(message)
        self.message = message
        self.location = location

    def to_envelope(self) -> ErrorEnvelope:
        """Convert the exception into the CLI JSON error contract.

        Returns:
            The typed JSON error envelope for this failure.
        """
        return ErrorEnvelope(
            error=ErrorDetail(code=self.code, message=self.message, location=self.location)
        )


class UserError(AppError):
    """User-facing input or contract error."""

    code = 1


class ParseDataError(AppError):
    """Parse or data-integrity error raised while reading GEDCOM input."""

    code = 2


class InternalError(AppError):
    """Unexpected internal application error."""

    code = 3
