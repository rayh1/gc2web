"""ASCII tree rendering helpers."""

from __future__ import annotations

from collections.abc import Sequence

BRANCH_MORE = "├─"
BRANCH_LAST = "└─"
SPOUSE_PREFIX = "× "
CONTINUATION_INDENT = "│    "
CHILD_INDENT = "     "
ANSI_RESET = "\033[0m"
ANSI_BY_GLYPH = {
    "⚠": "\033[33m",
    "○": "\033[34m",
    "◍": "\033[35m",
    "✗": "\033[31m",
}


def branch_line(indent: str, label: str, *, is_last: bool = True, spouse: bool = False) -> str:
    """Render one branch line with deterministic branch and spouse markers."""
    branch = BRANCH_LAST if is_last else BRANCH_MORE
    prefix = f"{branch} {SPOUSE_PREFIX}" if spouse else f"{branch} "
    return f"{indent}{prefix}{label}"


def child_indent(indent: str, *, has_more_siblings: bool) -> str:
    """Return the next child indentation level with optional continuation column."""
    return indent + (CONTINUATION_INDENT if has_more_siblings else CHILD_INDENT)


def format_annotation(glyph: str, note: str | None, *, color_mode: str) -> str:
    """Render one outward annotation token, optionally with ANSI color."""
    text = glyph if not note else f"{glyph} {note}"
    if color_mode == "never":
        return text
    color = ANSI_BY_GLYPH.get(glyph)
    if color is None:
        return text
    return f"{color}{text}{ANSI_RESET}"


def render_tree_output(lines: Sequence[str]) -> str:
    """Serialize the rendered tree lines for CLI output."""
    return "\n".join(lines)
