"""Renderer package for gedq."""
