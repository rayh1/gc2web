"""JSON and JSON Lines renderer for gedq output."""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from copy import deepcopy

from gedq.model.output import (
    OutputRecord,
    serialize_output_event_payload,
    serialize_output_record_payload,
    suppress_duplicate_source_text,
    suppress_shadow_raw_fields,
)
from gedq.model.output_keys import field_contract_specs

_BASE_PRESERVED_NULL_FIELDS = {
    "lifespan_years",
    "current_age",
    "age_at_event",
    "marriage_age_husb",
    "marriage_age_wife",
    "age_gap_years",
    "marriage_duration_years",
    "years_to_first_child",
    "years_between_first_and_last_child",
}
_PRESERVED_NULL_SUFFIXES = (
    "_confidence",
    "_full",
    "_min",
    "_max",
    "_period_start",
    "_period_end",
    "_source_text",
    "_dual_year",
    "_era",
    "_era_year",
    "_min_era_year",
    "_max_era_year",
    "_calendar",
    "_calendar_original",
    "_parse_warning",
)


def render_record(
    record: OutputRecord,
    *,
    compact: bool = True,
    collapse_place: bool = False,
) -> str:
    """Render one output record as a JSON object string.

    Args:
        record: The record to render.
        compact: Whether to remove null/empty and placeholder fields.
        collapse_place: Whether to suppress repeated event place values.

    Returns:
        The compact JSON representation for the record.
    """
    payload = serialize_output_record_payload(
        record,
        record.model_dump(mode="json", exclude_none=not compact, exclude={"raw_fields"}),
    )
    payload["events"] = [serialize_output_event_payload(event) for event in record.events]
    payload.update(suppress_shadow_raw_fields(payload, record.raw_fields))
    payload = suppress_duplicate_source_text(payload)
    if collapse_place:
        _collapse_repeated_places(payload)
    if compact:
        payload = _compact_payload(payload, record.kind)
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


def render_jsonl(
    records: Sequence[OutputRecord],
    *,
    compact: bool = True,
    collapse_place: bool = False,
) -> str:
    """Render multiple records as JSON Lines.

    Args:
        records: The records to render.
        compact: Whether to remove null/empty and placeholder fields.
        collapse_place: Whether to suppress repeated event place values.

    Returns:
        One JSON object per line.
    """
    return "\n".join(
        render_record(record, compact=compact, collapse_place=collapse_place) for record in records
    )


def render_row(row: Mapping[str, object]) -> str:
    """Render one raw-query row as a compact JSON object string."""
    return json.dumps(dict(row), ensure_ascii=False, separators=(",", ":"))


def render_rows(rows: Sequence[Mapping[str, object]]) -> str:
    """Render raw-query rows as a single object or JSON Lines."""
    if not rows:
        return json.dumps([], ensure_ascii=False)
    if len(rows) == 1:
        return render_row(rows[0])
    return "\n".join(render_row(row) for row in rows)


def _collapse_repeated_places(payload: dict[str, object]) -> None:
    events = payload.get("events")
    if not isinstance(events, list):
        return
    seen: set[str] = set()
    for event in events:
        if not isinstance(event, dict):
            continue
        place = event.get("place")
        if not isinstance(place, str):
            continue
        if place in seen:
            event.pop("place", None)
            continue
        seen.add(place)


def _compact_payload(payload: dict[str, object], owner_kind: str) -> dict[str, object]:
    compacted = _prune_empty_values(deepcopy(payload), _preserved_null_keys(owner_kind))
    if not isinstance(compacted, dict):
        return {}
    _prune_placeholder_map(compacted)
    return compacted


def _prune_empty_values(value: object, preserved_null_keys: set[str]) -> object:
    if isinstance(value, dict):
        result: dict[str, object] = {}
        for key, item in value.items():
            normalized = _prune_empty_values(item, preserved_null_keys)
            if normalized is None and not _preserve_null_key(key, preserved_null_keys):
                continue
            if isinstance(normalized, (list, dict)) and not normalized:
                continue
            result[key] = normalized
        return result
    if isinstance(value, list):
        result_list = [_prune_empty_values(item, preserved_null_keys) for item in value]
        return [item for item in result_list if item is not None]
    return value


def _prune_placeholder_map(payload: dict[str, object]) -> None:
    lati = payload.get("LATI")
    longi = payload.get("LONG")
    if not isinstance(lati, str) or not isinstance(longi, str):
        return
    if lati.strip().upper() == "N45.0" and longi.strip().upper() == "W4.0":
        payload.pop("MAP", None)
        payload.pop("LATI", None)
        payload.pop("LONG", None)


def _preserve_null_key(key: str, preserved_null_keys: set[str]) -> bool:
    return key in preserved_null_keys or key.endswith(_PRESERVED_NULL_SUFFIXES)


def _preserved_null_keys(owner_kind: str) -> set[str]:
    return _BASE_PRESERVED_NULL_FIELDS | {
        spec.canonical_key
        for spec in field_contract_specs(owner_kind)
        if spec.emit_null_when_absent
    }
