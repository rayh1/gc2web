"""Human-readable renderer for gedq output."""

from __future__ import annotations

from collections.abc import Sequence

from gedq.model.output import OutputAssociation, OutputEvent, OutputRecord

MONTH_NAMES = {
    "JAN": "January",
    "FEB": "February",
    "MAR": "March",
    "APR": "April",
    "MAY": "May",
    "JUN": "June",
    "JUL": "July",
    "AUG": "August",
    "SEP": "September",
    "OCT": "October",
    "NOV": "November",
    "DEC": "December",
}


def render_compact(record: OutputRecord) -> str:
    """Render a compact human card for a record.

    Args:
        record: The record to render.

    Returns:
        The compact card output.
    """
    lines = [f"{record.kind} {record.entity_id or ''}".strip()]
    source_title = _source_title(record)
    if record.name is not None:
        lines.append(f"name: {_normalize_name(record.name)}")
    if source_title is not None:
        lines.append(f"title: {source_title}")
    if record.nickname is not None:
        lines.append(f"nickname: {record.nickname}")
    if record.date is not None:
        lines.append(f"{_summary_date_label(record)}: {_expand_date(record.date)}")
    if record.place is not None:
        lines.append(f"place: {record.place}")
    if record.relations:
        lines.append(f"relations: {', '.join(record.relations)}")
    return "\n".join(lines)


def render_full(record: OutputRecord) -> str:
    """Render the full dossier for a record.

    Args:
        record: The record to render.

    Returns:
        The expanded human-readable dossier.
    """
    lines = [render_compact(record)]
    for event in record.events:
        lines.append(_render_event(event))
    for association in record.associations:
        lines.append(_render_association(association))
    if record.note is not None:
        lines.append(f"note: {record.note}")
    if record.media_path is not None:
        lines.append(f"media: {record.media_path}")
    if record.source_text is not None:
        lines.append(f"source: {record.source_text}")
    return "\n".join(lines)


def render_narrative(record: OutputRecord) -> str:
    """Render a short narrative summary for a record.

    Args:
        record: The record to render.

    Returns:
        The narrative summary.
    """
    source_title = _source_title(record)
    name = (
        _normalize_name(record.name)
        if record.name is not None
        else source_title or record.entity_id or "Unknown"
    )
    date = _expand_date(record.date) if record.date is not None else "an unknown date"
    place = record.place or "an unknown place"
    event_phrase = f"a {record.date_tag} event" if record.date_tag is not None else "an event"
    return f"{name} is recorded with {event_phrase} on {date} in {place}."


def render_family_table(rows: Sequence[tuple[str, OutputRecord]]) -> str:
    """Render one deterministic family table for parent and child rows."""
    ordered_rows = _ordered_family_rows(rows)
    table_rows: list[tuple[str, str, str, str]] = []
    for _, record in ordered_rows:
        table_rows.append(
            (
                record.entity_id or "",
                _normalize_name(record.name) if record.name is not None else "",
                _event_date(record, "BIRT") or "",
                _event_date(record, "DEAT") or "",
            )
        )

    headers = ("id", "name", "birth", "death")
    widths = [len(header) for header in headers]
    for row in table_rows:
        for index, value in enumerate(row):
            widths[index] = max(widths[index], len(value))

    header = "  ".join(title.ljust(widths[index]) for index, title in enumerate(headers))
    lines = [header]
    for row in table_rows:
        padded_row = "  ".join(value.ljust(widths[index]) for index, value in enumerate(row))
        lines.append(padded_row.rstrip())
    return "\n".join(lines)


def _render_event(event: OutputEvent) -> str:
    parts = [f"event: {event.tag}"]
    if event.date is not None:
        parts.append(f"date: {_expand_date(event.date)}")
    if event.place is not None:
        parts.append(f"place: {event.place}")
    if event.address is not None:
        parts.append(f"address: {event.address}")
    if event.source_ids:
        parts.append(f"sources: {', '.join(event.source_ids)}")
    if event.associations:
        parts.append(
            "associations: "
            + "; ".join(
                _format_association_summary(association) for association in event.associations
            )
        )
    return " | ".join(parts)


def _render_association(association: OutputAssociation) -> str:
    return f"association: {_format_association_summary(association)}"


def _format_association_summary(association: OutputAssociation) -> str:
    parts = [association.target_id or "unknown"]
    if association.role is not None:
        parts.append(f"role: {association.role}")
    if association.source_ids:
        parts.append(f"sources: {', '.join(association.source_ids)}")
    return " | ".join(parts)


def _source_title(record: OutputRecord) -> str | None:
    if record.kind != "SOUR":
        return None
    value = record.raw_fields.get("TITL")
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        for item in value:
            if isinstance(item, str):
                return item
    return None


def _summary_date_label(record: OutputRecord) -> str:
    if record.date_tag is None:
        return "date"
    return f"date ({record.date_tag})"


def _ordered_family_rows(
    rows: Sequence[tuple[str, OutputRecord]],
) -> list[tuple[str, OutputRecord]]:
    parents = [row for row in rows if row[0] in {"HUSB", "WIFE"}]
    children = [row for row in rows if row[0] == "CHIL"]
    children.sort(key=lambda row: (_sortable_birth(row[1]), row[1].entity_id or ""))
    return parents + children


def _sortable_birth(record: OutputRecord) -> str:
    date_value = _event_date(record, "BIRT")
    if date_value is None:
        return "9999"
    tokens = date_value.split()
    return tokens[-1] if tokens else "9999"


def _event_date(record: OutputRecord, tag: str) -> str | None:
    for event in record.events:
        if event.tag == tag and event.date is not None:
            return event.date
    return None


def _normalize_name(name: str) -> str:
    if "/" not in name:
        return name

    first = name.find("/")
    second = name.find("/", first + 1)
    if second == -1:
        return name.replace("/", "").strip()

    before = name[:first].strip()
    surname = name[first + 1 : second].strip()
    after = name[second + 1 :].strip()
    given = " ".join(part for part in (before, after) if part)
    return " ".join(part for part in (given, surname) if part)


def _expand_date(date: str) -> str:
    tokens = date.split()
    if len(tokens) == 3 and tokens[1] in MONTH_NAMES:
        return f"{tokens[0]} {MONTH_NAMES[tokens[1]]} {tokens[2]}"
    return date
