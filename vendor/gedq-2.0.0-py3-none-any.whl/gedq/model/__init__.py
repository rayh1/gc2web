"""Internal GEDCOM model types for gedq."""

from gedq.model.tags import (
    EVENT_TAGS_BY_KIND,
    FAM_ATTRIBUTE_TAGS,
    FAM_EVENT_TAGS,
    INDI_ATTRIBUTE_TAGS,
    INDI_EVENT_TAGS,
    LDS_ORDINANCE_TAGS,
    WRITE_CHILD_FIELDS_BY_KIND,
    WRITE_EVENT_ALIASES_BY_KIND,
    WRITE_PARENT_ALIASES_BY_KIND,
    event_tags_for_kind,
    resolve_event_tag_alias,
    resolve_registered_parent_alias,
    supports_event_tag,
    supports_registered_child_field,
    supports_registered_parent_field,
)

__all__ = [
    "EVENT_TAGS_BY_KIND",
    "FAM_ATTRIBUTE_TAGS",
    "FAM_EVENT_TAGS",
    "INDI_ATTRIBUTE_TAGS",
    "INDI_EVENT_TAGS",
    "LDS_ORDINANCE_TAGS",
    "WRITE_CHILD_FIELDS_BY_KIND",
    "WRITE_EVENT_ALIASES_BY_KIND",
    "WRITE_PARENT_ALIASES_BY_KIND",
    "event_tags_for_kind",
    "resolve_event_tag_alias",
    "resolve_registered_parent_alias",
    "supports_event_tag",
    "supports_registered_child_field",
    "supports_registered_parent_field",
]
