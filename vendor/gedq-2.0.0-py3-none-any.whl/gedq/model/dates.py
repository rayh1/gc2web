"""GEDCOM date parsing and query-facet helpers."""

from __future__ import annotations

from calendar import monthrange
from dataclasses import dataclass
from datetime import date
from typing import Literal

from pydantic import BaseModel, ConfigDict

MONTH_NUMBERS = {
    "JAN": 1,
    "FEB": 2,
    "MAR": 3,
    "APR": 4,
    "MAY": 5,
    "JUN": 6,
    "JUL": 7,
    "AUG": 8,
    "SEP": 9,
    "OCT": 10,
    "NOV": 11,
    "DEC": 12,
}
QUALIFIERS = {"ABT", "EST", "CAL", "BEF", "AFT"}
Confidence = Literal[
    "exact",
    "month_only",
    "year_only",
    "approximate",
    "calculated",
    "estimated",
    "interpreted",
    "dual_dating",
    "upper_bound",
    "lower_bound",
    "range",
    "phrase_only",
    "unknown",
]
CalendarCode = Literal["JULIAN", "HEBREW", "FRENCH_R", "ROMAN", "UNKNOWN"]
EraCode = Literal["BC", "AD"]


class DateDelta(BaseModel):
    """Exact date span rendered on computed-date sibling fields."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    years: int
    months: int
    days: int


class ComputedDateField(BaseModel):
    """Typed internal model for one computed date field before flattening."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    value: int | None = None
    confidence: Confidence
    full: DateDelta | None = None
    min: int | None = None
    max: int | None = None
    period_start: int | None = None
    period_end: int | None = None
    source_text: str | None = None
    dual_year: tuple[int, int] | None = None
    era: EraCode | None = None
    era_year: int | None = None
    min_era_year: int | None = None
    max_era_year: int | None = None
    calendar: CalendarCode | None = None
    calendar_original: str | None = None
    parse_warning: str | None = None


@dataclass(frozen=True)
class DateValue:
    """Derived GEDCOM date facets used for query semantics and output helpers."""

    raw: bytes
    qualifier: str | None
    year: int | None
    month: int | None
    day: int | None
    end_year: int | None = None
    end_month: int | None = None
    end_day: int | None = None
    confidence: Confidence = "unknown"
    supported: bool = True
    syntax_valid: bool = True
    exact_date: date | None = None
    source_text: str | None = None
    dual_year: tuple[int, int] | None = None
    era: EraCode | None = None
    era_year: int | None = None
    min_era_year: int | None = None
    max_era_year: int | None = None
    calendar: CalendarCode | None = None
    calendar_original: str | None = None
    parse_warning: str | None = None
    period_start: int | None = None
    period_end: int | None = None
    is_period: bool = False


@dataclass(frozen=True)
class _PointDate:
    year: int | None
    month: int | None
    day: int | None
    confidence: Confidence
    exact_date: date | None = None
    dual_year: tuple[int, int] | None = None
    era: EraCode | None = None
    era_year: int | None = None


@dataclass(frozen=True)
class _SimpleDateParseResult:
    value: _PointDate | None
    calendar_invalid: bool = False


def parse_date_value(raw: bytes | None) -> DateValue | None:
    """Parse GEDCOM date text into queryable facets.

    Args:
        raw: Raw GEDCOM date bytes.

    Returns:
        The derived date facets, or `None` when no date exists.
    """
    if raw is None:
        return None

    text = raw.decode("utf-8").strip()
    if not text:
        return DateValue(raw=raw, qualifier=None, year=None, month=None, day=None)

    if calendar_value := _parse_calendar_date(raw, text):
        return calendar_value

    if phrase_value := _parse_phrase_only_date(raw, text):
        return phrase_value

    parsed_simple = _parse_simple_date(text)
    if parsed_simple.value is not None:
        return DateValue(
            raw=raw,
            qualifier=None,
            year=parsed_simple.value.year,
            month=parsed_simple.value.month,
            day=parsed_simple.value.day,
            confidence=parsed_simple.value.confidence,
            exact_date=parsed_simple.value.exact_date,
            dual_year=parsed_simple.value.dual_year,
            era=parsed_simple.value.era,
            era_year=parsed_simple.value.era_year,
        )

    if parsed_simple.calendar_invalid:
        return _unsupported_date_value(raw, text, syntax_valid=True)

    if qualified_value := _parse_qualified_date(raw, text):
        return qualified_value

    if range_value := _parse_range_date(raw, text):
        return range_value

    if period_value := _parse_period_date(raw, text):
        return period_value

    return _unsupported_date_value(raw, text, syntax_valid=False)


def _unsupported_date_value(
    raw: bytes,
    text: str,
    *,
    qualifier: str | None = None,
    syntax_valid: bool,
) -> DateValue:
    return DateValue(
        raw=raw,
        qualifier=qualifier,
        year=None,
        month=None,
        day=None,
        supported=False,
        syntax_valid=syntax_valid,
        parse_warning=text,
    )


def normalize_date_field(
    value: DateValue | None,
    *,
    period_aware: bool = False,
) -> ComputedDateField:
    """Normalize one parsed GEDCOM date into the public sibling-field contract."""
    if value is None:
        return ComputedDateField(value=None, confidence="unknown")

    if not value.supported:
        return ComputedDateField(
            value=None,
            confidence="unknown",
            parse_warning=value.parse_warning or value.raw.decode("utf-8").strip(),
        )

    if value.is_period and not period_aware:
        return ComputedDateField(
            value=None,
            confidence="unknown",
            parse_warning=value.raw.decode("utf-8").strip(),
        )

    if value.is_period:
        return ComputedDateField(
            value=None,
            confidence="range",
            period_start=value.period_start,
            period_end=value.period_end,
        )

    if value.confidence in {
        "exact",
        "month_only",
        "year_only",
        "approximate",
        "calculated",
        "estimated",
        "interpreted",
        "dual_dating",
    }:
        payload: dict[str, object | None] = {
            "value": value.year if value.era is None else None,
            "confidence": value.confidence,
        }
        if value.confidence == "interpreted":
            payload["source_text"] = value.source_text
        elif value.source_text is not None:
            payload["source_text"] = value.source_text
        if value.dual_year is not None:
            payload["dual_year"] = value.dual_year
        if value.era is not None:
            payload["era"] = value.era
        if value.era_year is not None:
            payload["era_year"] = value.era_year
        if value.calendar is not None:
            payload["calendar"] = value.calendar
        if value.calendar_original is not None:
            payload["calendar_original"] = value.calendar_original
        if value.parse_warning is not None:
            payload["parse_warning"] = value.parse_warning
        return ComputedDateField.model_validate(payload)

    if value.confidence == "upper_bound":
        payload = {"value": None, "confidence": "upper_bound"}
        if value.year is not None:
            payload["max"] = value.year
        if value.era is not None:
            payload["era"] = value.era
        if value.max_era_year is not None:
            payload["max_era_year"] = value.max_era_year
        return ComputedDateField.model_validate(payload)

    if value.confidence == "lower_bound":
        payload = {"value": None, "confidence": "lower_bound"}
        if value.year is not None:
            payload["min"] = value.year
        if value.era is not None:
            payload["era"] = value.era
        if value.min_era_year is not None:
            payload["min_era_year"] = value.min_era_year
        return ComputedDateField.model_validate(payload)

    if value.confidence == "range":
        payload = {"value": None, "confidence": "range"}
        if value.year is not None:
            payload["min"] = value.year
        if value.end_year is not None:
            payload["max"] = value.end_year
        if value.era is not None:
            payload["era"] = value.era
        if value.min_era_year is not None:
            payload["min_era_year"] = value.min_era_year
        if value.max_era_year is not None:
            payload["max_era_year"] = value.max_era_year
        return ComputedDateField.model_validate(payload)

    if value.confidence == "phrase_only":
        return ComputedDateField(
            value=None,
            confidence="phrase_only",
            source_text=value.source_text,
        )

    return ComputedDateField(
        value=None,
        confidence="unknown",
        calendar=value.calendar,
        calendar_original=value.calendar_original,
        parse_warning=value.parse_warning,
    )


def exact_year_difference(start: DateValue, end: DateValue) -> ComputedDateField:
    """Return an exact date difference when both endpoints support exact arithmetic."""
    if start.exact_date is None or end.exact_date is None:
        raise ValueError("exact arithmetic requires exact boundary dates")

    full = _difference_parts(start.exact_date, end.exact_date)
    return ComputedDateField(value=full.years, confidence="exact", full=full)


def fallback_difference(
    *values: DateValue | None,
    period_aware_index: int | None = None,
) -> ComputedDateField:
    """Return the first non-exact normalized fallback among the contributing dates."""
    for index, value in enumerate(values):
        if value is None:
            return ComputedDateField(value=None, confidence="unknown")
        if value.exact_date is None:
            return _degrade_derived_field(
                normalize_date_field(value, period_aware=period_aware_index == index)
            )
    return ComputedDateField(value=None, confidence="unknown")


def supports_exact_arithmetic(value: DateValue | None) -> bool:
    """Return whether a parsed GEDCOM date supports exact arithmetic."""
    return value is not None and value.exact_date is not None


def earliest_possible_date(value: DateValue | None) -> date | None:
    """Return the earliest supported date implied by one parsed GEDCOM date."""
    if value is None or not value.supported or value.confidence == "phrase_only":
        return None
    if value.exact_date is not None:
        return value.exact_date
    if value.confidence in {"month_only", "year_only", "dual_dating"} and value.year is not None:
        month = value.month or 1
        day = value.day or 1
        return _safe_date(value.year, month, day)
    if value.confidence in {"approximate", "calculated", "estimated", "interpreted"}:
        if value.year is None:
            return None
        return date(value.year - 1, 1, 1)
    if value.confidence == "lower_bound" and value.year is not None:
        return date(value.year + 1, 1, 1)
    if value.confidence == "range":
        return _safe_date(value.year, value.month, value.day)
    return None


def latest_possible_date(value: DateValue | None) -> date | None:
    """Return the latest supported date implied by one parsed GEDCOM date."""
    if value is None or not value.supported or value.confidence == "phrase_only":
        return None
    if value.exact_date is not None:
        return value.exact_date
    if value.confidence == "month_only" and value.year is not None and value.month is not None:
        return date(value.year, value.month, monthrange(value.year, value.month)[1])
    if value.confidence in {"year_only", "dual_dating"} and value.year is not None:
        return date(value.year, 12, 31)
    if value.confidence in {"approximate", "calculated", "estimated", "interpreted"}:
        if value.year is None:
            return None
        return date(value.year + 1, 12, 31)
    if value.confidence == "upper_bound" and value.year is not None:
        return date(value.year - 1, 12, 31)
    if value.confidence == "range":
        return _safe_date(value.end_year, value.end_month, value.end_day, latest=True)
    return None


def _safe_date(
    year: int | None,
    month: int | None,
    day: int | None,
    *,
    latest: bool = False,
) -> date | None:
    if year is None:
        return None
    resolved_month = month or (12 if latest else 1)
    if day is None:
        resolved_day = monthrange(year, resolved_month)[1] if latest else 1
    else:
        resolved_day = day
    return date(year, resolved_month, resolved_day)


def flatten_computed_field(
    prefix: str,
    field: ComputedDateField,
    *,
    full_key: str | None = None,
) -> dict[str, object | None]:
    """Flatten one typed computed-date model to its public sibling keys."""
    result: dict[str, object | None] = {
        prefix: field.value,
        f"{prefix}_confidence": field.confidence,
    }
    field_set = set(field.model_fields_set)
    mapping = {
        "full": full_key or f"{prefix}_full",
        "min": f"{prefix}_min",
        "max": f"{prefix}_max",
        "period_start": f"{prefix}_period_start",
        "period_end": f"{prefix}_period_end",
        "source_text": f"{prefix}_source_text",
        "dual_year": f"{prefix}_dual_year",
        "era": f"{prefix}_era",
        "era_year": f"{prefix}_era_year",
        "min_era_year": f"{prefix}_min_era_year",
        "max_era_year": f"{prefix}_max_era_year",
        "calendar": f"{prefix}_calendar",
        "calendar_original": f"{prefix}_calendar_original",
        "parse_warning": f"{prefix}_parse_warning",
    }
    for attribute, key in mapping.items():
        value = getattr(field, attribute)
        if value is None and attribute not in field_set:
            continue
        if isinstance(value, BaseModel):
            result[key] = value.model_dump(mode="json")
            continue
        result[key] = value
    return result


def _degrade_derived_field(field: ComputedDateField) -> ComputedDateField:
    payload: dict[str, object | None] = {"value": None, "confidence": field.confidence}
    for attribute in (
        "min",
        "max",
        "period_start",
        "period_end",
        "source_text",
        "dual_year",
        "era",
        "era_year",
        "min_era_year",
        "max_era_year",
        "calendar",
        "calendar_original",
        "parse_warning",
    ):
        value = getattr(field, attribute)
        if value is None and attribute not in field.model_fields_set:
            continue
        payload[attribute] = value
    return ComputedDateField.model_validate(payload)


def matches_year(value: DateValue, year: int) -> bool:
    """Match a derived date value against a query year.

    Args:
        value: The derived GEDCOM date facets.
        year: The query year to test.

    Returns:
        `True` when the date value matches the query year semantics.
    """
    if value.year is None:
        return False

    if value.qualifier in {"BET", "FROM"}:
        if value.end_year is None:
            return False
        return value.year <= year <= value.end_year

    if value.qualifier in {None, "ABT", "EST", "CAL", "INT"}:
        return value.year == year
    if value.qualifier == "BEF":
        return year < value.year
    if value.qualifier == "AFT":
        return year > value.year
    return False


def _parse_simple_date(text: str) -> _SimpleDateParseResult:
    tokens = text.split()
    if not tokens:
        return _SimpleDateParseResult(None)

    if len(tokens) == 2 and tokens[1] in {"B.C.", "BC"} and tokens[0].isdigit():
        return _SimpleDateParseResult(
            _PointDate(
                year=None,
                month=None,
                day=None,
                confidence="exact",
                era="BC",
                era_year=int(tokens[0]),
            )
        )

    if len(tokens) == 1 and (parsed_year := _parse_year_token(tokens[0])) is not None:
        year, dual_year = parsed_year
        return _SimpleDateParseResult(
            _PointDate(
                year=year,
                month=None,
                day=None,
                confidence="dual_dating" if dual_year is not None else "year_only",
                dual_year=dual_year,
            )
        )

    if len(tokens) == 2 and tokens[0] in MONTH_NUMBERS:
        parsed_year = _parse_year_token(tokens[1])
        if parsed_year is None:
            return _SimpleDateParseResult(None)
        year, dual_year = parsed_year
        return _SimpleDateParseResult(
            _PointDate(
                year=year,
                month=MONTH_NUMBERS[tokens[0]],
                day=None,
                confidence="dual_dating" if dual_year is not None else "month_only",
                dual_year=dual_year,
            )
        )

    if len(tokens) == 2 and tokens[0].isdigit() and tokens[1] in MONTH_NUMBERS:
        try:
            date(2000, MONTH_NUMBERS[tokens[1]], int(tokens[0]))
        except ValueError:
            return _SimpleDateParseResult(None, calendar_invalid=True)
        return _SimpleDateParseResult(
            _PointDate(
                year=None,
                month=MONTH_NUMBERS[tokens[1]],
                day=int(tokens[0]),
                confidence="unknown",
            )
        )

    if len(tokens) == 3 and tokens[0].isdigit() and tokens[1] in MONTH_NUMBERS:
        parsed_year = _parse_year_token(tokens[2])
        if parsed_year is None:
            return _SimpleDateParseResult(None)
        year, dual_year = parsed_year
        try:
            exact_date = date(year, MONTH_NUMBERS[tokens[1]], int(tokens[0]))
        except ValueError:
            return _SimpleDateParseResult(None, calendar_invalid=True)
        return _SimpleDateParseResult(
            _PointDate(
                year=year,
                month=MONTH_NUMBERS[tokens[1]],
                day=int(tokens[0]),
                confidence="dual_dating" if dual_year is not None else "exact",
                exact_date=exact_date,
                dual_year=dual_year,
            )
        )

    if (
        len(tokens) == 4
        and tokens[0].isdigit()
        and tokens[1] in MONTH_NUMBERS
        and tokens[3] in {"B.C.", "BC"}
        and tokens[2].isdigit()
    ):
        return _SimpleDateParseResult(
            _PointDate(
                year=None,
                month=MONTH_NUMBERS[tokens[1]],
                day=int(tokens[0]),
                confidence="exact",
                era="BC",
                era_year=int(tokens[2]),
            )
        )

    return _SimpleDateParseResult(None)


def _parse_qualified_date(raw: bytes, text: str) -> DateValue | None:
    tokens = text.split()
    if len(tokens) < 2:
        return None

    qualifier = tokens[0]
    if qualifier not in QUALIFIERS | {"INT"}:
        return None

    remainder = text[len(qualifier) :].strip()
    source_text: str | None = None
    if qualifier == "INT":
        remainder, source_text = _split_interpreted_remainder(remainder)
        if not remainder:
            return _unsupported_date_value(raw, text, qualifier="INT", syntax_valid=False)

    parsed = _parse_simple_date(remainder)
    if parsed.value is None:
        return _unsupported_date_value(
            raw,
            text,
            qualifier=qualifier,
            syntax_valid=parsed.calendar_invalid,
        )

    point = parsed.value

    if qualifier in {"ABT", "CAL", "EST", "INT"}:
        confidence_map: dict[str, Confidence] = {
            "ABT": "approximate",
            "CAL": "calculated",
            "EST": "estimated",
            "INT": "interpreted",
        }
        return DateValue(
            raw=raw,
            qualifier=qualifier,
            year=point.year,
            month=point.month,
            day=point.day,
            confidence=confidence_map[qualifier],
            source_text=source_text,
            dual_year=point.dual_year,
            era=point.era,
            era_year=point.era_year,
            calendar=None,
        )

    if qualifier == "BEF":
        return DateValue(
            raw=raw,
            qualifier=qualifier,
            year=point.year,
            month=point.month,
            day=point.day,
            confidence="upper_bound",
            era=point.era,
            max_era_year=point.era_year,
        )

    return DateValue(
        raw=raw,
        qualifier=qualifier,
        year=point.year,
        month=point.month,
        day=point.day,
        confidence="lower_bound",
        era=point.era,
        min_era_year=point.era_year,
    )


def _parse_range_date(raw: bytes, text: str) -> DateValue | None:
    if not text.startswith("BET ") or " AND " not in text:
        return None

    start_text, end_text = text[4:].split(" AND ", 1)
    start = _parse_simple_date(start_text)
    end = _parse_simple_date(end_text)
    if start.value is None or end.value is None:
        syntax_valid = all(
            result.value is not None or result.calendar_invalid for result in (start, end)
        ) and any(result.value is None and result.calendar_invalid for result in (start, end))
        return _unsupported_date_value(raw, text, qualifier="BET", syntax_valid=syntax_valid)

    start_point = start.value
    end_point = end.value

    min_era_year: int | None = None
    max_era_year: int | None = None
    era: EraCode | None = None
    if (
        start_point.era == end_point.era == "BC"
        and start_point.era_year is not None
        and end_point.era_year is not None
    ):
        era = "BC"
        min_era_year = max(start_point.era_year, end_point.era_year)
        max_era_year = min(start_point.era_year, end_point.era_year)

    return DateValue(
        raw=raw,
        qualifier="BET",
        year=start_point.year,
        month=start_point.month,
        day=start_point.day,
        end_year=end_point.year,
        end_month=end_point.month,
        end_day=end_point.day,
        confidence="range",
        era=era,
        min_era_year=min_era_year,
        max_era_year=max_era_year,
    )


def _parse_period_date(raw: bytes, text: str) -> DateValue | None:
    if text.startswith("FROM "):
        body = text[5:]
        if " TO " in body:
            start_text, end_text = body.split(" TO ", 1)
        else:
            start_text, end_text = body, None
    elif text.startswith("TO "):
        start_text, end_text = None, text[3:]
    else:
        return None

    start = _parse_simple_date(start_text) if start_text is not None else None
    end = _parse_simple_date(end_text) if end_text is not None else None
    if (start_text is not None and start is not None and start.value is None) or (
        end_text is not None and end is not None and end.value is None
    ):
        results = tuple(result for result in (start, end) if result is not None)
        syntax_valid = all(
            result.value is not None or result.calendar_invalid for result in results
        ) and any(result.value is None and result.calendar_invalid for result in results)
        return _unsupported_date_value(
            raw,
            text,
            qualifier="FROM" if text.startswith("FROM ") else "TO",
            syntax_valid=syntax_valid,
        )

    start_point = None if start is None else start.value
    end_point = None if end is None else end.value

    return DateValue(
        raw=raw,
        qualifier="FROM" if text.startswith("FROM ") else "TO",
        year=start_point.year if start_point is not None else None,
        month=start_point.month if start_point is not None else None,
        day=start_point.day if start_point is not None else None,
        end_year=end_point.year if end_point is not None else None,
        end_month=end_point.month if end_point is not None else None,
        end_day=end_point.day if end_point is not None else None,
        confidence="range",
        period_start=start_point.year if start_point is not None else None,
        period_end=end_point.year if end_point is not None else None,
        is_period=True,
    )


def _parse_phrase_only_date(raw: bytes, text: str) -> DateValue | None:
    if not (text.startswith("(") and text.endswith(")")):
        return None

    return DateValue(
        raw=raw,
        qualifier=None,
        year=None,
        month=None,
        day=None,
        confidence="phrase_only",
        source_text=text[1:-1] or None,
    )


def _parse_calendar_date(raw: bytes, text: str) -> DateValue | None:
    if not text.startswith("@#D"):
        return None

    marker_end = text.find("@", 3)
    if marker_end == -1:
        return _unsupported_date_value(raw, text, syntax_valid=False)

    calendar_tag = text[3:marker_end].strip().upper()
    payload = text[marker_end + 1 :].strip()
    calendar_map: dict[str, CalendarCode] = {
        "JULIAN": "JULIAN",
        "HEBREW": "HEBREW",
        "FRENCH R": "FRENCH_R",
        "ROMAN": "ROMAN",
        "UNKNOWN": "UNKNOWN",
    }
    calendar_code = calendar_map.get(calendar_tag, "UNKNOWN")
    if calendar_code != "JULIAN":
        return DateValue(
            raw=raw,
            qualifier=None,
            year=None,
            month=None,
            day=None,
            confidence="unknown",
            calendar=calendar_code,
            calendar_original=payload,
        )

    parsed = _parse_simple_date(payload)
    if (
        parsed.value is None
        or parsed.value.day is None
        or parsed.value.month is None
        or parsed.value.year is None
    ):
        return _unsupported_date_value(
            raw,
            text,
            syntax_valid=parsed.value is None and parsed.calendar_invalid,
        )

    point = parsed.value
    year = point.year
    month = point.month
    day = point.day
    assert year is not None
    assert month is not None
    assert day is not None

    gregorian = _julian_to_gregorian_date(year, month, day)
    return DateValue(
        raw=raw,
        qualifier=None,
        year=gregorian.year,
        month=gregorian.month,
        day=gregorian.day,
        confidence="exact",
        exact_date=gregorian,
        calendar="JULIAN",
        calendar_original=payload,
    )


def _parse_year_token(token: str) -> tuple[int, tuple[int, int] | None] | None:
    if token.isdigit():
        return int(token), None
    if "/" not in token:
        return None
    left, right = token.split("/", 1)
    if not left.isdigit() or not right.isdigit():
        return None
    first = int(left)
    second = _expand_dual_year(first, right)
    return second, (first, second)


def _expand_dual_year(first: int, second_text: str) -> int:
    candidate: int = int(second_text)
    width = len(second_text)
    base: int = first - (first % (10**width))
    second: int = base + candidate
    if second <= first:
        second += 10**width
    return second


def _split_interpreted_remainder(remainder: str) -> tuple[str, str | None]:
    if not remainder.endswith(")") or "(" not in remainder:
        return remainder, None
    base, _, phrase = remainder.partition("(")
    phrase_text = phrase[:-1]
    return base.strip(), phrase_text or None


def _difference_parts(start: date, end: date) -> DateDelta:
    years = end.year - start.year
    months = end.month - start.month
    days = end.day - start.day

    if days < 0:
        months -= 1
        previous_month = 12 if end.month == 1 else end.month - 1
        previous_year = end.year - 1 if end.month == 1 else end.year
        days += monthrange(previous_year, previous_month)[1]

    if months < 0:
        years -= 1
        months += 12

    return DateDelta(years=years, months=months, days=days)


def _julian_to_gregorian_date(year: int, month: int, day: int) -> date:
    julian_day = _julian_day_number(year, month, day)
    return _gregorian_date_from_jdn(julian_day)


def _julian_day_number(year: int, month: int, day: int) -> int:
    a = (14 - month) // 12
    shifted_year = year + 4800 - a
    shifted_month = month + 12 * a - 3
    return day + ((153 * shifted_month + 2) // 5) + 365 * shifted_year + shifted_year // 4 - 32083


def _gregorian_date_from_jdn(julian_day: int) -> date:
    a = julian_day + 32044
    b = (4 * a + 3) // 146097
    c = a - (146097 * b) // 4
    d = (4 * c + 3) // 1461
    e = c - (1461 * d) // 4
    m = (5 * e + 2) // 153

    day = e - (153 * m + 2) // 5 + 1
    month = m + 3 - 12 * (m // 10)
    year = 100 * b + d - 4800 + m // 10
    return date(year, month, day)
