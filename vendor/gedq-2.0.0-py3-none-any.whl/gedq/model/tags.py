"""Shared GEDCOM 5.5.1 event-tag catalog helpers."""

from __future__ import annotations

from types import MappingProxyType

INDI_EVENT_TAGS = frozenset(
    {
        "ADOP",
        "BAPM",
        "BARM",
        "BASM",
        "BIRT",
        "BLES",
        "BURI",
        "CENS",
        "CHR",
        "CHRA",
        "CONF",
        "CREM",
        "DEAT",
        "EMIG",
        "EVEN",
        "FCOM",
        "GRAD",
        "IMMI",
        "NATU",
        "ORDN",
        "PROB",
        "RETI",
        "WILL",
    }
)
INDI_ATTRIBUTE_TAGS = frozenset(
    {
        "CAST",
        "DSCR",
        "EDUC",
        "FACT",
        "IDNO",
        "NATI",
        "NCHI",
        "NMR",
        "OCCU",
        "PROP",
        "RELI",
        "RESI",
        "SSN",
        "TITL",
    }
)
FAM_EVENT_TAGS = frozenset(
    {
        "ANUL",
        "CENS",
        "DIV",
        "DIVF",
        "ENGA",
        "EVEN",
        "MARB",
        "MARC",
        "MARL",
        "MARR",
        "MARS",
    }
)
FAM_ATTRIBUTE_TAGS = frozenset({"FACT", "NCHI", "RESI"})
LDS_ORDINANCE_TAGS = frozenset({"BAPL", "CONL", "ENDL", "SLGC", "SLGS"})

EVENT_TAGS_BY_KIND = MappingProxyType(
    {
        "INDI": INDI_EVENT_TAGS | INDI_ATTRIBUTE_TAGS | LDS_ORDINANCE_TAGS,
        "FAM": FAM_EVENT_TAGS | FAM_ATTRIBUTE_TAGS,
    }
)
WRITE_CHILD_FIELDS_BY_KIND = MappingProxyType(
    {
        "INDI": MappingProxyType(
            {
                "NAME": frozenset({"GIVN", "SURN", "NICK", "NPFX", "NSFX", "SPFX", "NOTE", "SOUR"}),
                "ASSO": frozenset({"RELA", "SOUR"}),
            }
        ),
        "FAM": MappingProxyType(
            {
                "ASSO": frozenset({"RELA", "SOUR"}),
            }
        ),
        "OBJE": MappingProxyType(
            {
                "FILE": frozenset({"FORM", "TITL"}),
            }
        ),
    }
)
PERSONAL_NAME_PIECE_TAGS = frozenset({"GIVN", "SURN", "NICK", "NPFX", "NSFX", "SPFX"})
WRITE_EVENT_ALIASES_BY_KIND = MappingProxyType(
    {
        kind: MappingProxyType({tag.lower(): tag for tag in sorted(tags)})
        for kind, tags in EVENT_TAGS_BY_KIND.items()
    }
)
WRITE_PARENT_ALIASES_BY_KIND = MappingProxyType(
    {
        kind: MappingProxyType({tag.lower(): tag for tag in sorted(parent_fields)})
        for kind, parent_fields in WRITE_CHILD_FIELDS_BY_KIND.items()
    }
)


def event_tags_for_kind(kind: str) -> frozenset[str]:
    """Return the supported event/attribute tags for one GEDCOM owner kind."""
    return EVENT_TAGS_BY_KIND.get(kind.strip().upper(), frozenset())


def supports_event_tag(kind: str, tag: str) -> bool:
    """Return whether one tag is part of the standard catalog for the owner kind."""
    return tag.strip().upper() in event_tags_for_kind(kind)


def resolve_event_tag_alias(kind: str, alias: str) -> str | None:
    """Resolve one lower-case dotted-field alias against the owner-kind catalog."""
    aliases = WRITE_EVENT_ALIASES_BY_KIND.get(kind.strip().upper())
    if aliases is None:
        return None
    return aliases.get(alias.strip().lower())


def resolve_registered_parent_alias(kind: str, alias: str) -> str | None:
    """Resolve one lower-case registered parent-field alias for dotted write paths."""
    aliases = WRITE_PARENT_ALIASES_BY_KIND.get(kind.strip().upper())
    if aliases is None:
        return None
    return aliases.get(alias.strip().lower())


def supports_registered_parent_field(kind: str, parent_tag: str) -> bool:
    """Return whether one field tag is a registered parent for nested write paths."""
    parent_fields = WRITE_CHILD_FIELDS_BY_KIND.get(kind.strip().upper())
    if parent_fields is None:
        return False
    return parent_tag.strip().upper() in parent_fields


def supports_registered_child_field(kind: str, parent_tag: str, child_tag: str) -> bool:
    """Return whether one registered parent supports the requested nested child tag."""
    parent_fields = WRITE_CHILD_FIELDS_BY_KIND.get(kind.strip().upper())
    if parent_fields is None:
        return False
    return child_tag.strip().upper() in parent_fields.get(parent_tag.strip().upper(), frozenset())
