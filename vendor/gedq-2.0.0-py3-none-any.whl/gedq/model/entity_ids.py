"""Shared entity-ID normalization helpers."""

from __future__ import annotations


def normalize_entity_id(entity_id: str | None) -> str:
    """Normalize wrapped or bare entity IDs without altering numeric shape."""
    if entity_id is None:
        return ""
    return entity_id.strip().strip("@").upper()


def canonical_entity_xref(entity_id: str) -> str:
    """Render a normalized entity ID in GEDCOM xref form."""
    return f"@{normalize_entity_id(entity_id)}@"
