"""Semantic GEDCOM event models."""

from __future__ import annotations

from dataclasses import dataclass

from gedq.model.dates import DateValue


@dataclass(frozen=True)
class AssociationRecord:
    """Projected association data derived from an ASSO node."""

    target_id: str | None
    role: bytes | None
    line_indexes: tuple[int, ...]
    source_ids: tuple[str, ...]


@dataclass(frozen=True)
class EventRecord:
    """Projected event data derived from the preserved GEDCOM tree."""

    tag: str
    line_indexes: tuple[int, ...]
    value: bytes | None
    type_value: bytes | None
    cause: bytes | None
    date_raw: bytes | None
    date: DateValue | None
    place: bytes | None
    address: bytes | None
    source_ids: tuple[str, ...]
    associations: tuple[AssociationRecord, ...]
    notes: tuple[bytes, ...]
    note_line_indexes: tuple[tuple[int, ...], ...]
    note_refs: tuple[str, ...]
