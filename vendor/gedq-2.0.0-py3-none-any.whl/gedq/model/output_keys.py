"""Shared outward-key metadata for read serialization and write alias resolution."""

from __future__ import annotations

from dataclasses import dataclass
from types import MappingProxyType
from typing import Literal


@dataclass(frozen=True)
class WriteAliasTarget:
    """One writable GEDCOM target reached through an outward descriptive key."""

    parent_tag: str | None
    field_tag: str


@dataclass(frozen=True)
class RecordOutwardFieldSpec:
    """One top-level outward record key derived from GEDCOM content."""

    json_key: str
    schema_description: str | None = None
    shadow_raw: bool = False
    suppress_duplicate_raw: bool = False


@dataclass(frozen=True)
class EventOutwardFieldSpec:
    """One outward event key used for aliasing or redirect guidance."""

    json_key: str
    source_tag: str | None = None
    schema_description: str | None = None
    write_child_tag: str | None = None
    redirect_template: str | None = None


@dataclass(frozen=True)
class FieldContractSpec:
    """One canonical outward field contract entry shared across surfaces."""

    owner_kind: str
    canonical_key: str
    tag_path: str
    shape: Literal["scalar", "structured"]
    queryable: bool = False
    writable: bool = False
    emit_null_when_absent: bool = False
    aliases: tuple[str, ...] = ()
    schema_description: str | None = None


EVENT_VALUE_SOURCE_TAG = "__VALUE__"


_RECORD_FIELDS_BY_RAW_TAG = MappingProxyType(
    {
        "ASSO": RecordOutwardFieldSpec(
            json_key="associations",
            schema_description="GEDCOM `ASSO` substructures (enriched).",
            shadow_raw=True,
        ),
        "CHIL": RecordOutwardFieldSpec(
            json_key="chil",
            schema_description="GEDCOM `CHIL` cross-reference list under the canonical child key.",
            shadow_raw=True,
        ),
        "OBJE": RecordOutwardFieldSpec(
            json_key="media_refs",
            schema_description=(
                "GEDCOM `OBJE` cross-reference set surfaced under the canonical media_refs key."
            ),
            shadow_raw=True,
        ),
        "FAMC": RecordOutwardFieldSpec(
            json_key="famc",
            schema_description=(
                "GEDCOM `FAMC` cross-reference surfaced under the canonical famc key."
            ),
            shadow_raw=True,
        ),
        "FAMS": RecordOutwardFieldSpec(
            json_key="fams",
            schema_description=(
                "GEDCOM `FAMS` cross-reference surfaced under the canonical fams key."
            ),
            shadow_raw=True,
        ),
        "FILE": RecordOutwardFieldSpec(
            json_key="media_path",
            schema_description=(
                "Representative GEDCOM `OBJE`/`FILE` path surfaced under a scalar convenience key."
            ),
        ),
        "HUSB": RecordOutwardFieldSpec(
            json_key="husb",
            schema_description=(
                "GEDCOM `HUSB` cross-reference surfaced under the canonical husb key."
            ),
            shadow_raw=True,
        ),
        "NAME": RecordOutwardFieldSpec(
            json_key="name",
            schema_description="Primary GEDCOM `NAME` value surfaced under the canonical name key.",
            shadow_raw=True,
        ),
        "NICK": RecordOutwardFieldSpec(
            json_key="nickname",
            schema_description="Primary GEDCOM `NICK` value.",
            shadow_raw=True,
        ),
        "PUBL": RecordOutwardFieldSpec(
            json_key="publication",
            schema_description="GEDCOM `PUBL` value surfaced under the canonical publication key.",
            shadow_raw=True,
        ),
        "REPO": RecordOutwardFieldSpec(
            json_key="repository_ref",
            schema_description=(
                "GEDCOM `REPO` cross-reference surfaced under the canonical repository key."
            ),
            shadow_raw=True,
        ),
        "SEX": RecordOutwardFieldSpec(
            json_key="sex",
            schema_description="GEDCOM `SEX` value surfaced under the canonical sex key.",
            shadow_raw=True,
        ),
        "SOUR": RecordOutwardFieldSpec(
            json_key="source_ids",
            schema_description=(
                "GEDCOM `SOUR` cross-reference list surfaced under the canonical source_ids key."
            ),
            shadow_raw=True,
        ),
        "TEXT": RecordOutwardFieldSpec(
            json_key="source_text",
            schema_description=(
                "GEDCOM `TEXT` content plus `CONT`/`CONC` continuations surfaced as the "
                "full transcript under a descriptive key."
            ),
            shadow_raw=True,
            suppress_duplicate_raw=True,
        ),
        "TITL": RecordOutwardFieldSpec(
            json_key="title",
            schema_description="GEDCOM `TITL` value surfaced under the canonical title key.",
            shadow_raw=True,
        ),
        "WWW": RecordOutwardFieldSpec(
            json_key="www",
            schema_description="GEDCOM `WWW` value surfaced under the canonical web-address key.",
            shadow_raw=True,
        ),
        "WIFE": RecordOutwardFieldSpec(
            json_key="wife",
            schema_description=(
                "GEDCOM `WIFE` cross-reference surfaced under the canonical wife key."
            ),
            shadow_raw=True,
        ),
    }
)
_RECORD_WRITE_ALIASES_BY_KIND = MappingProxyType(
    {
        "INDI": MappingProxyType(
            {"nickname": WriteAliasTarget(parent_tag="NAME", field_tag="NICK")}
        ),
        "SOUR": MappingProxyType(
            {"source_text": WriteAliasTarget(parent_tag=None, field_tag="TEXT")}
        ),
    }
)
_RECORD_REDIRECT_MESSAGES = MappingProxyType(
    {
        "associations": (
            "associations is a structured read key; use 'ASSO=TARGET_ID' plus "
            "'ASSO.RELA=...' or 'ASSO.SOUR=...' instead"
        ),
        "media_path": (
            "media_path is a read-side convenience key; use 'FILE=...' on an OBJE record or "
            "edit the owning OBJE record's FILE value instead"
        ),
        "note_refs": (
            "note_refs is derived from NOTE text and cannot be written directly; edit 'NOTE=...' "
            "instead"
        ),
        "notes": "notes is a read-only aggregated key; write 'NOTE=...' instead",
        "source_ids": "source_ids is a read-only aggregated key; write 'SOUR=...' instead",
        "value": (
            "value is the inline value of an event/attribute; write the event's own tag instead, "
            "e.g. 'OCCU=...' or 'DEAT=...'"
        ),
    }
)
_EVENT_FIELDS_BY_JSON_KEY = MappingProxyType(
    {
        "associations": EventOutwardFieldSpec(
            json_key="associations",
            source_tag="ASSO",
            schema_description=(
                "GEDCOM `ASSO` substructures attached directly to this event or attribute."
            ),
            redirect_template=(
                "associations is a structured read key for {parent}; use '{parent}.ASSO=TARGET_ID' "
                "plus '{parent}.ASSO.RELA=...' or '{parent}.ASSO.SOUR=...' instead"
            ),
        ),
        "cause": EventOutwardFieldSpec(
            json_key="cause",
            source_tag="CAUS",
            schema_description="GEDCOM `CAUS` text attached directly to this event or attribute.",
            write_child_tag="CAUS",
        ),
        "type": EventOutwardFieldSpec(
            json_key="type",
            source_tag="TYPE",
            schema_description="GEDCOM `TYPE` label attached directly to this event or attribute.",
            write_child_tag="TYPE",
        ),
        "note_refs": EventOutwardFieldSpec(
            json_key="note_refs",
            source_tag="NOTE",
            schema_description=(
                "Resolved GEDCOM `NOTE` cross-reference IDs attached directly to this event or "
                "attribute."
            ),
            redirect_template=(
                "note_refs is derived from {parent}.NOTE text and cannot be written directly; edit "
                "'{parent}.NOTE=...' instead"
            ),
        ),
        "notes": EventOutwardFieldSpec(
            json_key="notes",
            source_tag="NOTE",
            schema_description=(
                "GEDCOM `NOTE` text blocks attached directly to this event or attribute."
            ),
            redirect_template=(
                "notes is a read-only aggregated key for {parent}; write '{parent}.NOTE=...' "
                "instead"
            ),
        ),
        "source_ids": EventOutwardFieldSpec(
            json_key="source_ids",
            source_tag="SOUR",
            schema_description=(
                "GEDCOM `SOUR` cross-reference list attached directly to this event or attribute."
            ),
            redirect_template=(
                "source_ids is a read-only aggregated key for {parent}; write '{parent}.SOUR=...' "
                "instead"
            ),
        ),
        "value": EventOutwardFieldSpec(
            json_key="value",
            source_tag=EVENT_VALUE_SOURCE_TAG,
            schema_description=(
                "Literal line value carried directly by this GEDCOM event or attribute."
            ),
            redirect_template=(
                "value is the outward line-value key for {parent}; write '{parent}=...' "
                "(or '{parent}[i]=...') instead"
            ),
        ),
    }
)
_EVENT_FIELDS_BY_SOURCE_TAG = MappingProxyType(
    {
        "ASSO": (_EVENT_FIELDS_BY_JSON_KEY["associations"],),
        "CAUS": (_EVENT_FIELDS_BY_JSON_KEY["cause"],),
        "NOTE": (_EVENT_FIELDS_BY_JSON_KEY["notes"], _EVENT_FIELDS_BY_JSON_KEY["note_refs"]),
        "SOUR": (_EVENT_FIELDS_BY_JSON_KEY["source_ids"],),
        "TYPE": (_EVENT_FIELDS_BY_JSON_KEY["type"],),
        EVENT_VALUE_SOURCE_TAG: (_EVENT_FIELDS_BY_JSON_KEY["value"],),
    }
)
_FIELD_CONTRACT_SPECS_BY_KIND = MappingProxyType(
    {
        "INDI": (
            FieldContractSpec(
                owner_kind="INDI",
                canonical_key="name",
                tag_path="NAME",
                shape="scalar",
                queryable=True,
                writable=True,
                aliases=("NAME",),
                schema_description="Primary GEDCOM `NAME` value.",
            ),
            FieldContractSpec(
                owner_kind="INDI",
                canonical_key="nickname",
                tag_path="NAME.NICK",
                shape="scalar",
                queryable=True,
                writable=True,
                aliases=("NICK",),
                schema_description="Primary GEDCOM `NICK` value.",
            ),
            FieldContractSpec(
                owner_kind="INDI",
                canonical_key="sex",
                tag_path="SEX",
                shape="scalar",
                queryable=True,
                writable=True,
                emit_null_when_absent=True,
                aliases=("SEX",),
                schema_description="GEDCOM `SEX` value.",
            ),
            FieldContractSpec(
                owner_kind="INDI",
                canonical_key="famc",
                tag_path="FAMC",
                shape="structured",
                writable=True,
                aliases=("FAMC",),
                schema_description="GEDCOM `FAMC` cross-reference list.",
            ),
            FieldContractSpec(
                owner_kind="INDI",
                canonical_key="fams",
                tag_path="FAMS",
                shape="structured",
                writable=True,
                aliases=("FAMS",),
                schema_description="GEDCOM `FAMS` cross-reference list.",
            ),
            FieldContractSpec(
                owner_kind="INDI",
                canonical_key="source_ids",
                tag_path="SOUR",
                shape="structured",
                writable=False,
                aliases=("SOUR",),
                schema_description="GEDCOM `SOUR` cross-reference list.",
            ),
            FieldContractSpec(
                owner_kind="INDI",
                canonical_key="cause",
                tag_path="<event>.CAUS",
                shape="scalar",
                writable=True,
                aliases=("CAUS",),
                schema_description="GEDCOM `CAUS` text attached directly to an event.",
            ),
            FieldContractSpec(
                owner_kind="INDI",
                canonical_key="type",
                tag_path="<event>.TYPE",
                shape="scalar",
                writable=True,
                aliases=("TYPE",),
                schema_description="GEDCOM `TYPE` label attached directly to an event.",
            ),
        ),
        "FAM": (
            FieldContractSpec(
                owner_kind="FAM",
                canonical_key="husb",
                tag_path="HUSB",
                shape="structured",
                writable=True,
                aliases=("HUSB",),
                schema_description="GEDCOM `HUSB` cross-reference.",
            ),
            FieldContractSpec(
                owner_kind="FAM",
                canonical_key="wife",
                tag_path="WIFE",
                shape="structured",
                writable=True,
                aliases=("WIFE",),
                schema_description="GEDCOM `WIFE` cross-reference.",
            ),
            FieldContractSpec(
                owner_kind="FAM",
                canonical_key="chil",
                tag_path="CHIL",
                shape="structured",
                writable=True,
                aliases=("CHIL",),
                schema_description="GEDCOM `CHIL` cross-reference list.",
            ),
            FieldContractSpec(
                owner_kind="FAM",
                canonical_key="source_ids",
                tag_path="SOUR",
                shape="structured",
                writable=False,
                aliases=("SOUR",),
                schema_description="GEDCOM `SOUR` cross-reference list.",
            ),
        ),
        "OBJE": (
            FieldContractSpec(
                owner_kind="OBJE",
                canonical_key="media_path",
                tag_path="FILE",
                shape="scalar",
                queryable=True,
                writable=False,
                aliases=("FILE",),
                schema_description="Representative GEDCOM `FILE` value on an OBJE record.",
            ),
        ),
        "REPO": (
            FieldContractSpec(
                owner_kind="REPO",
                canonical_key="name",
                tag_path="NAME",
                shape="scalar",
                queryable=True,
                writable=True,
                aliases=("NAME",),
                schema_description="Primary GEDCOM `NAME` value.",
            ),
            FieldContractSpec(
                owner_kind="REPO",
                canonical_key="note",
                tag_path="NOTE",
                shape="scalar",
                queryable=True,
                writable=True,
                aliases=("NOTE",),
                schema_description="Primary GEDCOM `NOTE` value.",
            ),
            FieldContractSpec(
                owner_kind="REPO",
                canonical_key="www",
                tag_path="WWW",
                shape="scalar",
                queryable=True,
                writable=True,
                aliases=("WWW",),
                schema_description="GEDCOM `WWW` value.",
            ),
        ),
        "SOUR": (
            FieldContractSpec(
                owner_kind="SOUR",
                canonical_key="source_text",
                tag_path="TEXT",
                shape="scalar",
                queryable=False,
                writable=True,
                emit_null_when_absent=True,
                aliases=("TEXT",),
                schema_description=(
                    "GEDCOM `TEXT` content plus `CONT`/`CONC` continuations surfaced as the "
                    "full transcript under a descriptive key."
                ),
            ),
            FieldContractSpec(
                owner_kind="SOUR",
                canonical_key="title",
                tag_path="TITL",
                shape="scalar",
                queryable=True,
                writable=True,
                emit_null_when_absent=True,
                aliases=("TITL",),
                schema_description="GEDCOM `TITL` value surfaced under the canonical title key.",
            ),
            FieldContractSpec(
                owner_kind="SOUR",
                canonical_key="publication",
                tag_path="PUBL",
                shape="scalar",
                queryable=True,
                writable=True,
                emit_null_when_absent=True,
                aliases=("PUBL",),
                schema_description=(
                    "GEDCOM `PUBL` value surfaced under the canonical publication key."
                ),
            ),
            FieldContractSpec(
                owner_kind="SOUR",
                canonical_key="repository_ref",
                tag_path="REPO",
                shape="scalar",
                queryable=True,
                writable=True,
                emit_null_when_absent=True,
                aliases=("REPO",),
                schema_description=(
                    "GEDCOM `REPO` cross-reference surfaced under the canonical repository key."
                ),
            ),
            FieldContractSpec(
                owner_kind="SOUR",
                canonical_key="media_refs",
                tag_path="OBJE",
                shape="structured",
                aliases=("OBJE",),
                schema_description=(
                    "GEDCOM `OBJE` cross-reference set surfaced under the canonical media_refs key."
                ),
            ),
        ),
    }
)
_FIELD_CONTRACT_SPECS_BY_OWNER_AND_KEY = MappingProxyType(
    {
        (spec.owner_kind, spec.canonical_key): spec
        for specs in _FIELD_CONTRACT_SPECS_BY_KIND.values()
        for spec in specs
    }
)
_FIELD_CONTRACT_SPECS_BY_OWNER_AND_ALIAS = MappingProxyType(
    {
        (spec.owner_kind, alias.lower()): spec
        for specs in _FIELD_CONTRACT_SPECS_BY_KIND.values()
        for spec in specs
        for alias in (spec.canonical_key, *spec.aliases)
    }
)


def record_outward_field_spec(raw_tag: str) -> RecordOutwardFieldSpec | None:
    """Return outward top-level record metadata for one raw GEDCOM tag."""
    return _RECORD_FIELDS_BY_RAW_TAG.get(raw_tag.strip().upper())


def record_outward_json_key(raw_tag: str) -> str | None:
    """Return the outward top-level JSON key for one raw GEDCOM tag."""
    spec = record_outward_field_spec(raw_tag)
    return None if spec is None else spec.json_key


def resolve_record_write_alias(owner_kind: str, key: str) -> WriteAliasTarget | None:
    """Resolve one top-level outward key to a writable GEDCOM target."""
    aliases = _RECORD_WRITE_ALIASES_BY_KIND.get(owner_kind.strip().upper())
    normalized_owner_kind = owner_kind.strip().upper()
    normalized_key = key.strip().lower()
    if aliases is not None:
        direct = aliases.get(normalized_key)
        if direct is not None:
            return direct

    contract_spec = resolve_field_contract_alias(normalized_owner_kind, normalized_key)
    if contract_spec is None or not contract_spec.writable:
        return None

    if "." in contract_spec.tag_path:
        parent_tag, field_tag = contract_spec.tag_path.split(".", 1)
        if parent_tag.startswith("<"):
            return None
        return WriteAliasTarget(parent_tag=parent_tag, field_tag=field_tag)

    return WriteAliasTarget(parent_tag=None, field_tag=contract_spec.tag_path)


def record_redirect_message(key: str) -> str | None:
    """Return targeted write guidance for one non-writable top-level outward key."""
    return _RECORD_REDIRECT_MESSAGES.get(key.strip().lower())


def outward_record_raw_fields(
    payload: dict[str, object],
    raw_fields: dict[str, object],
) -> dict[str, object]:
    """Return raw field data re-keyed onto the canonical outward record contract."""
    outward_fields: dict[str, object] = {}
    for raw_tag, value in raw_fields.items():
        spec = record_outward_field_spec(raw_tag)
        if spec is None:
            outward_fields[raw_tag] = value
            continue
        if spec.json_key not in payload:
            outward_fields[spec.json_key] = value
        if not spec.shadow_raw and spec.json_key == raw_tag:
            outward_fields[raw_tag] = value
    return outward_fields


def resolve_event_child_write_alias(key: str) -> str | None:
    """Resolve one outward event child key to its writable GEDCOM child tag."""
    spec = _EVENT_FIELDS_BY_JSON_KEY.get(key.strip().lower())
    return None if spec is None else spec.write_child_tag


def event_outward_field_specs_for_source_tag(source_tag: str) -> tuple[EventOutwardFieldSpec, ...]:
    """Return outward event-field specs derived from one GEDCOM event subtag surface."""
    return _EVENT_FIELDS_BY_SOURCE_TAG.get(source_tag.strip().upper(), ())


def event_outward_json_key(source_tag: str) -> str | None:
    """Return the outward event key for a one-to-one GEDCOM event subtag surface."""
    specs = event_outward_field_specs_for_source_tag(source_tag)
    if len(specs) != 1:
        return None
    return specs[0].json_key


def event_redirect_message(parent_tag: str, key: str) -> str | None:
    """Return targeted write guidance for one non-writable outward event key."""
    spec = _EVENT_FIELDS_BY_JSON_KEY.get(key.strip().lower())
    if spec is None or spec.redirect_template is None:
        return None
    return spec.redirect_template.format(parent=parent_tag.strip().upper())


def field_contract_specs(owner_kind: str) -> tuple[FieldContractSpec, ...]:
    """Return the shared field-contract entries for one record kind."""
    return _FIELD_CONTRACT_SPECS_BY_KIND.get(owner_kind.strip().upper(), ())


def field_contract_spec(owner_kind: str, canonical_key: str) -> FieldContractSpec | None:
    """Return one field-contract entry by canonical outward key."""
    return _FIELD_CONTRACT_SPECS_BY_OWNER_AND_KEY.get(
        (owner_kind.strip().upper(), canonical_key.strip().lower())
    )


def resolve_field_contract_alias(owner_kind: str, key: str) -> FieldContractSpec | None:
    """Resolve one canonical key or compatibility alias to a field-contract entry."""
    return _FIELD_CONTRACT_SPECS_BY_OWNER_AND_ALIAS.get(
        (owner_kind.strip().upper(), key.strip().lower())
    )
