"""Semantic GEDCOM record models."""

from __future__ import annotations

from dataclasses import dataclass

from gedq.model.events import AssociationRecord, EventRecord


@dataclass(frozen=True)
class RecordField:
    """Projected non-event field derived from a GEDCOM node."""

    tag: str
    value: bytes | None
    line_indexes: tuple[int, ...]
    children: tuple[RecordField, ...] = ()
    references: tuple[str, ...] = ()
    source_ids: tuple[str, ...] = ()
    name_index: int | None = None


@dataclass(frozen=True)
class EntityRecord:
    """Projected GEDCOM entity record with preserved source identity."""

    entity_id: str | None
    kind: str
    root_line_indexes: tuple[int, ...]
    fields: tuple[RecordField, ...]
    events: tuple[EventRecord, ...]
    associations: tuple[AssociationRecord, ...]
    dangling_references: tuple[str, ...] = ()
