"""GEDCOM document model built over the preserved line tape."""

from __future__ import annotations

from dataclasses import dataclass, field

from gedq.errors import ErrorLocation, ParseDataError
from gedq.parser.lexer import tokenize


@dataclass(frozen=True)
class GedLine:
    """One physical GEDCOM line with preserved source bytes."""

    index: int
    raw: bytes
    level: int
    xref: str | None
    tag: str
    value: bytes | None
    eol: bytes


@dataclass
class GedNode:
    """A GEDCOM tree node rooted at one physical line."""

    tag: str
    xref: str | None
    value: bytes | None
    line_indexes: tuple[int, ...]
    children: list[GedNode] = field(default_factory=list)


@dataclass(frozen=True)
class GedDocument:
    """Byte-preserving GEDCOM document with parsed roots and line tape."""

    lines: tuple[GedLine, ...]
    roots: tuple[GedNode, ...]


def parse_document(data: bytes) -> GedDocument:
    """Parse raw GEDCOM bytes into the preserved document model.

    Args:
        data: Raw GEDCOM file bytes.

    Returns:
        The parsed GEDCOM document model.

    Raises:
        ParseDataError: If GEDCOM levels or root structure are malformed.
    """
    lines = tokenize(data)
    roots: list[GedNode] = []
    stack: list[tuple[int, GedNode]] = []

    for line in lines:
        node = GedNode(
            tag=line.tag,
            xref=line.xref,
            value=line.value,
            line_indexes=(line.index,),
        )

        while stack and stack[-1][0] >= line.level:
            stack.pop()

        if line.level == 0:
            roots.append(node)
        else:
            if not stack:
                raise ParseDataError(
                    "missing parent GEDCOM level",
                    location=ErrorLocation(line=line.index + 1, column=1),
                )
            parent_level, parent = stack[-1]
            if line.level != parent_level + 1:
                raise ParseDataError(
                    "invalid GEDCOM level jump",
                    location=ErrorLocation(line=line.index + 1, column=1),
                )
            parent.children.append(node)

        stack.append((line.level, node))

    if not roots:
        raise ParseDataError(
            "missing GEDCOM root records",
            location=ErrorLocation(line=1, column=1),
        )

    return GedDocument(lines=lines, roots=tuple(roots))
