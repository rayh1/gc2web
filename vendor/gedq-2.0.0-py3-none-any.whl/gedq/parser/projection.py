"""Semantic projection from the preserved GEDCOM document model."""

from __future__ import annotations

import re
from collections.abc import Mapping
from dataclasses import dataclass
from types import MappingProxyType

from gedq.model.dates import parse_date_value
from gedq.model.events import AssociationRecord, EventRecord
from gedq.model.records import EntityRecord, RecordField
from gedq.model.tags import supports_event_tag
from gedq.parser.document import GedDocument, GedNode

NOTE_REF_PATTERN = re.compile(r"@(?:I|F|S)[A-Za-z0-9:_-]+@")
NOTE_REF_LABEL_PATTERN = re.compile(r"\bxref_id\s*:\s*@?([IFS][A-Za-z0-9:_-]+)@?", re.I)


@dataclass(frozen=True)
class Projection:
    """Projected semantic records indexed by GEDCOM identifier."""

    records: tuple[EntityRecord, ...]
    by_id: Mapping[str, EntityRecord]

    def get_record(self, entity_id: str) -> EntityRecord | None:
        """Return a projected record by GEDCOM identifier.

        Args:
            entity_id: The GEDCOM identifier to look up.

        Returns:
            The matching projected record, if present.
        """
        return self.by_id.get(entity_id)


def project_document(document: GedDocument) -> Projection:
    """Build semantic GEDCOM records from the preserved document tree.

    Args:
        document: The preserved GEDCOM document.

    Returns:
        The semantic projection keyed by GEDCOM identifier.
    """
    known_ids = {root.xref for root in document.roots if root.xref is not None}
    records: list[EntityRecord] = []

    for root in document.roots:
        fields: list[RecordField] = []
        events: list[EventRecord] = []
        associations: list[AssociationRecord] = []
        referenced_ids: list[str] = []
        indi_name_index = 0

        for child in root.children:
            if supports_event_tag(root.tag, child.tag):
                event = _project_event(child)
                events.append(event)
                referenced_ids.extend(event.source_ids)
                referenced_ids.extend(_association_reference_ids(event.associations))
                referenced_ids.extend(event.note_refs)
                continue

            if child.tag == "ASSO":
                association = _project_association(child)
                associations.append(association)
                referenced_ids.extend(_association_reference_ids((association,)))
                continue

            value = _node_value(child)
            references = _extract_references(value)
            source_ids: tuple[str, ...] = ()
            name_index: int | None = None
            if root.tag == "INDI" and child.tag == "NAME":
                source_ids = tuple(_child_reference_values(child, "SOUR"))
                name_index = indi_name_index
                indi_name_index += 1
            referenced_ids.extend(references)
            referenced_ids.extend(source_ids)
            fields.append(
                RecordField(
                    tag=child.tag,
                    value=value,
                    line_indexes=child.line_indexes,
                    children=_project_field_children(child),
                    references=references,
                    source_ids=source_ids,
                    name_index=name_index,
                )
            )

        dangling_references = tuple(
            sorted({reference for reference in referenced_ids if reference not in known_ids})
        )
        records.append(
            EntityRecord(
                entity_id=root.xref,
                kind=root.tag,
                root_line_indexes=root.line_indexes,
                fields=tuple(fields),
                events=tuple(events),
                associations=tuple(associations),
                dangling_references=dangling_references,
            )
        )

    by_id = {record.entity_id: record for record in records if record.entity_id is not None}
    return Projection(records=tuple(records), by_id=MappingProxyType(by_id))


def _project_event(node: GedNode) -> EventRecord:
    date_raw = _child_value(node, "DATE")
    associations: list[AssociationRecord] = []
    notes: list[bytes] = []
    note_line_indexes: list[tuple[int, ...]] = []
    for child in node.children:
        if child.tag == "ASSO":
            associations.append(_project_association(child))
            continue
        if child.tag != "NOTE":
            continue
        note_value = _node_value(child)
        if note_value is None:
            continue
        notes.append(note_value)
        note_line_indexes.append(_node_block_line_indexes(child))
    note_refs = _extract_note_references(tuple(notes))
    return EventRecord(
        tag=node.tag,
        line_indexes=node.line_indexes,
        value=_node_value(node),
        type_value=_child_value(node, "TYPE"),
        cause=_child_value(node, "CAUS"),
        date_raw=date_raw,
        date=parse_date_value(date_raw),
        place=_child_value(node, "PLAC"),
        address=_child_value(node, "ADDR"),
        source_ids=tuple(_child_reference_values(node, "SOUR")),
        associations=tuple(associations),
        notes=tuple(notes),
        note_line_indexes=tuple(note_line_indexes),
        note_refs=note_refs,
    )


def _project_association(node: GedNode) -> AssociationRecord:
    references = _extract_references(node.value)
    return AssociationRecord(
        target_id=references[0] if references else None,
        role=_child_value(node, "RELA"),
        line_indexes=node.line_indexes,
        source_ids=tuple(_child_reference_values(node, "SOUR")),
    )


def _child_value(node: GedNode, tag: str) -> bytes | None:
    for child in node.children:
        if child.tag == tag:
            return _node_value(child)
    return None


def _child_reference_values(node: GedNode, tag: str) -> list[str]:
    values: list[str] = []
    for child in node.children:
        if child.tag == tag:
            values.extend(_extract_references(child.value))
    return values


def _extract_references(value: bytes | None) -> tuple[str, ...]:
    if value is None:
        return ()
    token = value.decode("utf-8").strip()
    if token.startswith("@") and token.endswith("@") and len(token) >= 2:
        return (token,)
    return ()


def _extract_note_references(values: tuple[bytes, ...]) -> tuple[str, ...]:
    seen: set[str] = set()
    ordered: list[str] = []

    def _add(reference: str) -> None:
        if reference in seen:
            return
        seen.add(reference)
        ordered.append(reference)

    for value in values:
        text = value.decode("utf-8")
        for reference in NOTE_REF_PATTERN.findall(text):
            _add(reference)
        for identifier in NOTE_REF_LABEL_PATTERN.findall(text):
            _add(f"@{identifier}@")
    return tuple(ordered)


def _association_reference_ids(associations: tuple[AssociationRecord, ...]) -> list[str]:
    references: list[str] = []
    for association in associations:
        if association.target_id is not None:
            references.append(association.target_id)
        references.extend(association.source_ids)
    return references


def _node_value(node: GedNode) -> bytes | None:
    value = node.value
    for child in node.children:
        if child.tag == "CONC":
            value = (value or b"") + (child.value or b"")
        elif child.tag == "CONT":
            if value is None:
                value = child.value or b""
            else:
                value = value + b"\n" + (child.value or b"")
    return value


def _node_block_line_indexes(node: GedNode) -> tuple[int, ...]:
    indexes = list(node.line_indexes)
    for child in node.children:
        indexes.extend(_node_block_line_indexes(child))
    return tuple(indexes)


def _project_field_children(node: GedNode) -> tuple[RecordField, ...]:
    children: list[RecordField] = []
    for child in node.children:
        if child.tag in {"CONC", "CONT"}:
            continue
        value = _node_value(child)
        children.append(
            RecordField(
                tag=child.tag,
                value=value,
                line_indexes=child.line_indexes,
                children=_project_field_children(child),
                references=_extract_references(value),
            )
        )
    return tuple(children)
