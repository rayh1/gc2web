"""Byte-preserving GEDCOM serializer."""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

from gedq.parser.document import GedDocument


def serialize_document(document: GedDocument) -> bytes:
    """Serialize a preserved GEDCOM document back to bytes.

    Args:
        document: The preserved GEDCOM document.

    Returns:
        The byte-identical GEDCOM payload for an untouched document.
    """
    return b"".join(line.raw + line.eol for line in document.lines)


def write_atomic(path: Path, document: GedDocument) -> None:
    """Write a GEDCOM document atomically beside the source file.

    Args:
        path: Destination GEDCOM path.
        document: The preserved GEDCOM document to write.
    """
    write_atomic_bytes(path, serialize_document(document))


def write_atomic_bytes(path: Path, payload: bytes) -> None:
    """Write a GEDCOM payload atomically beside the source file."""
    path.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())
        temp_path = Path(handle.name)

    temp_path.replace(path)
