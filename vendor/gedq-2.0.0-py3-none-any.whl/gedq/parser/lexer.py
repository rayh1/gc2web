"""Byte-preserving GEDCOM lexer."""

from __future__ import annotations

from typing import TYPE_CHECKING

from gedq.errors import ErrorLocation, ParseDataError

if TYPE_CHECKING:
    from gedq.parser.document import GedLine

UTF8_BOM = b"\xef\xbb\xbf"


def tokenize(data: bytes) -> tuple[GedLine, ...]:
    """Tokenize GEDCOM bytes into preserved physical lines.

    Args:
        data: Raw GEDCOM file bytes.

    Returns:
        The parsed GEDCOM physical lines in source order.

    Raises:
        ParseDataError: If a line cannot be parsed as GEDCOM line structure.
    """
    lines: list[GedLine] = []
    for index, (raw, eol) in enumerate(_split_physical_lines(data)):
        parse_bytes = raw.removeprefix(UTF8_BOM) if index == 0 else raw
        lines.append(_parse_line(index=index, raw=raw, parse_bytes=parse_bytes, eol=eol))
    return tuple(lines)


def _split_physical_lines(data: bytes) -> list[tuple[bytes, bytes]]:
    lines: list[tuple[bytes, bytes]] = []
    start = 0
    cursor = 0

    while cursor < len(data):
        current = data[cursor : cursor + 1]
        if current == b"\r":
            eol = b"\r\n" if data[cursor + 1 : cursor + 2] == b"\n" else b"\r"
            lines.append((data[start:cursor], eol))
            cursor += len(eol)
            start = cursor
            continue
        if current == b"\n":
            lines.append((data[start:cursor], b"\n"))
            cursor += 1
            start = cursor
            continue
        cursor += 1

    if start < len(data):
        lines.append((data[start:], b""))

    return lines


def _parse_line(index: int, raw: bytes, parse_bytes: bytes, eol: bytes) -> GedLine:
    from gedq.parser.document import GedLine

    if not parse_bytes:
        raise _parse_error(index, "blank GEDCOM lines are not supported")

    level_token, remainder = _consume_token(parse_bytes)
    if level_token is None or remainder is None:
        raise _parse_error(index, "missing GEDCOM level")

    try:
        level = int(level_token.decode("ascii"))
    except ValueError as exc:
        raise _parse_error(index, "invalid GEDCOM level") from exc

    xref: str | None = None
    tag_token: bytes | None = None
    value: bytes | None = None

    first_token, tail = _consume_token(remainder)
    if first_token is None:
        raise _parse_error(index, "missing GEDCOM tag")

    if _is_xref(first_token):
        xref = _decode_ascii(first_token, index, "invalid GEDCOM xref")
        tag_token, tail = _consume_token(tail or b"")
        if tag_token is None:
            raise _parse_error(index, "missing GEDCOM tag after xref")
    else:
        tag_token = first_token

    tag = _decode_ascii(tag_token, index, "invalid GEDCOM tag")
    if tail is not None:
        value = tail

    return GedLine(
        index=index,
        raw=raw,
        level=level,
        xref=xref,
        tag=tag,
        value=value,
        eol=eol,
    )


def _consume_token(data: bytes) -> tuple[bytes | None, bytes | None]:
    stripped = data.lstrip(b" ")
    if not stripped:
        return None, None

    token, separator, remainder = stripped.partition(b" ")
    if not separator:
        return token, None

    return token, remainder


def _is_xref(token: bytes) -> bool:
    return len(token) >= 2 and token.startswith(b"@") and token.endswith(b"@")


def _decode_ascii(token: bytes, index: int, message: str) -> str:
    try:
        return token.decode("ascii")
    except UnicodeDecodeError as exc:
        raise _parse_error(index, message) from exc


def _parse_error(index: int, message: str) -> ParseDataError:
    return ParseDataError(message, location=ErrorLocation(line=index + 1, column=1))
