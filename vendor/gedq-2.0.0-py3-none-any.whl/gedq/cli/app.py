"""Root Typer application for gedq."""

from __future__ import annotations

import sys
from collections.abc import Sequence
from typing import TYPE_CHECKING, Annotated, Any

import typer
from pydantic import ValidationError
from typer.core import TyperGroup

from gedq import __version__
from gedq.cli.commands import (
    _common,
    add,
    analyze,
    ancestors,
    anniversary,
    delete,
    descendants,
    edit,
    family,
    path,
    person,
    query,
    schema,
    search,
    siblings,
    source,
    tree,
    validate,
)
from gedq.errors import UserError

if TYPE_CHECKING:
    from gedq.config import Settings


class GedqGroup(TyperGroup):
    """Root CLI group with gedq-specific usage-error exit codes."""

    def main(
        self,
        args: Sequence[str] | None = None,
        prog_name: str | None = None,
        complete_var: str | None = None,
        standalone_mode: bool = True,
        windows_expand_args: bool = True,
        **extra: Any,
    ) -> Any:
        """Map root-level usage failures to exit code 1."""
        effective_standalone_mode = standalone_mode
        cli_args = tuple(args) if args is not None else tuple(sys.argv[1:])
        try:
            result = super().main(
                args=args,
                prog_name=prog_name,
                complete_var=complete_var,
                standalone_mode=False,
                windows_expand_args=windows_expand_args,
                **extra,
            )
        except Exception as error:
            if _is_click_exception(error, "MissingParameter"):
                _emit_usage_error(
                    error,
                    message=_translate_missing_parameter(error),
                    cli_args=cli_args,
                )
                if effective_standalone_mode:
                    raise SystemExit(1) from error
                return 1
            if _is_click_exception(error, "UsageError"):
                _emit_usage_error(
                    error,
                    message=_translate_usage_error(error),
                    cli_args=cli_args,
                )
                if effective_standalone_mode:
                    raise SystemExit(1) from error
                return 1
            raise
        if effective_standalone_mode:
            raise SystemExit(result)
        return result


def initialize_runtime_logging(settings: Settings | None = None) -> None:
    """Configure structlog before command handlers execute."""
    from gedq.config import LoggingSettings
    from gedq.log import configure_logging, resolve_log_level

    runtime_settings = LoggingSettings() if settings is None else settings
    configure_logging(
        json_output=runtime_settings.log_json,
        level=resolve_log_level(runtime_settings.log_level),
    )


def _translate_missing_parameter(error: object) -> str | None:
    if getattr(getattr(error, "param", None), "name", None) == "expand":
        return "expected: TAG[,TAG...] or 'all'"
    return None


def _translate_usage_error(error: object) -> str | None:
    if getattr(getattr(error, "param", None), "name", None) == "expand":
        return "expected: TAG[,TAG...] or 'all'"
    format_message = getattr(error, "format_message", None)
    if callable(format_message) and format_message() == "Option '--expand' requires an argument.":
        return "expected: TAG[,TAG...] or 'all'"
    return None


def _is_click_exception(error: Exception, *names: str) -> bool:
    mro = error.__class__.__mro__
    return (
        any(base.__name__ in names for base in mro)
        and "click" in error.__class__.__module__.lower()
    )


def _emit_usage_error(error: Exception, *, message: str | None, cli_args: Sequence[str]) -> None:
    if message is None:
        show = getattr(error, "show", None)
        if callable(show):
            show()
            return
        typer.echo(f"Error: {error}", err=True)
        return
    if "--json" in cli_args:
        typer.echo(UserError(message).to_envelope().model_dump_json(exclude_none=True))
        return
    typer.echo(message, err=True)


def _settings_error_message(error: ValidationError) -> str:
    for detail in error.errors():
        location = tuple(detail.get("loc", ()))
        message = str(detail.get("msg", "invalid configuration"))
        if location == ("cache_dir",) and "cannot be empty" in message:
            return "GEDQ_CACHE_DIR cannot be empty"
        if message.startswith("Value error, "):
            return message.removeprefix("Value error, ")
        return message
    return "invalid configuration"


def _show_version(value: bool) -> None:
    if value:
        typer.echo(__version__)
        raise typer.Exit()


app = typer.Typer(
    cls=GedqGroup,
    no_args_is_help=True,
    pretty_exceptions_enable=False,
)


@app.callback()
def main(
    version: Annotated[
        bool,
        typer.Option(
            "--version",
            callback=_show_version,
            is_eager=True,
            help="Show the application version and exit.",
        ),
    ] = False,
    json_output: Annotated[
        bool,
        typer.Option("--json", help="Force JSON output mode for the selected command."),
    ] = False,
    human_output: Annotated[
        bool,
        typer.Option("--human", help="Force human-readable output mode for the selected command."),
    ] = False,
) -> None:
    """Inspect, search, validate, and edit GEDCOM files."""
    cli_args = tuple(sys.argv[1:])
    _common.set_root_output_overrides(
        json_output=json_output,
        human_output=human_output,
    )
    try:
        initialize_runtime_logging()
    except ValidationError as error:
        message = _settings_error_message(error)
        if json_output or "--json" in cli_args:
            typer.echo(UserError(message).to_envelope().model_dump_json(exclude_none=True))
        else:
            typer.echo(message, err=True)
        raise typer.Exit(1) from error
    del version, json_output, human_output


app.command("person")(person.run)
app.command("family")(family.run)
app.command("source")(source.run)
app.command("descendants")(descendants.run)
app.command("ancestors")(ancestors.run)
app.command("siblings")(siblings.run)
app.command("path")(path.run)
app.command("search")(search.run)
app.command(
    "query",
    short_help="Execute raw Cypher; start with 'gedq query --examples'.",
)(query.run)
app.command("schema")(schema.run)
app.command("validate")(validate.run)
app.command("tree")(tree.run)
app.command("analyze")(analyze.run)
app.command("anniversary")(anniversary.run)
app.command(
    "add",
    epilog=_common.mutation_grammar_help_note(command_name="add"),
)(add.run)
app.command(
    "edit",
    epilog=_common.mutation_grammar_help_note(command_name="edit"),
)(edit.run)
app.command("delete")(delete.run)
