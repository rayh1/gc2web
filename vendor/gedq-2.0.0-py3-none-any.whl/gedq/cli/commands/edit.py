"""Implementation for the edit command."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated

import typer

from gedq.cli.commands._common import cache_dir_option, resolve_cache_base, run_command
from gedq.service.write import (
    EditRequest,
    WriteService,
    build_operations,
    render_write_plan_preview,
    render_write_warnings,
)

SetOption = Annotated[
    list[str] | None,
    typer.Option(
        "--set",
        help="Overwrite one field=value pair on the target entity. Repeat as needed.",
    ),
]
ClearOption = Annotated[
    list[str] | None,
    typer.Option("--clear", help="Clear one field from the target entity. Repeat as needed."),
]
AddOption = Annotated[
    list[str] | None,
    typer.Option(
        "--add",
        help="Append one additional field=value pair without replacing existing values.",
    ),
]
RemoveOption = Annotated[
    list[str] | None,
    typer.Option(
        "--remove", help="Remove one field=value pair from a repeatable field. Repeat as needed."
    ),
]


def run(
    entity_id: str,
    ged_path: Path,
    cache_dir: str | None = cache_dir_option(),
    set_fields: SetOption = None,
    clear_fields: ClearOption = None,
    add_fields: AddOption = None,
    remove_fields: RemoveOption = None,
    dry_run: bool = typer.Option(
        False, "--dry-run", help="Preview the guarded write plan without changing the file."
    ),
    json_output: bool = typer.Option(
        False, "--json", help="Use JSON error envelopes when the command fails."
    ),
    human_output: bool = typer.Option(False, "--human", help="Force human-readable error output."),
) -> None:
    """Mutate one top-level GEDCOM entity."""

    def handler() -> None:
        cache_base = resolve_cache_base(cache_dir)
        service = WriteService()
        plan = service.plan_edit(
            EditRequest(
                ged_path=ged_path,
                cache_base=cache_base,
                entity_id=entity_id,
                operations=build_operations(
                    set_fields=set_fields,
                    clear_fields=clear_fields,
                    add_fields=add_fields,
                    remove_fields=remove_fields,
                ),
            )
        )
        if dry_run:
            typer.echo(render_write_plan_preview(plan), nl=False)
            return

        result = service.apply_plan(plan)

        if result.warnings:
            typer.echo(render_write_warnings(result.warnings), err=True, nl=False)

        typer.echo(result.changed_ids[0])

    run_command(handler, json_output=json_output, human_output=human_output)
