"""Implementation for the add command."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated

import typer

from gedq.cli.commands._common import cache_dir_option, resolve_cache_base, run_command
from gedq.service.write import (
    AddRequest,
    WriteService,
    build_operations,
    render_write_plan_preview,
    render_write_warnings,
    supported_add_kinds_text,
)

KindArgument = Annotated[
    str,
    typer.Argument(
        help=f"New top-level GEDCOM entity kind. Supported kinds: {supported_add_kinds_text()}."
    ),
]

SetOption = Annotated[
    list[str] | None,
    typer.Option(
        "--set",
        help="Overwrite one field=value pair on the new entity. Repeat as needed.",
    ),
]
AddOption = Annotated[
    list[str] | None,
    typer.Option(
        "--add",
        help="Append one additional field=value pair without replacing existing values.",
    ),
]


def run(
    kind: KindArgument,
    ged_path: Path,
    cache_dir: str | None = cache_dir_option(),
    entity_id: str | None = typer.Option(
        None, "--id", help="Choose the new entity ID explicitly instead of auto-generating it."
    ),
    set_fields: SetOption = None,
    add_fields: AddOption = None,
    dry_run: bool = typer.Option(
        False, "--dry-run", help="Preview the guarded write plan without changing the file."
    ),
    json_output: bool = typer.Option(
        False, "--json", help="Use JSON error envelopes when the command fails."
    ),
    human_output: bool = typer.Option(False, "--human", help="Force human-readable error output."),
) -> None:
    """Create a new top-level GEDCOM entity.

    Supported kinds: person, family, source, note, repo, object, submitter.
    """

    def handler() -> None:
        cache_base = resolve_cache_base(cache_dir)
        service = WriteService()
        plan = service.plan_add(
            AddRequest(
                ged_path=ged_path,
                cache_base=cache_base,
                kind=kind,
                entity_id=entity_id,
                operations=build_operations(
                    set_fields=set_fields,
                    clear_fields=None,
                    add_fields=add_fields,
                    remove_fields=None,
                ),
            )
        )
        if dry_run:
            typer.echo(render_write_plan_preview(plan), nl=False)
            return

        result = service.apply_plan(plan)

        if result.warnings:
            typer.echo(render_write_warnings(result.warnings), err=True, nl=False)

        typer.echo(result.changed_ids[0])

    run_command(handler, json_output=json_output, human_output=human_output)
