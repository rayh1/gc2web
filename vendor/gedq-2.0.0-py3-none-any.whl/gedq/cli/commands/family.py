"""Placeholder implementation for the family command."""

from __future__ import annotations

from pathlib import Path

import typer

from gedq.cli.commands._common import (
    cache_dir_option,
    emit_payload,
    emit_records,
    human_render_requested,
    open_handle,
    parse_expand_spec,
    resolve_cache_base,
    resolve_output_overrides,
    run_command,
)
from gedq.render.human import render_family_table
from gedq.service.read import lookup_entity, lookup_entity_or_error, lookup_entity_payload_or_error


def run(
    entity_id: str,
    ged_path: Path,
    cache_dir: str | None = cache_dir_option(),
    json_output: bool = typer.Option(False, "--json", help="Emit the record as JSON."),
    human_output: bool = typer.Option(
        False,
        "--human",
        help="Emit the record in a human-readable form.",
    ),
    with_src: bool = typer.Option(
        False,
        "--with-src",
        help="Include file/line provenance in JSON read output.",
    ),
    full: bool = typer.Option(False, "--full", help="Show the full human-readable view."),
    narrative: bool = typer.Option(
        False,
        "--narrative",
        help="Render the human-readable view as prose.",
    ),
    expand: str | None = typer.Option(
        None,
        "--expand",
        help=(
            "Inline selected reference tags or event tags. Use 'all' to expand all supported tags."
        ),
    ),
    table: bool = typer.Option(
        False,
        "--table",
        help="Render family members in a deterministic table in human mode.",
    ),
    verbose_json: bool = typer.Option(
        False,
        "--verbose-json",
        help="Keep null and empty JSON fields that compact mode omits.",
    ),
    collapse_place: bool = typer.Option(
        False,
        "--collapse-place",
        help="Deduplicate repeated identical place strings within one response.",
    ),
) -> None:
    """Look up one family by GEDCOM identifier.

    Accepts FAM IDs only; wrong-kind IDs are rejected.
    """
    effective_human_output = human_render_requested(
        human_output=human_output,
        full=full,
        narrative=narrative,
    )
    effective_json_output, _ = resolve_output_overrides(
        json_output=json_output,
        human_output=effective_human_output,
    )

    def handler() -> None:
        cache_base = resolve_cache_base(cache_dir)
        handle = open_handle(ged_path, cache_base=cache_base)
        if expand is not None:
            expand_spec = parse_expand_spec(expand, traversal=False)
            emit_payload(
                lookup_entity_payload_or_error(
                    handle,
                    entity_id,
                    expand=expand_spec.tags,
                    expand_all=expand_spec.expand_all,
                    expected_kind="FAM",
                    with_src=with_src,
                ),
                json_output=json_output,
                human_output=effective_human_output,
            )
            return

        record = lookup_entity_or_error(
            handle,
            entity_id,
            expected_kind="FAM",
            with_src=with_src,
        )

        if table and not effective_json_output:
            members = []
            for role in ("HUSB", "WIFE", "CHIL"):
                value = record.raw_fields.get(role)
                if isinstance(value, str):
                    person_record = lookup_entity(handle, value, with_src=False)
                    if person_record is not None:
                        members.append((role, person_record))
                if isinstance(value, list):
                    for child_id in value:
                        if not isinstance(child_id, str):
                            continue
                        person_record = lookup_entity(handle, child_id, with_src=False)
                        if person_record is not None:
                            members.append((role, person_record))
            typer.echo(render_family_table(members))
            return

        emit_records(
            [record],
            json_output=json_output,
            human_output=effective_human_output,
            full=full,
            narrative=narrative,
            verbose_json=verbose_json,
            collapse_place=collapse_place,
        )

    run_command(handler, json_output=json_output, human_output=effective_human_output)
