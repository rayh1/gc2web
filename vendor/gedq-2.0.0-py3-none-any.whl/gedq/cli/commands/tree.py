"""Implementation for the tree command."""

from __future__ import annotations

import re
import sys
from pathlib import Path

import typer

from gedq.cli.commands._common import cache_dir_option, resolve_cache_base, run_command
from gedq.service.tree import build_tree_output
from gedq.storage.ladybug_index import GraphIndexService

_LABEL_FIELD_PATTERN = re.compile(r"\{([^{}]+)\}")
_LABEL_PRESETS = {"minimal", "standard", "rich"}
_LABEL_FIELDS = {"name", "birth", "death", "birthplace", "id", "occu", "sex"}
_COLOR_MODES = {"auto", "always", "never"}


def run(
    entity_id: str,
    ged_path: Path,
    cache_dir: str | None = cache_dir_option(),
    direction: str = typer.Option(
        ..., "--direction", help="Tree direction: up for ancestors, down for descendants."
    ),
    depth: int | None = typer.Option(None, "--depth", help="Limit traversal depth."),
    mode: str = typer.Option("clean", "--mode", help="Render clean or annotated output."),
    cap: int = typer.Option(12, "--cap", help="Maximum nodes to render before truncation."),
    color: str = typer.Option(
        "auto", "--color", help="ANSI color mode: auto, always, or never."
    ),
    label: str = typer.Option(
        "standard",
        "--label",
        help="Label preset (minimal, standard, rich) or custom template.",
    ),
    show_ids: bool = typer.Option(False, "--show-ids", help="Append @Id@ to node labels."),
    note_cap: int = typer.Option(
        3,
        "--note-cap",
        min=0,
        help="Maximum source IDs to show in annotated note text; 0 shows count only.",
    ),
) -> None:
    """Render a deterministic ASCII family tree."""

    def handler() -> None:
        resolved_color = _resolve_color_mode(color)
        normalized_label = _normalize_label(label)
        cache_base = resolve_cache_base(cache_dir)
        handle = GraphIndexService(cache_base=cache_base).open_for_query(ged_path)
        output = build_tree_output(
            handle,
            entity_id,
            direction=direction,
            depth=depth,
            mode=mode,
            cap=cap,
            color_mode=resolved_color,
            label=normalized_label,
            show_ids=show_ids,
            note_cap=note_cap,
        )
        typer.echo(output, color=resolved_color != "never")

    run_command(handler, json_output=False, human_output=True)


def _resolve_color_mode(color: str) -> str:
    normalized = color.strip().lower()
    if normalized not in _COLOR_MODES:
        raise typer.BadParameter("--color must be one of: auto, always, never")
    if normalized == "auto":
        return "always" if sys.stdout.isatty() else "never"
    return normalized


def _normalize_label(label: str) -> str:
    normalized = label.strip()
    lowered = normalized.lower()
    if lowered in _LABEL_PRESETS:
        return lowered
    unknown_fields = sorted(set(_LABEL_FIELD_PATTERN.findall(normalized)) - _LABEL_FIELDS)
    if unknown_fields:
        allowed = ", ".join(sorted(_LABEL_FIELDS))
        unknown = ", ".join(unknown_fields)
        raise typer.BadParameter(
            f"unknown --label field(s): {unknown}; allowed fields: {allowed}"
        )
    return normalized
