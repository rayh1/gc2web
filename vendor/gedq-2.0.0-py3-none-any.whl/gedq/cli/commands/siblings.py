"""Placeholder implementation for the siblings command."""

from __future__ import annotations

from pathlib import Path

import typer

from gedq.cli.commands._common import (
    cache_dir_option,
    emit_payload,
    open_handle,
    parse_expand_spec,
    resolve_cache_base,
    resolve_output_mode,
    run_command,
    traversal_payload,
)
from gedq.service.read import lookup_entity_or_error, sibling_elements
from gedq.storage.ladybug_index import QueryHandle


def run(
    entity_id: str,
    ged_path: Path,
    cache_dir: str | None = cache_dir_option(),
    json_output: bool = typer.Option(False, "--json", help="Emit sibling elements as JSON."),
    human_output: bool = typer.Option(
        False, "--human", help="Emit sibling results in a human-readable form."
    ),
    with_src: bool = typer.Option(
        False,
        "--with-src",
        help="Include file/line provenance in JSON read output.",
    ),
    expand: str | None = typer.Option(
        None,
        "--expand",
        help="Use 'all' to inline linked lookup payloads in sibling elements.",
    ),
) -> None:
    """Return siblings for one GEDCOM identifier."""

    def handler() -> None:
        cache_base = resolve_cache_base(cache_dir)
        emit_payload(
            _payload_for_mode(
                open_handle(ged_path, cache_base=cache_base),
                entity_id,
                expand,
                with_src=with_src,
                json_output=json_output,
                human_output=human_output,
            ),
            json_output=json_output,
            human_output=human_output,
        )

    run_command(
        handler,
        json_output=json_output,
        human_output=human_output,
    )


def _parse_and_load(
    handle: QueryHandle, entity_id: str, expand: str | None, with_src: bool
) -> list[dict[str, object]]:
    expand_spec = parse_expand_spec(expand, traversal=True) if expand is not None else None
    return [
        element.model_dump(mode="json", exclude_none=True)
        for element in sibling_elements(
            handle,
            entity_id,
            expand_all=bool(expand_spec and expand_spec.expand_all),
            with_src=with_src,
        )
    ]


def _payload_for_mode(
    handle: QueryHandle,
    entity_id: str,
    expand: str | None,
    *,
    with_src: bool,
    json_output: bool,
    human_output: bool,
) -> object:
    lookup_entity_or_error(handle, entity_id, expected_kind="INDI", with_src=False)
    elements = _parse_and_load(handle, entity_id, expand, with_src)
    mode = resolve_output_mode(json_output=json_output, human_output=human_output)
    return traversal_payload(elements) if mode == "json" else elements
