"""Schema command for output-contract discovery."""

from __future__ import annotations

from collections.abc import Callable
from copy import deepcopy
from typing import Annotated, Any, Literal

import typer
from pydantic import BaseModel, ConfigDict, create_model

from gedq.cli.commands._common import emit_payload, run_command
from gedq.model.dates import ComputedDateField
from gedq.model.output import (
    OutputAssociation,
    OutputEvent,
    OutputFieldSourceMap,
    OutputNoteSourceRef,
    OutputSourceRef,
)
from gedq.model.output_keys import (
    EVENT_VALUE_SOURCE_TAG,
    EventOutwardFieldSpec,
    RecordOutwardFieldSpec,
    event_outward_field_specs_for_source_tag,
    record_outward_field_spec,
)

SchemaMode = Literal["person", "family", "source", "event", "note"]

_RECORD_COMPUTED_FIELDS: tuple[tuple[str, str | None], ...] = (
    ("lifespan_years", "lifespan_full"),
    ("current_age", None),
    ("marriage_age_husb", None),
    ("marriage_age_wife", None),
    ("age_gap_years", None),
    ("marriage_duration_years", None),
    ("years_to_first_child", None),
    ("years_between_first_and_last_child", None),
)
_EVENT_COMPUTED_FIELDS: tuple[tuple[str, str | None], ...] = (("age_at_event", None),)


def _nullable_string_schema(description: str) -> dict[str, Any]:
    return {
        "anyOf": [{"type": "string"}, {"type": "null"}],
        "default": None,
        "description": description,
    }


def _string_list_schema(description: str) -> dict[str, Any]:
    return {
        "type": "array",
        "items": {"type": "string"},
        "default": [],
        "description": description,
    }


def _require_record_outward_field_spec(raw_tag: str) -> RecordOutwardFieldSpec:
    spec = record_outward_field_spec(raw_tag)
    if spec is None:
        raise RuntimeError(f"missing record outward field spec for {raw_tag}")
    return spec


def _require_single_event_outward_field_spec(source_tag: str) -> EventOutwardFieldSpec:
    specs = event_outward_field_specs_for_source_tag(source_tag)
    if len(specs) != 1:
        raise RuntimeError(f"expected exactly one event outward field spec for {source_tag}")
    return specs[0]


def _create_lookup_schema_model(
    model_name: str,
    field_definitions: dict[str, Any],
) -> type[BaseModel]:
    return create_model(
        model_name,
        __base__=_LookupSchemaBase,
        __module__=__name__,
        **field_definitions,
    )


_RECORD_ASSOCIATIONS_SPEC = _require_record_outward_field_spec("ASSO")
_RECORD_CHILDREN_SPEC = _require_record_outward_field_spec("CHIL")
_RECORD_FAMC_SPEC = _require_record_outward_field_spec("FAMC")
_RECORD_FAMS_SPEC = _require_record_outward_field_spec("FAMS")
_RECORD_MEDIA_REFS_SPEC = _require_record_outward_field_spec("OBJE")
_RECORD_MEDIA_PATH_SPEC = _require_record_outward_field_spec("FILE")
_RECORD_HUSB_SPEC = _require_record_outward_field_spec("HUSB")
_RECORD_NAME_SPEC = _require_record_outward_field_spec("NAME")
_RECORD_NICKNAME_SPEC = _require_record_outward_field_spec("NICK")
_RECORD_PUBLICATION_SPEC = _require_record_outward_field_spec("PUBL")
_RECORD_REPOSITORY_REF_SPEC = _require_record_outward_field_spec("REPO")
_RECORD_SEX_SPEC = _require_record_outward_field_spec("SEX")
_RECORD_SOURCE_IDS_SPEC = _require_record_outward_field_spec("SOUR")
_RECORD_SOURCE_TEXT_SPEC = _require_record_outward_field_spec("TEXT")
_RECORD_TITLE_SPEC = _require_record_outward_field_spec("TITL")
_RECORD_WIFE_SPEC = _require_record_outward_field_spec("WIFE")
_EVENT_ASSOCIATIONS_SPEC = _require_single_event_outward_field_spec("ASSO")
_EVENT_CAUSE_SPEC = _require_single_event_outward_field_spec("CAUS")
_EVENT_SOURCE_IDS_SPEC = _require_single_event_outward_field_spec("SOUR")
_EVENT_VALUE_SPEC = _require_single_event_outward_field_spec(EVENT_VALUE_SOURCE_TAG)
_EVENT_NOTE_SPECS = {
    spec.json_key: spec for spec in event_outward_field_specs_for_source_tag("NOTE")
}


_LOOKUP_PROPERTY_DESCRIPTIONS: dict[str, dict[str, str]] = {
    "person": {
        "name": "Primary display name derived from GEDCOM `NAME` structures.",
        "name_variants": (
            "Ordered outward variants derived from repeated GEDCOM `NAME` structures."
        ),
        _RECORD_SEX_SPEC.json_key: _RECORD_SEX_SPEC.schema_description or "",
        _RECORD_FAMC_SPEC.json_key: _RECORD_FAMC_SPEC.schema_description or "",
        _RECORD_FAMS_SPEC.json_key: _RECORD_FAMS_SPEC.schema_description or "",
        _RECORD_SOURCE_IDS_SPEC.json_key: _RECORD_SOURCE_IDS_SPEC.schema_description or "",
        _RECORD_NICKNAME_SPEC.json_key: _RECORD_NICKNAME_SPEC.schema_description or "",
        "date": (
            "Representative date derived from the selected GEDCOM event or attribute substructure."
        ),
        "date_tag": "GEDCOM tag for the event or attribute that supplied `date`.",
        "place": (
            "Representative place derived from the same GEDCOM event or attribute "
            "substructure that supplied `date`."
        ),
        _RECORD_MEDIA_PATH_SPEC.json_key: _RECORD_MEDIA_PATH_SPEC.schema_description or "",
        "relations": (
            "Derived relationship labels resolved from GEDCOM family-link tags such "
            "as `FAMC`, `FAMS`, `HUSB`, `WIFE`, and `CHIL`."
        ),
        "events": "GEDCOM event and attribute substructures (enriched).",
        _RECORD_ASSOCIATIONS_SPEC.json_key: _RECORD_ASSOCIATIONS_SPEC.schema_description or "",
        "is_alive": "Derived liveness flag inferred from GEDCOM life-event evidence.",
    },
    "family": {
        "date": (
            "Representative date derived from the selected GEDCOM family event or "
            "attribute substructure."
        ),
        "date_tag": "GEDCOM tag for the family event or attribute that supplied `date`.",
        "place": (
            "Representative place derived from the same GEDCOM family event or "
            "attribute substructure that supplied `date`."
        ),
        "relations": (
            "Derived relationship labels resolved from GEDCOM family-link tags such "
            "as `HUSB`, `WIFE`, and `CHIL`."
        ),
        "events": "GEDCOM family event and attribute substructures (enriched).",
        _RECORD_HUSB_SPEC.json_key: _RECORD_HUSB_SPEC.schema_description or "",
        _RECORD_WIFE_SPEC.json_key: _RECORD_WIFE_SPEC.schema_description or "",
        _RECORD_CHILDREN_SPEC.json_key: _RECORD_CHILDREN_SPEC.schema_description or "",
        _RECORD_SOURCE_IDS_SPEC.json_key: _RECORD_SOURCE_IDS_SPEC.schema_description or "",
        _RECORD_ASSOCIATIONS_SPEC.json_key: _RECORD_ASSOCIATIONS_SPEC.schema_description or "",
    },
    "source": {
        _RECORD_SOURCE_TEXT_SPEC.json_key: _RECORD_SOURCE_TEXT_SPEC.schema_description or "",
        _RECORD_TITLE_SPEC.json_key: _RECORD_TITLE_SPEC.schema_description or "",
        _RECORD_PUBLICATION_SPEC.json_key: _RECORD_PUBLICATION_SPEC.schema_description or "",
        _RECORD_REPOSITORY_REF_SPEC.json_key: _RECORD_REPOSITORY_REF_SPEC.schema_description or "",
        _RECORD_MEDIA_REFS_SPEC.json_key: _RECORD_MEDIA_REFS_SPEC.schema_description or "",
    },
}


_LOOKUP_PASS_THROUGH_SCHEMAS: dict[str, dict[str, dict[str, Any]]] = {
    "person": {
        _RECORD_SEX_SPEC.json_key: _nullable_string_schema(
            _RECORD_SEX_SPEC.schema_description or ""
        ),
        _RECORD_FAMC_SPEC.json_key: _nullable_string_schema(
            _RECORD_FAMC_SPEC.schema_description or ""
        ),
        _RECORD_FAMS_SPEC.json_key: _nullable_string_schema(
            _RECORD_FAMS_SPEC.schema_description or ""
        ),
        _RECORD_SOURCE_IDS_SPEC.json_key: _string_list_schema(
            _RECORD_SOURCE_IDS_SPEC.schema_description or ""
        ),
    },
    "family": {
        _RECORD_HUSB_SPEC.json_key: _nullable_string_schema(
            _RECORD_HUSB_SPEC.schema_description or ""
        ),
        _RECORD_WIFE_SPEC.json_key: _nullable_string_schema(
            _RECORD_WIFE_SPEC.schema_description or ""
        ),
        _RECORD_CHILDREN_SPEC.json_key: _string_list_schema(
            _RECORD_CHILDREN_SPEC.schema_description or ""
        ),
        _RECORD_SOURCE_IDS_SPEC.json_key: _string_list_schema(
            _RECORD_SOURCE_IDS_SPEC.schema_description or ""
        ),
    },
    "source": {
        _RECORD_TITLE_SPEC.json_key: _nullable_string_schema(
            _RECORD_TITLE_SPEC.schema_description or ""
        ),
        _RECORD_PUBLICATION_SPEC.json_key: _nullable_string_schema(
            _RECORD_PUBLICATION_SPEC.schema_description or ""
        ),
        _RECORD_REPOSITORY_REF_SPEC.json_key: _nullable_string_schema(
            _RECORD_REPOSITORY_REF_SPEC.schema_description or ""
        ),
        _RECORD_MEDIA_REFS_SPEC.json_key: _string_list_schema(
            _RECORD_MEDIA_REFS_SPEC.schema_description or ""
        ),
    },
}


_OUTPUT_EVENT_PROPERTY_DESCRIPTIONS: dict[str, str] = {
    _EVENT_VALUE_SPEC.json_key: _EVENT_VALUE_SPEC.schema_description or "",
    _EVENT_CAUSE_SPEC.json_key: _EVENT_CAUSE_SPEC.schema_description or "",
    _EVENT_SOURCE_IDS_SPEC.json_key: _EVENT_SOURCE_IDS_SPEC.schema_description or "",
    _EVENT_ASSOCIATIONS_SPEC.json_key: _EVENT_ASSOCIATIONS_SPEC.schema_description or "",
    "notes": _EVENT_NOTE_SPECS["notes"].schema_description or "",
    "note_refs": _EVENT_NOTE_SPECS["note_refs"].schema_description or "",
}


class _LookupSchemaBase(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    entity_id: str | None = None
    kind: str
    src: OutputSourceRef | None = None
    note: str | None = None
    field_src: OutputFieldSourceMap | None = None


_PersonLookupSchema = _create_lookup_schema_model(
    "_PersonLookupSchema",
    {
        "name": (str | None, None),
        "name_variants": (tuple[str, ...], ()),
        "date": (str | None, None),
        "date_tag": (str | None, None),
        "place": (str | None, None),
        "relations": (tuple[str, ...], ()),
        "events": (tuple[OutputEvent, ...], ()),
        "is_alive": (bool | None, None),
        "lifespan_years": (ComputedDateField | None, None),
        "current_age": (ComputedDateField | None, None),
        _RECORD_NICKNAME_SPEC.json_key: (str | None, None),
        _RECORD_MEDIA_PATH_SPEC.json_key: (str | None, None),
        _RECORD_ASSOCIATIONS_SPEC.json_key: (tuple[OutputAssociation, ...], ()),
    },
)

_FamilyLookupSchema = _create_lookup_schema_model(
    "_FamilyLookupSchema",
    {
        "date": (str | None, None),
        "date_tag": (str | None, None),
        "place": (str | None, None),
        "relations": (tuple[str, ...], ()),
        "events": (tuple[OutputEvent, ...], ()),
        "marriage_age_husb": (ComputedDateField | None, None),
        "marriage_age_wife": (ComputedDateField | None, None),
        "age_gap_years": (ComputedDateField | None, None),
        "marriage_duration_years": (ComputedDateField | None, None),
        "years_to_first_child": (ComputedDateField | None, None),
        "years_between_first_and_last_child": (ComputedDateField | None, None),
        _RECORD_ASSOCIATIONS_SPEC.json_key: (tuple[OutputAssociation, ...], ()),
    },
)

_SourceLookupSchema = _create_lookup_schema_model(
    "_SourceLookupSchema",
    {
        _RECORD_SOURCE_TEXT_SPEC.json_key: (str | None, None),
        _RECORD_TITLE_SPEC.json_key: (str | None, None),
        _RECORD_PUBLICATION_SPEC.json_key: (str | None, None),
        _RECORD_REPOSITORY_REF_SPEC.json_key: (str | None, None),
        _RECORD_MEDIA_REFS_SPEC.json_key: (tuple[str, ...], ()),
    },
)


_SCHEMA_MODELS: dict[SchemaMode, type[BaseModel]] = {
    "person": _PersonLookupSchema,
    "family": _FamilyLookupSchema,
    "source": _SourceLookupSchema,
    "event": OutputEvent,
    "note": OutputNoteSourceRef,
}


def run(
    mode: Annotated[
        SchemaMode,
        typer.Option(
            "--mode", help="Choose one schema family: person, family, source, event, or note."
        ),
    ] = "person",
) -> None:
    """Emit JSON schema for the selected output mode.

    This command documents output payload contracts only. For raw-query graph
    labels and the scalar `:entities` property list, use `gedq query --examples`.
    """

    def handler() -> None:
        schema = _SCHEMA_MODELS[mode].model_json_schema()
        schema["title"] = f"gedq-{mode}-schema"
        _annotate_schema(mode, schema)
        emit_payload(schema, json_output=True, human_output=False)

    run_command(handler, json_output=True, human_output=False)


def _annotate_schema(mode: SchemaMode, schema: dict[str, Any]) -> None:
    defs = schema.get("$defs", {})
    computed = defs.get("ComputedDateField")
    computed_props = computed.get("properties", {}) if isinstance(computed, dict) else {}
    if isinstance(computed_props, dict) and computed_props:
        _flatten_computed_date_properties(schema, computed_props, _RECORD_COMPUTED_FIELDS)
        _flatten_computed_date_properties(schema, computed_props, _EVENT_COMPUTED_FIELDS)

    source_ref = defs.get("OutputSourceRef")
    if isinstance(source_ref, dict):
        source_props = source_ref.get("properties", {})
        if isinstance(source_props, dict):
            file_prop = source_props.get("file")
            if isinstance(file_prop, dict):
                file_prop["description"] = (
                    "Caller-supplied GED path as provided on the CLI; never a cache path."
                )
            line_end_prop = source_props.get("line_end")
            if isinstance(line_end_prop, dict):
                line_end_prop["description"] = (
                    "Optional final source line for multi-line note provenance; omitted elsewhere."
                )

    field_map = defs.get("OutputFieldSourceMap")
    if isinstance(field_map, dict):
        field_props = field_map.get("properties", {})
        if isinstance(field_props, dict):
            by_tag = field_props.get("by_tag")
            if isinstance(by_tag, dict):
                by_tag["description"] = (
                    "Companion provenance map for flat inline scalar fields "
                    "that remain scalar in JSON."
                )

    output_event = defs.get("OutputEvent")
    if isinstance(output_event, dict) and isinstance(computed_props, dict) and computed_props:
        _flatten_computed_date_properties(output_event, computed_props, _EVENT_COMPUTED_FIELDS)
        defs.pop("ComputedDateField", None)
    if isinstance(output_event, dict):
        _annotate_property_descriptions(
            output_event.get("properties", {}),
            _OUTPUT_EVENT_PROPERTY_DESCRIPTIONS,
        )

    properties = schema.get("properties", {})
    if not isinstance(properties, dict):
        return

    if mode == "event":
        _annotate_property_descriptions(properties, _OUTPUT_EVENT_PROPERTY_DESCRIPTIONS)

    _annotate_property_descriptions(properties, _LOOKUP_PROPERTY_DESCRIPTIONS.get(mode, {}))
    _annotate_lookup_pass_through_properties(properties, _LOOKUP_PASS_THROUGH_SCHEMAS.get(mode, {}))

    for field_name in (
        "lifespan_years",
        "current_age",
        "marriage_age_husb",
        "marriage_age_wife",
        "age_gap_years",
        "marriage_duration_years",
        "years_to_first_child",
        "years_between_first_and_last_child",
        "age_at_event",
    ):
        field_schema = properties.get(field_name)
        if isinstance(field_schema, dict):
            field_schema["description"] = (
                "Primary value in the public computed-date sibling-field vocabulary for "
                f"{field_name}."
            )


def _annotate_property_descriptions(
    properties: Any,
    descriptions: dict[str, str],
) -> None:
    if not isinstance(properties, dict):
        return

    for field_name, description in descriptions.items():
        field_schema = properties.get(field_name)
        if isinstance(field_schema, dict):
            field_schema["description"] = description


def _annotate_lookup_pass_through_properties(
    properties: dict[str, Any],
    pass_through_schemas: dict[str, dict[str, Any]],
) -> None:
    for field_name, field_schema in pass_through_schemas.items():
        existing_schema = properties.get(field_name)
        if isinstance(existing_schema, dict):
            description = field_schema.get("description")
            if isinstance(description, str):
                existing_schema["description"] = description
            continue
        properties[field_name] = deepcopy(field_schema)


def _flatten_computed_date_properties(
    container: dict[str, Any],
    computed_props: dict[str, Any],
    fields: tuple[tuple[str, str | None], ...],
) -> None:
    properties = container.get("properties", {})
    if not isinstance(properties, dict):
        return

    sibling_keys: dict[str, Callable[[str, str | None], str]] = {
        "confidence": lambda field_name, full_key: f"{field_name}_confidence",
        "full": lambda field_name, full_key: full_key or f"{field_name}_full",
        "min": lambda field_name, full_key: f"{field_name}_min",
        "max": lambda field_name, full_key: f"{field_name}_max",
        "period_start": lambda field_name, full_key: f"{field_name}_period_start",
        "period_end": lambda field_name, full_key: f"{field_name}_period_end",
        "source_text": lambda field_name, full_key: f"{field_name}_source_text",
        "dual_year": lambda field_name, full_key: f"{field_name}_dual_year",
        "era": lambda field_name, full_key: f"{field_name}_era",
        "era_year": lambda field_name, full_key: f"{field_name}_era_year",
        "min_era_year": lambda field_name, full_key: f"{field_name}_min_era_year",
        "max_era_year": lambda field_name, full_key: f"{field_name}_max_era_year",
        "calendar": lambda field_name, full_key: f"{field_name}_calendar",
        "calendar_original": lambda field_name, full_key: f"{field_name}_calendar_original",
        "parse_warning": lambda field_name, full_key: f"{field_name}_parse_warning",
    }

    for field_name, full_key in fields:
        field_schema = properties.get(field_name)
        if not isinstance(field_schema, dict):
            continue

        value_schema = deepcopy(computed_props.get("value", {}))
        description = field_schema.get("description")
        if isinstance(description, str):
            value_schema["description"] = description
        properties[field_name] = value_schema

        for attr_name, key_builder in sibling_keys.items():
            sibling_schema = computed_props.get(attr_name)
            if not isinstance(sibling_schema, dict):
                continue
            properties[key_builder(field_name, full_key)] = deepcopy(sibling_schema)
