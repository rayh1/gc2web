"""Implementation for the anniversary command."""

from __future__ import annotations

from pathlib import Path

import typer

from gedq.cli.commands._common import (
    cache_dir_option,
    emit_payload,
    open_handle,
    resolve_cache_base,
    resolve_output_mode,
    run_command,
)
from gedq.service.anniversary import (
    build_anniversary_report,
    format_anniversary_report,
    parse_event_selection,
    resolve_query_date,
)


def run(
    ged_path: Path,
    cache_dir: str | None = cache_dir_option(),
    date: str | None = typer.Option(
        None,
        "--date",
        help="Query date as YYYY-MM-DD or 'DD MON'; mutually exclusive with --today.",
    ),
    today: bool = typer.Option(
        False,
        "--today",
        help="Use the current day and month; default when --date is omitted.",
    ),
    events: str | None = typer.Option(
        None,
        "--events",
        help="Comma-separated subset of birth,marriage,death; defaults to birth.",
    ),
    json_output: bool = typer.Option(False, "--json", help="Emit anniversary output as JSON."),
    human_output: bool = typer.Option(False, "--human", help="Emit human-readable output."),
) -> None:
    """Report deterministic anniversaries for one calendar day."""

    def handler() -> None:
        cache_base = resolve_cache_base(cache_dir)
        handle = open_handle(ged_path, cache_base=cache_base)
        query_date = resolve_query_date(explicit_date=date, use_today=today)
        selected_events = parse_event_selection(events)
        report = build_anniversary_report(
            handle,
            query_date=query_date,
            selected_events=selected_events,
        )
        if resolve_output_mode(json_output=json_output, human_output=human_output) == "json":
            emit_payload(report, json_output=json_output, human_output=human_output)
            return
        typer.echo(format_anniversary_report(report))

    run_command(handler, json_output=json_output, human_output=human_output)
