"""Implementation for the delete command."""

from __future__ import annotations

from pathlib import Path

import typer

from gedq.cli.commands._common import cache_dir_option, resolve_cache_base, run_command
from gedq.service.write import (
    DeleteRequest,
    WriteService,
    render_write_plan_preview,
    render_write_warnings,
)


def run(
    entity_id: str,
    ged_path: Path,
    cache_dir: str | None = cache_dir_option(),
    cascade: bool = typer.Option(
        False,
        "--cascade",
        help="Explicitly remove inbound references that would otherwise block the delete.",
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run", help="Preview the guarded write plan without changing the file."
    ),
    json_output: bool = typer.Option(
        False, "--json", help="Use JSON error envelopes when the command fails."
    ),
    human_output: bool = typer.Option(False, "--human", help="Force human-readable error output."),
) -> None:
    """Delete one top-level GEDCOM entity."""

    def handler() -> None:
        cache_base = resolve_cache_base(cache_dir)
        service = WriteService()
        plan = service.plan_delete(
            DeleteRequest(
                ged_path=ged_path,
                cache_base=cache_base,
                entity_id=entity_id,
                cascade=cascade,
            )
        )
        if dry_run:
            typer.echo(render_write_plan_preview(plan), nl=False)
            return

        result = service.apply_plan(plan)
        if result.warnings:
            typer.echo(render_write_warnings(result.warnings), err=True, nl=False)
        typer.echo(result.changed_ids[0])

    run_command(handler, json_output=json_output, human_output=human_output)
