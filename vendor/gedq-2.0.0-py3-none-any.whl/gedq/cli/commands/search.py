"""Placeholder implementation for the search command."""

from __future__ import annotations

from pathlib import Path

import typer

from gedq.cli.commands._common import (
    cache_dir_option,
    emit_payload,
    emit_records,
    open_handle,
    parse_expand_spec,
    resolve_cache_base,
    run_command,
)
from gedq.service.read import search, search_payloads


def run(
    ged_path: Path,
    cache_dir: str | None = cache_dir_option(),
    surname: str | None = typer.Option(None, "--surname", help="Match surname text."),
    name: str | None = typer.Option(None, "--name", help="Match full-name text."),
    place: str | None = typer.Option(None, "--place", help="Match event place text."),
    year: int | None = typer.Option(None, "--year", help="Match one specific year."),
    year_from: int | None = typer.Option(
        None, "--year-from", help="Match years on or after this value."
    ),
    year_to: int | None = typer.Option(
        None, "--year-to", help="Match years on or before this value."
    ),
    residence: str | None = typer.Option(None, "--residence", help="Match residence text."),
    occupation: str | None = typer.Option(None, "--occupation", help="Match occupation text."),
    sex: str | None = typer.Option(None, "--sex", help="Match sex values such as M or F."),
    text: str | None = typer.Option(None, "--text", help="Match free text across indexed content."),
    kind: str | None = typer.Option(
        None, "--kind", help="Restrict results to one GEDCOM entity kind."
    ),
    cites: str | None = typer.Option(
        None,
        "--cites",
        help="Match distinct citing entities for the given source ID.",
    ),
    json_output: bool = typer.Option(False, "--json", help="Emit matches as JSON or JSON Lines."),
    human_output: bool = typer.Option(
        False, "--human", help="Emit matches in a human-readable form."
    ),
    with_src: bool = typer.Option(
        False,
        "--with-src",
        help="Include file/line provenance in JSON read output.",
    ),
    full: bool = typer.Option(
        False,
        "--full",
        help="Return the full record per match in JSON and the full human-readable view.",
    ),
    narrative: bool = typer.Option(
        False, "--narrative", help="Render human-readable matches as prose."
    ),
    expand: str | None = typer.Option(
        None,
        "--expand",
        help=(
            "Inline selected reference tags or event tags. Use 'all' to expand all supported tags."
        ),
    ),
    verbose_json: bool = typer.Option(
        False,
        "--verbose-json",
        help="Keep null and empty JSON fields that compact mode omits.",
    ),
    collapse_place: bool = typer.Option(
        False,
        "--collapse-place",
        help="Deduplicate repeated identical place strings within one response.",
    ),
) -> None:
    """Search GEDCOM entities using semantic filters."""

    def handler() -> None:
        cache_base = resolve_cache_base(cache_dir)
        handle = open_handle(ged_path, cache_base=cache_base)
        if expand is not None:
            expand_spec = parse_expand_spec(expand, traversal=False)
            emit_payload(
                search_payloads(
                    handle,
                    kind=kind,
                    surname=surname,
                    name=name,
                    place=place,
                    year=year,
                    year_from=year_from,
                    year_to=year_to,
                    occupation=occupation,
                    sex=sex,
                    residence=residence,
                    text=text,
                    cites=cites,
                    expand=expand_spec.tags,
                    expand_all=expand_spec.expand_all,
                    with_src=with_src,
                ),
                json_output=json_output,
                human_output=human_output,
            )
            return

        emit_records(
            search(
                handle,
                kind=kind,
                surname=surname,
                name=name,
                place=place,
                year=year,
                year_from=year_from,
                year_to=year_to,
                occupation=occupation,
                sex=sex,
                residence=residence,
                text=text,
                cites=cites,
                full=full,
                with_src=with_src,
            ),
            json_output=json_output,
            human_output=human_output,
            full=full,
            narrative=narrative,
            verbose_json=verbose_json,
            collapse_place=collapse_place,
        )

    run_command(handler, json_output=json_output, human_output=human_output)
