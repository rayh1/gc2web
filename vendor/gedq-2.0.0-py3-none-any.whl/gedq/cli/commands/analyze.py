"""Implementation for the analyze command."""

from __future__ import annotations

from pathlib import Path

import typer

from gedq.cli.commands._common import (
    cache_dir_option,
    emit_payload,
    open_handle,
    resolve_cache_base,
    resolve_output_mode,
    run_command,
)
from gedq.service.analyze import analyze_file, format_analyze_reports, parse_report_selection


def run(
    ged_path: Path,
    cache_dir: str | None = cache_dir_option(),
    report: str | None = typer.Option(
        None,
        "--report",
        help="Comma-separated subset of census,coverage,structure,duplicates.",
    ),
    json_output: bool = typer.Option(False, "--json", help="Emit analyze output as JSON."),
    human_output: bool = typer.Option(False, "--human", help="Emit human-readable output."),
) -> None:
    """Analyze one GEDCOM file with deterministic aggregate reports."""

    def handler() -> None:
        cache_base = resolve_cache_base(cache_dir)
        handle = open_handle(ged_path, cache_base=cache_base)
        reports = parse_report_selection(report)
        payload = analyze_file(handle, reports)
        if resolve_output_mode(json_output=json_output, human_output=human_output) == "json":
            emit_payload(payload, json_output=json_output, human_output=human_output)
            return
        typer.echo(format_analyze_reports(payload))

    run_command(handler, json_output=json_output, human_output=human_output)
