"""Raw-query command and examples surface for the derived GEDCOM graph."""

from __future__ import annotations

from pathlib import Path

import typer

from gedq.cli.commands._common import (
    cache_dir_option,
    emit_query_rows,
    open_handle,
    resolve_cache_base,
    run_command,
)
from gedq.errors import UserError
from gedq.query.examples import get_query_examples_catalog, render_query_examples_markdown
from gedq.service.read import run_raw_query

_QUERY_ARG = typer.Argument(
    None,
    help=(
        "Cypher over the derived graph. Start with --examples to inspect "
        "supported labels, relationships, and placeholder conventions."
    ),
)
_GED_PATH_ARG = typer.Argument(
    None,
    help="Path to the GEDCOM file whose derived graph will be queried.",
)


def run(
    cypher: str | None = _QUERY_ARG,
    ged_path: Path | None = _GED_PATH_ARG,
    cache_dir: str | None = cache_dir_option(),
    examples: bool = typer.Option(
        False,
        "--examples",
        help="Show the raw-query graph primer and built-in query templates, then exit.",
    ),
    markdown: bool = typer.Option(
        False,
        "--markdown",
        help="Render query examples as Markdown. Only valid with --examples.",
    ),
    json_output: bool = typer.Option(False, "--json", help="Emit rows as JSON Lines."),
    human_output: bool = typer.Option(False, "--human", help="Emit rows in a human-readable form."),
) -> None:
    """Execute a raw Cypher query against the derived graph.

    Start with `gedq query --examples` to inspect the supported query surface.
    The raw-query graph uses two primary node labels, `entities` and `events`,
    with common relationship types such as `parent_of` and `cites`.
    Common `entities` properties include `id` and `kind`, but only the scalar
    `entity_properties` surface from `--examples` is bindable on `:entities`
    nodes. Structured tags such as `BIRT`, `DEAT`, `OBJE`, and `ASSO` stay on
    kind-specific `--json` lookup surfaces or event/citation nodes. Common
    `events` properties include `owner_id`, `tag`, `date_raw`, `year`, and
    `place`.

    Use `gedq schema` for output payload contracts only; it does not describe
    the raw-query graph model. For the authoritative bindable-property list,
    run `gedq query --examples`.
    """

    def handler() -> None:
        if examples:
            if cypher is not None or ged_path is not None:
                raise UserError("--examples does not accept a Cypher query or GED path")
            catalog = get_query_examples_catalog()
            if markdown:
                typer.echo(render_query_examples_markdown(catalog), nl=False)
                return
            typer.echo(catalog.model_dump_json(exclude_none=True))
            return

        if markdown:
            raise UserError("--markdown is only available with --examples")
        if cypher is None or ged_path is None:
            raise UserError("query requires CYPHER and GED_PATH unless --examples is set")
        cache_base = resolve_cache_base(cache_dir)

        emit_query_rows(
            run_raw_query(open_handle(ged_path, cache_base=cache_base), cypher),
            json_output=json_output,
            human_output=human_output,
        )

    run_command(handler, json_output=json_output, human_output=human_output)
