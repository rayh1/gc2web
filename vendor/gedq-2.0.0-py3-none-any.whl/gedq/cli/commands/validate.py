"""Implementation for the validate command."""

from __future__ import annotations

from pathlib import Path

import typer

from gedq.cli.commands._common import (
    cache_dir_option,
    emit_validation_issues,
    resolve_cache_base,
    run_command,
)
from gedq.errors import UserError
from gedq.service.validate import (
    diff_validation_issues_against_baseline,
    filter_validation_issues,
    load_validation_baseline,
    validate_file,
    write_validation_baseline,
)

_ENTITY_OPTION = typer.Option(
    None,
    "--entity",
    help="Restrict output to one normalized entity ID; repeat to union scopes.",
)
_CODE_OPTION = typer.Option(
    None,
    "--code",
    help="Restrict output to one validate issue code; repeat to union scopes.",
)
_BASELINE_OPTION = typer.Option(
    None,
    "--baseline",
    help="Store or compare against a validation baseline snapshot.",
)


def run(
    ged_path: Path,
    cache_dir: str | None = cache_dir_option(),
    json_output: bool = typer.Option(False, "--json", help="Emit validation issues as JSON."),
    human_output: bool = typer.Option(
        False, "--human", help="Emit validation issues in a human-readable form."
    ),
    entity: list[str] | None = _ENTITY_OPTION,
    code: list[str] | None = _CODE_OPTION,
    baseline: Path | None = _BASELINE_OPTION,
    update_baseline: bool = typer.Option(
        False,
        "--update-baseline",
        help="Rewrite the baseline file to the current finding set after validation.",
    ),
) -> None:
    """Validate one GEDCOM file on demand."""

    def handler() -> None:
        resolve_cache_base(cache_dir)
        issues = validate_file(ged_path)
        if update_baseline and baseline is None:
            raise UserError("--update-baseline requires --baseline")
        if baseline is not None:
            if baseline.exists():
                issues = diff_validation_issues_against_baseline(
                    issues,
                    load_validation_baseline(baseline),
                )
                if update_baseline:
                    write_validation_baseline(baseline, validate_file(ged_path))
            else:
                write_validation_baseline(baseline, issues)
                issues = []
        issues = filter_validation_issues(
            issues,
            entity_ids=tuple(entity or ()),
            codes=tuple(code or ()),
        )
        emit_validation_issues(
            issues,
            json_output=json_output,
            human_output=human_output,
        )

    run_command(handler, json_output=json_output, human_output=human_output)
