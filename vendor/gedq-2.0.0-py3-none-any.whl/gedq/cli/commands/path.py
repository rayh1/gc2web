"""Placeholder implementation for the path command."""

from __future__ import annotations

from pathlib import Path

import typer

from gedq.cli.commands._common import (
    cache_dir_option,
    emit_payload,
    open_handle,
    parse_expand_spec,
    resolve_cache_base,
    resolve_output_mode,
    run_command,
    traversal_payload,
)
from gedq.errors import UserError
from gedq.service.read import (
    common_ancestor_path,
    cousin_distance_path,
    lookup_entity_or_error,
    path_elements,
)


def run(
    left_id: str,
    right_id: str,
    ged_path: Path,
    cache_dir: str | None = cache_dir_option(),
    common_ancestor_mode: bool = typer.Option(
        False,
        "--common-ancestor",
        help="Return the common-ancestor payload instead of the shortest path.",
    ),
    cousin_distance_mode: bool = typer.Option(
        False,
        "--cousin-distance",
        help="Return cousin-distance details instead of the shortest path.",
    ),
    json_output: bool = typer.Option(False, "--json", help="Emit path results as JSON."),
    human_output: bool = typer.Option(
        False, "--human", help="Emit path results in a human-readable form."
    ),
    with_src: bool = typer.Option(
        False,
        "--with-src",
        help="Include file/line provenance in JSON read output.",
    ),
    expand: str | None = typer.Option(
        None,
        "--expand",
        help="Use 'all' to inline linked lookup payloads in path elements.",
    ),
) -> None:
    """Return a path, common ancestor, or cousin distance between two IDs."""

    def handler() -> None:
        cache_base = resolve_cache_base(cache_dir)
        handle = open_handle(ged_path, cache_base=cache_base)
        lookup_entity_or_error(handle, left_id, expected_kind="INDI", with_src=False)
        lookup_entity_or_error(handle, right_id, expected_kind="INDI", with_src=False)
        mode = resolve_output_mode(json_output=json_output, human_output=human_output)
        expand_spec = parse_expand_spec(expand, traversal=True) if expand is not None else None
        if expand is not None:
            parse_expand_spec(expand, traversal=True)
        if common_ancestor_mode and cousin_distance_mode:
            raise UserError("choose at most one of --common-ancestor or --cousin-distance")
        if common_ancestor_mode:
            emit_payload(
                common_ancestor_path(
                    handle,
                    left_id,
                    right_id,
                    expand_all=bool(expand_spec and expand_spec.expand_all),
                    with_src=with_src,
                ),
                json_output=json_output,
                human_output=human_output,
            )
            return
        if cousin_distance_mode:
            emit_payload(
                cousin_distance_path(
                    handle,
                    left_id,
                    right_id,
                    expand_all=bool(expand_spec and expand_spec.expand_all),
                    with_src=with_src,
                ),
                json_output=json_output,
                human_output=human_output,
            )
            return

        elements = [
            element.model_dump(mode="json", exclude_none=True)
            for element in path_elements(
                handle,
                left_id,
                right_id,
                expand_all=bool(expand_spec and expand_spec.expand_all),
                with_src=with_src,
            )
        ]
        emit_payload(
            traversal_payload(elements) if mode == "json" else elements,
            json_output=json_output,
            human_output=human_output,
        )

    run_command(handler, json_output=json_output, human_output=human_output)
