"""Placeholder implementation for the ancestors command."""

from __future__ import annotations

from pathlib import Path

import typer

from gedq.cli.commands._common import (
    ExpandSpec,
    cache_dir_option,
    emit_payload,
    open_handle,
    parse_expand_spec,
    resolve_cache_base,
    resolve_output_mode,
    run_command,
    traversal_payload,
)
from gedq.query.relations import LineageTraversal
from gedq.service.read import ancestor_elements, ancestors_with_notices, lookup_entity_or_error
from gedq.storage.ladybug_index import QueryHandle


def run(
    entity_id: str,
    ged_path: Path,
    cache_dir: str | None = cache_dir_option(),
    depth: int | None = typer.Option(None, "--depth", help="Limit traversal depth."),
    json_output: bool = typer.Option(False, "--json", help="Emit traversal elements as JSON."),
    human_output: bool = typer.Option(
        False, "--human", help="Emit traversal results in a human-readable form."
    ),
    with_src: bool = typer.Option(
        False,
        "--with-src",
        help="Include file/line provenance in JSON read output.",
    ),
    expand: str | None = typer.Option(
        None,
        "--expand",
        help="Use 'all' to inline linked lookup payloads in traversal elements.",
    ),
) -> None:
    """Return ancestors for one GEDCOM identifier."""

    def handler() -> None:
        cache_base = resolve_cache_base(cache_dir)
        _emit_lineage(
            open_handle(ged_path, cache_base=cache_base),
            entity_id,
            depth,
            _parse_expand(expand),
            with_src=with_src,
            json_output=json_output,
            human_output=human_output,
        )

    run_command(
        handler,
        json_output=json_output,
        human_output=human_output,
    )


def _parse_and_load(
    handle: QueryHandle,
    entity_id: str,
    depth: int | None,
) -> LineageTraversal:
    return ancestors_with_notices(handle, entity_id, depth)


def _parse_expand(expand: str | None) -> ExpandSpec | None:
    return parse_expand_spec(expand, traversal=True) if expand is not None else None


def _emit_lineage(
    handle: QueryHandle,
    entity_id: str,
    depth: int | None,
    expand_spec: ExpandSpec | None,
    *,
    with_src: bool,
    json_output: bool,
    human_output: bool,
) -> None:
    lookup_entity_or_error(handle, entity_id, expected_kind="INDI", with_src=False)
    traversal = _parse_and_load(handle, entity_id, depth)
    elements = [
        element.model_dump(mode="json", exclude_none=True)
        for element in ancestor_elements(
            handle,
            entity_id,
            depth,
            expand_all=bool(expand_spec and expand_spec.expand_all),
            with_src=with_src,
        )
    ]
    mode = resolve_output_mode(json_output=json_output, human_output=human_output)
    cycle_notice = getattr(traversal, "cycle_notice", None)
    notices: list[str] = [] if cycle_notice is None else [cycle_notice]
    if mode == "json":
        emit_payload(
            traversal_payload(elements, notices=notices),
            json_output=json_output,
            human_output=human_output,
        )
        return
    if not notices:
        emit_payload(elements, json_output=json_output, human_output=human_output)
        return
    lines = list(traversal.entity_ids)
    lines.append(f"notice: {traversal.cycle_notice}")
    typer.echo("\n".join(lines))
