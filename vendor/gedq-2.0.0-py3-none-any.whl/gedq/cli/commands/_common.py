"""Shared CLI helpers for read/query command modules."""

from __future__ import annotations

import errno
import json
import os
import sys
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import cast

import typer
from pydantic import BaseModel, ValidationError

from gedq.config import Settings
from gedq.errors import AppError, ErrorLocation, InternalError, UserError
from gedq.log import get_logger
from gedq.model.output import OutputRecord, ValidationIssueList, ValidationIssuePayload
from gedq.render.human import render_compact, render_full, render_narrative
from gedq.render.jsonl import render_jsonl, render_record, render_rows
from gedq.storage.ladybug_index import GraphIndexService, QueryHandle

_MISSING_EXPAND_MESSAGE = "expected: TAG[,TAG...] or 'all'"
_TRAVERSAL_EXPAND_MESSAGE = (
    "traversal output is typed-element output rather than tag-keyed records, "
    "so selective tag expansion is not available there"
)
_CACHE_DIR_HELP = "Base directory for per-file derived cache artifacts."
_MUTATION_GRAMMAR_HELP_NOTE = (
    "Sub-fields use dotted paths. Bare TAG.sub creates one new TAG structure and nests the "
    "child field onto it. TAG\\[i].sub addresses a pre-existing sibling using pre-edit document "
    "order, so it cannot target a structure created in the same command."
)
_ROOT_JSON_OUTPUT = False
_ROOT_HUMAN_OUTPUT = False


@dataclass(frozen=True)
class ExpandSpec:
    """Normalized command-line expand selection."""

    tags: tuple[str, ...] = ()
    expand_all: bool = False


def traversal_payload(
    elements: Sequence[object],
    *,
    notices: Sequence[str] | None = None,
) -> dict[str, object]:
    """Return the stable traversal JSON envelope used by traversal commands."""
    return {"elements": list(elements), "notices": list(notices or ())}


def parse_expand_spec(value: str | None, *, traversal: bool) -> ExpandSpec:
    """Normalize and validate one `--expand` option value.

    Args:
        value: The raw CLI value supplied after `--expand`.
        traversal: Whether traversal-only semantics apply.

    Returns:
        The normalized expand selection.
    """
    if value is None or not value.strip():
        raise UserError(_MISSING_EXPAND_MESSAGE)

    normalized = value.strip()
    if "." in normalized:
        raise UserError("alleen platte tag-namen, geen padexpressie")
    if ":" in normalized:
        raise UserError("geen depth-control; altijd één niveau diep")

    parts = tuple(part.strip().upper() for part in normalized.split(","))
    if not parts or any(not part for part in parts):
        raise UserError(_MISSING_EXPAND_MESSAGE)

    if "ALL" in parts:
        if len(parts) != 1:
            raise UserError("'all' kan niet gecombineerd worden met specifieke tags")
        return ExpandSpec(expand_all=True)

    if traversal:
        raise UserError(_TRAVERSAL_EXPAND_MESSAGE)

    return ExpandSpec(tags=tuple(dict.fromkeys(parts)))


def cache_dir_option() -> str | None:
    """Return the shared `--cache-dir` option definition."""
    return cast(
        str | None,
        typer.Option(
            None,
            "--cache-dir",
            help=_CACHE_DIR_HELP,
            rich_help_panel="Cache",
        ),
    )


def mutation_grammar_help_note(*, command_name: str) -> str:
    """Return the shared dotted child-path help note for write commands."""
    if command_name == "add":
        return (
            "These dotted child-path rules also apply when building nested structures on a new "
            f"entity. {_MUTATION_GRAMMAR_HELP_NOTE}"
        )
    return _MUTATION_GRAMMAR_HELP_NOTE


def set_root_output_overrides(*, json_output: bool, human_output: bool) -> None:
    """Store root-level output mode overrides for the current CLI invocation."""
    global _ROOT_JSON_OUTPUT, _ROOT_HUMAN_OUTPUT
    _ROOT_JSON_OUTPUT = json_output
    _ROOT_HUMAN_OUTPUT = human_output


def resolve_output_overrides(*, json_output: bool, human_output: bool) -> tuple[bool, bool]:
    """Merge command-local output flags with root-level overrides."""
    return json_output or _ROOT_JSON_OUTPUT, human_output or _ROOT_HUMAN_OUTPUT


def resolve_cache_base(cache_dir: str | None) -> Path | None:
    """Resolve the effective cache base from CLI flag or environment."""
    if cache_dir is not None:
        if not cache_dir.strip():
            raise UserError("--cache-dir cannot be empty")
        return Path(cache_dir)

    try:
        return Settings().cache_dir
    except ValidationError as error:
        if any(tuple(detail.get("loc", ())) == ("cache_dir",) for detail in error.errors()):
            raise UserError("GEDQ_CACHE_DIR cannot be empty") from error
        raise


def open_handle(ged_path: Path, *, cache_base: Path | None = None) -> QueryHandle:
    """Open the derived graph handle for a GEDCOM file.

    Args:
        ged_path: The GEDCOM file path.
        cache_base: Optional base directory for derived cache artifacts.

    Returns:
        The derived graph query handle.
    """
    handle = GraphIndexService(cache_base=cache_base).open_for_query(ged_path)
    if not getattr(sys.stderr, "isatty", lambda: False)():
        return handle
    if handle.cache_status == "built":
        typer.echo(f"building query cache for {ged_path}", err=True)
    elif handle.cache_status == "rebuilt":
        typer.echo(f"rebuilding query cache for {ged_path}", err=True)
    return handle


def emit_records(
    records: Sequence[OutputRecord],
    *,
    json_output: bool,
    human_output: bool,
    full: bool = False,
    narrative: bool = False,
    verbose_json: bool = False,
    collapse_place: bool = False,
) -> None:
    """Emit output records in the selected mode.

    Args:
        records: The records to emit.
        json_output: Whether JSON mode was forced.
        human_output: Whether human mode was forced.
        full: Whether full human rendering was requested.
        narrative: Whether narrative human rendering was requested.
        verbose_json: Whether to keep verbose JSON fields that compact mode omits.
        collapse_place: Whether to suppress repeated event place strings.
    """
    mode = resolve_output_mode(json_output=json_output, human_output=human_output)
    if mode == "json":
        if not records:
            return
        compact = not verbose_json
        typer.echo(
            render_record(records[0], compact=compact, collapse_place=collapse_place)
            if len(records) == 1
            else render_jsonl(records, compact=compact, collapse_place=collapse_place)
        )
        return

    renderer = render_narrative if narrative else render_full if full else render_compact
    if not records:
        typer.echo("not found")
        return
    typer.echo("\n\n".join(renderer(record) for record in records))


def emit_payload(payload: object, *, json_output: bool, human_output: bool) -> None:
    """Emit a non-record payload in the selected mode.

    Args:
        payload: The payload to emit.
        json_output: Whether JSON mode was forced.
        human_output: Whether human mode was forced.
    """
    mode = resolve_output_mode(json_output=json_output, human_output=human_output)
    if mode == "json":
        if (
            isinstance(payload, list)
            and payload
            and all(isinstance(value, BaseModel) for value in payload)
        ):
            rendered = [value.model_dump_json(exclude_none=True) for value in payload]
            typer.echo(rendered[0] if len(rendered) == 1 else "\n".join(rendered))
            return
        if isinstance(payload, BaseModel):
            typer.echo(payload.model_dump_json(exclude_none=True))
            return
        typer.echo(json.dumps(payload, ensure_ascii=False))
        return

    if isinstance(payload, BaseModel):
        payload = payload.model_dump(mode="json", exclude_none=True)

    if payload is None:
        typer.echo("not found")
        return

    if isinstance(payload, list):
        if payload and all(isinstance(value, BaseModel) for value in payload):
            payload = [value.model_dump(mode="json", exclude_none=True) for value in payload]
        typer.echo("\n".join(str(value) for value in payload) if payload else "not found")
        return

    if isinstance(payload, dict):
        typer.echo("\n".join(f"{key}: {value}" for key, value in payload.items()))
        return

    typer.echo(str(payload))


def emit_query_rows(
    rows: Sequence[dict[str, object]], *, json_output: bool, human_output: bool
) -> None:
    """Emit raw-query rows in the selected mode."""
    mode = resolve_output_mode(json_output=json_output, human_output=human_output)
    if mode == "json":
        typer.echo(render_rows(rows))
        return
    emit_payload(list(rows), json_output=json_output, human_output=human_output)


def human_render_requested(
    *, human_output: bool, full: bool = False, narrative: bool = False
) -> bool:
    """Return whether a human renderer was explicitly requested."""
    return human_output or full or narrative


def resolve_output_mode(*, json_output: bool, human_output: bool) -> str:
    """Resolve the output mode for the current command.

    Args:
        json_output: Whether JSON mode was forced.
        human_output: Whether human mode was forced.

    Returns:
        Either `"json"` or `"human"`.
    """
    json_output, human_output = resolve_output_overrides(
        json_output=json_output,
        human_output=human_output,
    )
    if json_output:
        return "json"
    if human_output:
        return "human"
    return "human" if sys.stdout.isatty() else "json"


def run_command(
    handler: Callable[[], None], *, json_output: bool = False, human_output: bool = False
) -> None:
    """Run one CLI command with shared error translation."""
    logger = get_logger().bind(
        output_mode=resolve_output_mode(json_output=json_output, human_output=human_output),
        json_output=json_output,
        human_output=human_output,
    )
    try:
        handler()
    except typer.Exit:
        raise
    except BrokenPipeError:
        _quiet_broken_pipe_exit()
    except typer.BadParameter as error:
        logger.debug(
            "handled cli exception",
            error_type=type(error).__name__,
            error_code=UserError.code,
            detail=str(error),
        )
        _exit_with_error(UserError(str(error)), json_output=json_output, human_output=human_output)
    except AppError as error:
        logger.debug(
            "handled cli exception",
            error_type=type(error).__name__,
            error_code=error.code,
            detail=error.message,
        )
        _exit_with_error(error, json_output=json_output, human_output=human_output)
    except FileNotFoundError:
        logger.debug(
            "handled cli exception",
            error_type="FileNotFoundError",
            error_code=UserError.code,
            detail="source file missing",
        )
        _exit_with_error(
            UserError("source file missing"),
            json_output=json_output,
            human_output=human_output,
        )
    except OSError as error:
        if error.errno == errno.EPIPE:
            _quiet_broken_pipe_exit()
        raise
    except Exception as error:
        logger.exception(
            "handled cli exception",
            error_type=type(error).__name__,
            error_code=InternalError.code,
            detail=str(error),
        )
        _exit_with_error(
            InternalError(f"unexpected internal error: {error}"),
            json_output=json_output,
            human_output=human_output,
        )


def _quiet_broken_pipe_exit() -> None:
    try:
        sys.stdout = open(os.devnull, "w", encoding="utf-8")
    except OSError:
        pass
    raise typer.Exit(code=0)


def emit_validation_issues(
    issues: Sequence[ValidationIssuePayload | dict[str, object]],
    *,
    json_output: bool,
    human_output: bool,
) -> None:
    """Emit validate-command findings in the selected mode."""
    normalized = [
        issue
        if isinstance(issue, ValidationIssuePayload)
        else ValidationIssuePayload.model_validate(issue)
        for issue in issues
    ]
    mode = resolve_output_mode(json_output=json_output, human_output=human_output)
    if mode == "json":
        typer.echo(ValidationIssueList(root=normalized).model_dump_json(exclude_none=True))
        return

    if not normalized:
        typer.echo("ok")
        return

    lines: list[str] = []
    for issue in normalized:
        if issue.location is not None:
            lines.append(f"{_format_location(issue.location)}: {issue.message}")
        else:
            lines.append(issue.message)
    typer.echo("\n".join(lines))


def _exit_with_error(error: AppError, *, json_output: bool, human_output: bool) -> None:
    mode = resolve_output_mode(json_output=json_output, human_output=human_output)
    if mode == "json":
        typer.echo(error.to_envelope().model_dump_json(exclude_none=True))
    else:
        typer.echo(_human_error_message(error), err=True)
    raise typer.Exit(code=error.code)


def _human_error_message(error: AppError) -> str:
    if error.location is None:
        return error.message
    return f"{_format_location(error.location)}: {error.message}"


def _format_location(location: ErrorLocation) -> str:
    parts: list[str] = []
    if location.path is not None:
        parts.append(location.path)
    if location.line is not None:
        line = f"line {location.line}"
        if location.column is not None:
            line = f"{line}:{location.column}"
        parts.append(line)
    elif location.column is not None:
        parts.append(f"column {location.column}")
    return " ".join(parts) if parts else "error"
