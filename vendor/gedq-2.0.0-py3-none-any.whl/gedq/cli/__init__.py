"""CLI package for gedq."""
