"""Runtime configuration for gedq."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Validated runtime configuration for the gedq CLI.

    Attributes:
        cache_dir: Optional cache base override for derived GEDCOM artifacts.
        log_json: Whether diagnostics should render as JSON logs.
        log_level: Minimum logging level for structlog-backed diagnostics.
        validate_unsourced_lenient_record_fallback: Whether record-level citations count for
            unsourced event/name checks.
    """

    model_config = SettingsConfigDict(env_prefix="GEDQ_", extra="forbid", frozen=True)

    cache_dir: Path | None = None
    log_json: bool = False
    log_level: str = "INFO"
    validate_unsourced_lenient_record_fallback: bool = False
    validate_unsourced_event_tags: tuple[str, ...] = ()
    validate_unsourced_event_exclude_tags: tuple[str, ...] = ()
    validate_unsourced_name_placeholder_patterns: tuple[str, ...] = (
        r"^N /N/$",
        r"^N\.N\. /.*$",
    )
    validate_sex_role_check_enabled: bool = True

    @field_validator("cache_dir", mode="before")
    @classmethod
    def validate_cache_dir(cls, value: object) -> object:
        """Reject explicitly empty cache-dir environment values."""
        if isinstance(value, str) and not value.strip():
            raise ValueError("GEDQ_CACHE_DIR cannot be empty")
        return value

    @field_validator(
        "validate_unsourced_event_tags",
        "validate_unsourced_event_exclude_tags",
        "validate_unsourced_name_placeholder_patterns",
        mode="before",
    )
    @classmethod
    def validate_string_tuple(cls, value: Any) -> Any:
        """Normalize comma-separated env values into tuples."""
        if isinstance(value, str):
            return tuple(part.strip() for part in value.split(",") if part.strip())
        return value


class LoggingSettings(BaseSettings):
    """Validated runtime logging configuration for early CLI bootstrap."""

    model_config = SettingsConfigDict(env_prefix="GEDQ_", extra="ignore", frozen=True)

    log_json: bool = False
    log_level: str = "INFO"
