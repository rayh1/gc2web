"""Shared record-level raw-query property metadata."""

from __future__ import annotations

from dataclasses import dataclass
from types import MappingProxyType
from typing import Literal

from gedq.model.entity_ids import normalize_entity_id
from gedq.model.output_keys import field_contract_specs
from gedq.model.records import EntityRecord, RecordField
from gedq.model.tags import EVENT_TAGS_BY_KIND
from gedq.parser.projection import Projection


@dataclass(frozen=True)
class EntityScalarProperty:
    """One scalar record-level property exposed on raw-query entity nodes."""

    query_name: str
    field_tag: str
    documented: bool = True
    storage_type: Literal["STRING", "INT64"] = "STRING"


def _source_scalar_properties_from_contract() -> tuple[EntityScalarProperty, ...]:
    properties: list[EntityScalarProperty] = [
        EntityScalarProperty(query_name="abbr", field_tag="ABBR"),
        EntityScalarProperty(query_name="ABBR", field_tag="ABBR", documented=False),
        EntityScalarProperty(query_name="auth", field_tag="AUTH"),
        EntityScalarProperty(query_name="AUTH", field_tag="AUTH", documented=False),
    ]
    for spec in field_contract_specs("SOUR"):
        if not spec.queryable:
            continue
        field_tag = spec.tag_path.split(".")[-1]
        properties.append(EntityScalarProperty(query_name=spec.canonical_key, field_tag=field_tag))
        for alias in spec.aliases:
            properties.append(
                EntityScalarProperty(query_name=alias, field_tag=field_tag, documented=False)
            )
    return tuple(properties)


def _repo_scalar_properties_from_contract() -> tuple[EntityScalarProperty, ...]:
    properties: list[EntityScalarProperty] = []
    for spec in field_contract_specs("REPO"):
        if not spec.queryable:
            continue
        field_tag = spec.tag_path.split(".")[-1]
        properties.append(EntityScalarProperty(query_name=spec.canonical_key, field_tag=field_tag))
    return tuple(properties)


def _obje_scalar_properties_from_contract() -> tuple[EntityScalarProperty, ...]:
    properties: list[EntityScalarProperty] = []
    for spec in field_contract_specs("OBJE"):
        if not spec.queryable:
            continue
        field_tag = spec.tag_path.split(".")[-1]
        properties.append(EntityScalarProperty(query_name=spec.canonical_key, field_tag=field_tag))
    return tuple(properties)


ENTITY_SCALAR_PROPERTIES_BY_KIND: dict[str, tuple[EntityScalarProperty, ...]] = {
    "INDI": (
        EntityScalarProperty(query_name="name", field_tag="NAME"),
        EntityScalarProperty(query_name="NAME", field_tag="NAME", documented=False),
        EntityScalarProperty(query_name="nickname", field_tag="NICK"),
        EntityScalarProperty(query_name="NICK", field_tag="NICK", documented=False),
        EntityScalarProperty(query_name="sex", field_tag="SEX"),
        EntityScalarProperty(query_name="SEX", field_tag="SEX", documented=False),
    ),
    "FAM": (
        EntityScalarProperty(query_name="husb", field_tag="HUSB"),
        EntityScalarProperty(query_name="HUSB", field_tag="HUSB", documented=False),
        EntityScalarProperty(query_name="wife", field_tag="WIFE"),
        EntityScalarProperty(query_name="WIFE", field_tag="WIFE", documented=False),
    ),
    "OBJE": (*_obje_scalar_properties_from_contract(),),
    "REPO": (*_repo_scalar_properties_from_contract(),),
    "SOUR": (
        *_source_scalar_properties_from_contract(),
    ),
}
_ENTITY_PROPERTY_HINTS = MappingProxyType(
    {
        "source_text": (
            "source_text is a payload-only transcript field; use `gedq source --json <id>` to "
            "read it instead of querying it from :entities nodes."
        ),
        "TEXT": (
            "TEXT is a payload-only transcript field; use `gedq source --json <id>` to read it "
            "instead of querying it from :entities nodes."
        ),
        "OBJE": (
            "OBJE is a structured/pointer field, not a scalar entity property on :entities "
            "nodes; use a kind-specific `--json` lookup or query the related OBJE record "
            "directly."
        ),
        "ASSO": (
            "ASSO is a structured association field, not a scalar entity property on :entities "
            "nodes; use a kind-specific `--json` lookup or citation/association metadata "
            "instead."
        ),
    }
)
_EVENT_PROPERTY_HINT = (
    "{property_name} is an event/attribute tag, not a scalar entity property on :entities nodes; "
    "use a kind-specific `--json` lookup or match "
    "`(:events {{owner_id: ..., tag: '{property_name}'}})` instead."
)
_NON_SCALAR_EVENT_TAGS = frozenset().union(*EVENT_TAGS_BY_KIND.values())


def entity_scalar_properties(kind: str) -> tuple[EntityScalarProperty, ...]:
    """Return the shared scalar raw-query properties for one entity kind."""
    return ENTITY_SCALAR_PROPERTIES_BY_KIND.get(kind, ())


def query_examples_entity_properties() -> tuple[str, ...]:
    """Return the documented raw-query entity-property primer."""
    properties = ["id", "kind", "media_path", "media_form", "media_title"]
    seen = set(properties)
    for kind in ("INDI", "FAM", "SOUR"):
        for property_spec in entity_scalar_properties(kind):
            if not property_spec.documented:
                continue
            if property_spec.query_name in seen:
                continue
            properties.append(property_spec.query_name)
            seen.add(property_spec.query_name)
    return tuple(properties)


def non_scalar_entity_property_hint(property_name: str) -> str | None:
    """Return a user-facing hint when one property is intentionally non-scalar."""
    normalized = property_name.strip()
    if not normalized:
        return None

    if normalized in _ENTITY_PROPERTY_HINTS:
        return _ENTITY_PROPERTY_HINTS[normalized]

    upper_name = normalized.upper()
    if upper_name in _ENTITY_PROPERTY_HINTS:
        return _ENTITY_PROPERTY_HINTS[upper_name]

    if upper_name in _NON_SCALAR_EVENT_TAGS:
        return _EVENT_PROPERTY_HINT.format(property_name=upper_name)

    return None


def build_record_raw_fields(
    record: EntityRecord,
    projection: Projection,
) -> dict[str, object | None]:
    """Build the outward raw-field map shared by lookup and raw query."""
    raw_fields: dict[str, object | None] = {}
    for field in record.fields:
        value: object | None
        if field.references:
            references = [
                (
                    normalize_entity_id(reference)
                    if projection.get_record(reference) is not None
                    else None
                )
                for reference in field.references
            ]
            value = references[0] if len(references) == 1 else references
        elif field.value is not None:
            value = field.value.decode("utf-8")
        else:
            value = None
        _insert_raw_field(raw_fields, field.tag, value)
    return raw_fields


def build_entity_scalar_query_values(
    record: EntityRecord,
    projection: Projection,
) -> dict[str, str | int | None]:
    """Build the shared scalar property values stored on raw-query entity nodes."""
    raw_fields = build_record_raw_fields(record, projection)
    name_values = _values_as_strings(raw_fields.get("NAME"))
    if name_values:
        raw_fields["NAME"] = name_values[0]
    return {
        property_spec.query_name: _coerce_scalar(raw_fields.get(property_spec.field_tag))
        for property_spec in entity_scalar_properties(record.kind)
    }


def build_single_file_object_media_values(record: EntityRecord) -> dict[str, str | None]:
    """Return additive media metadata for single-FILE OBJE records."""
    if record.kind != "OBJE":
        return {"media_form": None, "media_title": None}

    file_fields = [field for field in record.fields if field.tag == "FILE"]
    if len(file_fields) != 1:
        return {"media_form": None, "media_title": None}

    file_field = file_fields[0]
    return {
        "media_form": _decode_child_value(file_field, "FORM"),
        "media_title": _decode_child_value(file_field, "TITL"),
    }


def _coerce_scalar(value: object | None) -> str | int | None:
    if value is None or isinstance(value, (str, int)):
        return value
    return None


def _values_as_strings(value: object | None) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, list):
        return tuple(item for item in value if isinstance(item, str))
    if isinstance(value, str):
        return (value,)
    return ()


def _insert_raw_field(raw_fields: dict[str, object | None], tag: str, value: object | None) -> None:
    if tag not in raw_fields:
        raw_fields[tag] = value
        return

    current = raw_fields[tag]
    if isinstance(current, list):
        current.append(value)
        return

    raw_fields[tag] = [current, value]


def _decode_child_value(field: RecordField, tag: str) -> str | None:
    for child in field.children:
        if child.tag == tag and child.value is not None:
            return child.value.decode("utf-8")
    return None
