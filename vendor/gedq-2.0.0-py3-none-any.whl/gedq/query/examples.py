"""Built-in query example catalog and renderers."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict

from gedq.query.properties import query_examples_entity_properties

ExampleCategory = Literal[
    "traversal",
    "search",
    "cooccurrence",
    "statistics",
    "anomaly",
    "trajectory",
    "date-arithmetic",
]


class QueryExample(BaseModel):
    """One shipped query example."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    slug: str
    category: ExampleCategory
    title: str
    description: str
    cypher: str
    expected_output: str
    parameters: dict[str, str] | None = None


class QuerySurfacePrimer(BaseModel):
    """Top-level guidance for composing raw queries safely."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    labels: tuple[str, ...]
    relationships: tuple[str, ...]
    entity_properties: tuple[str, ...]
    event_properties: tuple[str, ...]
    notes: tuple[str, ...]


class QueryExampleCatalog(BaseModel):
    """Versioned shipped query example catalog."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    version: int
    primer: QuerySurfacePrimer
    examples: tuple[QueryExample, ...]


_CATALOG = QueryExampleCatalog(
    version=2,
    primer=QuerySurfacePrimer(
        labels=("entities", "events"),
        relationships=("parent_of", "cites"),
        entity_properties=query_examples_entity_properties(),
        event_properties=("owner_id", "tag", "date_raw", "year", "place"),
        notes=(
            "Start from these labels, edges, and properties before inventing new graph terms.",
            (
                "Replace quoted literals like 'I2', 'S1', and 'Rotterdam' "
                "with the IDs or values from your task."
            ),
            (
                "Raw `cites` rows retain `subject_kind`, optional `event_tag`, and association "
                "metadata; `search --cites` still returns distinct citing entities instead of one "
                "row per citation edge."
            ),
            (
                "Use `gedq schema` for output payload contracts only; "
                "it does not describe the raw-query graph model."
            ),
            (
                "Only `entity_properties` are bindable scalar `:entities` properties; "
                "structured tags such as `BIRT`, `DEAT`, `ASSO`, `OBJE`, and transcript "
                "text stay on kind-specific `--json` lookup surfaces or event/citation nodes."
            ),
        ),
    ),
    examples=(
        QueryExample(
            slug="parents-of-i2",
            category="traversal",
            title="Direct parents of one person",
            description="Find the immediate parents of a known child record.",
            cypher=(
                "MATCH (p:entities)-[:parent_of]->(c:entities {id: 'I2'}) "
                "RETURN p.id AS parent_id ORDER BY parent_id;"
            ),
            expected_output="One row per parent with `parent_id`.",
            parameters={
                "child_id": "Replace 'I2' with the child entity id you want to inspect.",
            },
        ),
        QueryExample(
            slug="grandchildren-of-i1",
            category="traversal",
            title="Grandchildren of one ancestor",
            description="Walk two parent_of hops to list grandchildren for a known ancestor.",
            cypher=(
                "MATCH (p:entities {id: 'I1'})-[:parent_of]->(:entities)-[:parent_of]->"
                "(gc:entities) RETURN gc.id AS grandchild_id ORDER BY grandchild_id;"
            ),
            expected_output="One row per grandchild with `grandchild_id`.",
            parameters={
                "ancestor_id": (
                    "Replace 'I1' with the ancestor entity id whose grandchildren you want."
                ),
            },
        ),
        QueryExample(
            slug="events-in-rotterdam",
            category="search",
            title="Events in one place",
            description="Find event owners whose indexed events happened in Rotterdam.",
            cypher=(
                "MATCH (event:events) WHERE event.place = 'Rotterdam' "
                "RETURN event.owner_id AS id ORDER BY id;"
            ),
            expected_output="Owner IDs for matching events.",
            parameters={
                "place": "Replace 'Rotterdam' with the place string to match.",
            },
        ),
        QueryExample(
            slug="events-in-1965",
            category="search",
            title="Events in one year",
            description="Find indexed events that match one exact year.",
            cypher=(
                "MATCH (event:events) WHERE event.year = 1965 "
                "RETURN event.owner_id AS id ORDER BY id;"
            ),
            expected_output="Owner IDs for 1965 events.",
            parameters={
                "year": "Replace 1965 with the exact event year you want to match.",
            },
        ),
        QueryExample(
            slug="source-s1-citations",
            category="cooccurrence",
            title="Records citing one source",
            description="List records that co-occur on the same cited source.",
            cypher=(
                "MATCH (e:entities)-[:cites]->(s:entities {id: 'S1'}) "
                "RETURN e.id AS id ORDER BY id;"
            ),
            expected_output="Rows of entity IDs that cite source S1.",
            parameters={
                "source_id": (
                    "Replace 'S1' with the source entity id whose citations you want to inspect."
                ),
            },
        ),
        QueryExample(
            slug="people-count",
            category="statistics",
            title="Count people",
            description="Return the total number of indexed person records.",
            cypher="MATCH (e:entities {kind: 'INDI'}) RETURN COUNT(e) AS people_count;",
            expected_output="One row with `people_count`.",
        ),
        QueryExample(
            slug="family-count",
            category="statistics",
            title="Count families",
            description="Return the total number of indexed family records.",
            cypher="MATCH (e:entities {kind: 'FAM'}) RETURN COUNT(e) AS family_count;",
            expected_output="One row with `family_count`.",
        ),
        QueryExample(
            slug="qualified-dates",
            category="anomaly",
            title="Qualified dates worth review",
            description="Find events with approximate or qualified dates that may need review.",
            cypher=(
                "MATCH (event:events) WHERE event.date_raw = 'BEF 1966' "
                "RETURN event.owner_id AS id, event.date_raw AS date ORDER BY id;"
            ),
            expected_output="Rows with event owner IDs and the qualified date text.",
            parameters={
                "date_text": "Replace 'BEF 1966' with the qualified date text you want to review.",
            },
        ),
        QueryExample(
            slug="residence-trajectory",
            category="trajectory",
            title="Residence trajectory for one person",
            description="Show place changes across one person's dated residence events.",
            cypher=(
                "MATCH (event:events {owner_id: 'I5'}) "
                "RETURN event.tag AS tag, event.place AS place, event.year AS year ORDER BY year;"
            ),
            expected_output="Ordered residence rows with tag, place, and year.",
            parameters={
                "owner_id": "Replace 'I5' with the entity id whose event trajectory you want.",
            },
        ),
        QueryExample(
            slug="adulthood-year",
            category="date-arithmetic",
            title="Approximate adulthood year",
            description="Add eighteen years to one birth year inside the query dialect.",
            cypher=(
                "MATCH (event:events {owner_id: 'I2', tag: 'BIRT'}) "
                "RETURN event.year AS birth_year, event.year + 18 AS adulthood_year;"
            ),
            expected_output="One row with `birth_year` and `adulthood_year`.",
            parameters={
                "owner_id": (
                    "Replace 'I2' with the person entity id whose birth year you want to offset."
                ),
                "offset_years": "Change `+ 18` in the Cypher to a different offset when needed.",
            },
        ),
    ),
)


def get_query_examples_catalog() -> QueryExampleCatalog:
    """Return the built-in versioned query example catalog."""
    return _CATALOG


def render_query_examples_markdown(catalog: QueryExampleCatalog) -> str:
    """Render the query example catalog as markdown from the typed source."""
    lines = ["# gedq query examples", "", f"Version: {catalog.version}", ""]
    lines.extend(
        [
            "## Query surface",
            "",
            "Labels:",
            *[f"- `{label}`" for label in catalog.primer.labels],
            "",
            "Relationships:",
            *[f"- `{relationship}`" for relationship in catalog.primer.relationships],
            "",
            "Common `entities` properties:",
            *[f"- `{field}`" for field in catalog.primer.entity_properties],
            "",
            "Common `events` properties:",
            *[f"- `{field}`" for field in catalog.primer.event_properties],
            "",
            "Notes:",
            *[f"- {note}" for note in catalog.primer.notes],
            "",
        ]
    )
    for example in catalog.examples:
        lines.extend(
            [
                f"## {example.title}",
                "",
                f"Category: {example.category}",
                "",
                example.description,
                "",
                f"Expected output: {example.expected_output}",
                "",
                "```cypher",
                example.cypher,
                "```",
                "",
            ]
        )
        if example.parameters:
            lines.append("Parameters:")
            lines.extend(
                f"- {name}: {description}" for name, description in example.parameters.items()
            )
            lines.append("")
    return "\n".join(lines).rstrip() + "\n"
