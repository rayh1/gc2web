"""Relationship and lineage query helpers."""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Literal

from gedq.model.entity_ids import normalize_entity_id
from gedq.storage.ladybug_index import QueryHandle, query_rows_as_dicts

TraversalRelation = Literal["child", "parent", "sibling", "spouse"]


@dataclass(frozen=True)
class TraversalNode:
    """One person reached during a traversal with its incoming family step."""

    person_id: str
    family_id: str | None = None
    relation: TraversalRelation | None = None


@dataclass(frozen=True)
class TraversalNeighbor:
    """One outward traversal hop to a neighboring person."""

    person_id: str
    family_id: str
    relation: TraversalRelation


@dataclass(frozen=True)
class LineageTraversal:
    """Lineage traversal output with an optional cycle notice."""

    nodes: list[TraversalNode]
    cycle_notice: str | None = None

    @property
    def entity_ids(self) -> list[str]:
        """Return only the visited person identifiers in traversal order."""
        return [node.person_id for node in self.nodes]


@dataclass(frozen=True)
class CousinRelationship:
    """Resolved cousin semantics derived from the selected shared ancestor."""

    ancestor_id: str
    cousin_distance: int
    generations_removed: int


def get_descendants(handle: QueryHandle, entity_id: str, depth: int | None = None) -> list[str]:
    """Return descendants in breadth-first order.

    Args:
        handle: The derived index handle.
        entity_id: The starting entity identifier.
        depth: Optional maximum traversal depth.

    Returns:
        The descendant identifiers, including the starting entity.
    """
    return trace_descendants(handle, entity_id, depth).entity_ids


def get_descendant_nodes(
    handle: QueryHandle, entity_id: str, depth: int | None = None
) -> list[TraversalNode]:
    """Return descendant traversal nodes, including family-edge metadata."""
    return trace_descendants(handle, entity_id, depth).nodes


def trace_descendants(
    handle: QueryHandle, entity_id: str, depth: int | None = None
) -> LineageTraversal:
    """Return descendants together with any detected cycle notice."""
    child_map = _child_neighbor_map(handle)
    return _walk_lineage(child_map, entity_id, relation="descendants", depth=depth)


def get_ancestors(handle: QueryHandle, entity_id: str, depth: int | None = None) -> list[str]:
    """Return ancestors in breadth-first order.

    Args:
        handle: The derived index handle.
        entity_id: The starting entity identifier.
        depth: Optional maximum traversal depth.

    Returns:
        The ancestor identifiers, including the starting entity.
    """
    return trace_ancestors(handle, entity_id, depth).entity_ids


def get_ancestor_nodes(
    handle: QueryHandle, entity_id: str, depth: int | None = None
) -> list[TraversalNode]:
    """Return ancestor traversal nodes, including family-edge metadata."""
    return trace_ancestors(handle, entity_id, depth).nodes


def trace_ancestors(
    handle: QueryHandle, entity_id: str, depth: int | None = None
) -> LineageTraversal:
    """Return ancestors together with any detected cycle notice."""
    start_id = _normalize_id(entity_id)
    parent_map = _parent_neighbor_map(handle)
    return _walk_lineage(parent_map, start_id, relation="ancestors", depth=depth)


def _walk_lineage(
    adjacency: dict[str, list[TraversalNeighbor]],
    entity_id: str,
    *,
    relation: str,
    depth: int | None,
) -> LineageTraversal:
    start_id = _normalize_id(entity_id)
    queue: deque[tuple[TraversalNode, int, tuple[str, ...]]] = deque(
        [(TraversalNode(person_id=start_id), 0, (start_id,))]
    )
    seen: set[str] = set()
    ordered: list[TraversalNode] = []

    while queue:
        current, current_depth, path = queue.popleft()
        if current.person_id in seen:
            return LineageTraversal(
                nodes=ordered,
                cycle_notice=f"cycle detected while traversing {relation}: {' -> '.join(path)}",
            )
        seen.add(current.person_id)
        ordered.append(current)
        if depth is not None and current_depth >= depth:
            continue
        for next_hop in adjacency.get(current.person_id, []):
            queue.append(
                (
                    TraversalNode(
                        person_id=next_hop.person_id,
                        family_id=next_hop.family_id,
                        relation=next_hop.relation,
                    ),
                    current_depth + 1,
                    (*path, next_hop.person_id),
                )
            )

    return LineageTraversal(nodes=ordered)


def get_shortest_path(handle: QueryHandle, start_id: str, end_id: str) -> list[str]:
    """Return the shortest relationship path between two entities.

    Args:
        handle: The derived index handle.
        start_id: The starting entity identifier.
        end_id: The ending entity identifier.

    Returns:
        The shortest path as entity identifiers, or an empty list.
    """
    return [node.person_id for node in get_shortest_path_nodes(handle, start_id, end_id)]


def get_shortest_path_nodes(handle: QueryHandle, start_id: str, end_id: str) -> list[TraversalNode]:
    """Return the shortest relationship path with family-edge metadata."""
    return _path_nodes(_adjacency_map(handle), start_id, end_id)


def get_cousin_path_nodes(handle: QueryHandle, left_id: str, right_id: str) -> list[TraversalNode]:
    """Return the consanguineous witness path for a cousin relationship."""
    relationship = get_cousin_relationship(handle, left_id, right_id)
    if relationship is None:
        return []

    upward = _path_nodes(_parent_neighbor_map(handle), left_id, relationship.ancestor_id)
    downward = _path_nodes(_child_neighbor_map(handle), relationship.ancestor_id, right_id)
    if not upward or not downward:
        return []
    return upward + downward[1:]


def _path_nodes(
    adjacency: dict[str, list[TraversalNeighbor]],
    start_id: str,
    end_id: str,
) -> list[TraversalNode]:
    normalized_start = _normalize_id(start_id)
    normalized_end = _normalize_id(end_id)
    queue: deque[list[TraversalNode]] = deque([[TraversalNode(person_id=normalized_start)]])
    seen: set[str] = set()

    while queue:
        path = queue.popleft()
        current = path[-1].person_id
        if current == normalized_end:
            return path
        if current in seen:
            continue
        seen.add(current)
        for neighbor in adjacency.get(current, []):
            queue.append(
                path
                + [
                    TraversalNode(
                        person_id=neighbor.person_id,
                        family_id=neighbor.family_id,
                        relation=neighbor.relation,
                    )
                ]
            )

    return []


def get_common_ancestor(handle: QueryHandle, left_id: str, right_id: str) -> str | None:
    """Return a lowest shared ancestor between two entities.

    Args:
        handle: The derived index handle.
        left_id: The first entity identifier.
        right_id: The second entity identifier.

    Returns:
        The first shared ancestor discovered by breadth-first search.
    """
    relationship = get_cousin_relationship(handle, left_id, right_id)
    return None if relationship is None else relationship.ancestor_id


def get_cousin_relationship(
    handle: QueryHandle,
    left_id: str,
    right_id: str,
) -> CousinRelationship | None:
    """Return cousin semantics based on the selected common ancestor."""
    left_depths = _ancestor_depths(handle, left_id)
    right_depths = _ancestor_depths(handle, right_id)
    shared = set(left_depths) & set(right_depths)
    if not shared:
        return None

    ancestor = min(
        shared,
        key=lambda candidate: (left_depths[candidate] + right_depths[candidate], candidate),
    )
    left_depth = left_depths[ancestor]
    right_depth = right_depths[ancestor]
    cousin_distance = 0 if left_depth == 0 or right_depth == 0 else min(left_depth, right_depth) - 1
    return CousinRelationship(
        ancestor_id=ancestor,
        cousin_distance=cousin_distance,
        generations_removed=abs(left_depth - right_depth),
    )


def get_cousin_distance(handle: QueryHandle, left_id: str, right_id: str) -> int | None:
    """Return a cousin-distance degree for two entities.

    Args:
        handle: The derived index handle.
        left_id: The first entity identifier.
        right_id: The second entity identifier.

    Returns:
        The cousin degree, or `None` when no shared ancestor exists.
    """
    relationship = get_cousin_relationship(handle, left_id, right_id)
    return None if relationship is None else relationship.cousin_distance


def get_siblings(handle: QueryHandle, entity_id: str) -> list[str]:
    """Return siblings for an entity.

    Args:
        handle: The derived index handle.
        entity_id: The entity identifier.

    Returns:
        The sibling identifiers excluding the starting entity.
    """
    return [node.person_id for node in get_sibling_nodes(handle, entity_id)]


def get_sibling_nodes(handle: QueryHandle, entity_id: str) -> list[TraversalNode]:
    """Return sibling traversal nodes with sibling-family metadata."""
    normalized_id = _normalize_id(entity_id)
    siblings: dict[str, str] = {}
    for family_id, children in _children_by_family(handle).items():
        if normalized_id not in children:
            continue
        for child_id in children:
            if child_id != normalized_id:
                siblings.setdefault(child_id, family_id)
    return [
        TraversalNode(person_id=sibling_id, family_id=family_id, relation="sibling")
        for sibling_id, family_id in sorted(siblings.items())
    ]


def _ancestor_depths(handle: QueryHandle, entity_id: str) -> dict[str, int]:
    parent_map = _parent_neighbor_map(handle)
    queue: deque[tuple[str, int]] = deque([(_normalize_id(entity_id), 0)])
    depths: dict[str, int] = {}

    while queue:
        current, depth = queue.popleft()
        if current in depths:
            continue
        depths[current] = depth
        for parent in parent_map.get(current, []):
            queue.append((parent.person_id, depth + 1))

    return depths


def _parent_neighbor_map(handle: QueryHandle) -> dict[str, list[TraversalNeighbor]]:
    parent_map: dict[str, list[TraversalNeighbor]] = {}
    rows = query_rows_as_dicts(
        handle.connection.execute(
            "MATCH (p:entities)-[rel:parent_of]->(c:entities) "
            "RETURN p.id AS parent_id, c.id AS child_id, rel.family_id AS family_id "
            "ORDER BY child_id, parent_id;"
        )
    )
    for row in rows:
        parent_map.setdefault(str(row["child_id"]), []).append(
            TraversalNeighbor(
                person_id=str(row["parent_id"]),
                family_id=str(row["family_id"]),
                relation="parent",
            )
        )
    return parent_map


def _child_neighbor_map(handle: QueryHandle) -> dict[str, list[TraversalNeighbor]]:
    child_map: dict[str, list[TraversalNeighbor]] = {}
    rows = query_rows_as_dicts(
        handle.connection.execute(
            "MATCH (p:entities)-[rel:parent_of]->(c:entities) "
            "RETURN p.id AS parent_id, c.id AS child_id, rel.family_id AS family_id "
            "ORDER BY parent_id, child_id;"
        )
    )
    for row in rows:
        child_map.setdefault(str(row["parent_id"]), []).append(
            TraversalNeighbor(
                person_id=str(row["child_id"]),
                family_id=str(row["family_id"]),
                relation="child",
            )
        )
    return child_map


def _adjacency_map(handle: QueryHandle) -> dict[str, list[TraversalNeighbor]]:
    adjacency: dict[str, list[TraversalNeighbor]] = {}
    for row in query_rows_as_dicts(
        handle.connection.execute(
            "MATCH (p:entities)-[rel:parent_of]->(c:entities) "
            "RETURN p.id AS left_id, c.id AS right_id, rel.family_id AS family_id "
            "ORDER BY left_id, right_id;"
        )
    ):
        left = str(row["left_id"])
        right = str(row["right_id"])
        family_id = str(row["family_id"])
        adjacency.setdefault(left, []).append(
            TraversalNeighbor(person_id=right, family_id=family_id, relation="child")
        )
        adjacency.setdefault(right, []).append(
            TraversalNeighbor(person_id=left, family_id=family_id, relation="parent")
        )
    for row in query_rows_as_dicts(
        handle.connection.execute(
            "MATCH (a:entities)-[rel:spouse_of]->(b:entities) "
            "RETURN a.id AS left_id, b.id AS right_id, rel.family_id AS family_id "
            "ORDER BY left_id, right_id;"
        )
    ):
        left = str(row["left_id"])
        right = str(row["right_id"])
        family_id = str(row["family_id"])
        adjacency.setdefault(left, []).append(
            TraversalNeighbor(person_id=right, family_id=family_id, relation="spouse")
        )
    return adjacency


def _children_by_family(handle: QueryHandle) -> dict[str, tuple[str, ...]]:
    children_by_family: dict[str, list[str]] = {}
    rows = query_rows_as_dicts(
        handle.connection.execute(
            "MATCH (p:entities)-[rel:parent_of]->(c:entities) "
            "RETURN rel.family_id AS family_id, c.id AS child_id "
            "ORDER BY family_id, child_id;"
        )
    )
    for row in rows:
        family_id = str(row["family_id"])
        child_id = str(row["child_id"])
        children = children_by_family.setdefault(family_id, [])
        if child_id not in children:
            children.append(child_id)
    return {family_id: tuple(children) for family_id, children in children_by_family.items()}


def _normalize_id(entity_id: str) -> str:
    return normalize_entity_id(entity_id)
