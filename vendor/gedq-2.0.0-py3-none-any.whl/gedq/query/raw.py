"""Raw Cypher passthrough helpers."""

from __future__ import annotations

import re

from gedq.errors import AppError, ErrorLocation
from gedq.model.entity_ids import normalize_entity_id
from gedq.query.properties import non_scalar_entity_property_hint
from gedq.storage.ladybug_index import QueryHandle, query_rows_as_dicts

_QUERY_ERROR_PREFIXES = ("Parser exception:", "Binder exception:")
_QUERY_LOCATION_RE = re.compile(r"\(line:\s*(?P<line>\d+),\s*offset:\s*(?P<offset>\d+)\)")
_MISSING_PROPERTY_RE = re.compile(
    r"Binder exception: Cannot find property (?P<property>[A-Za-z_][A-Za-z0-9_]*) for "
    r"(?P<alias>[A-Za-z_][A-Za-z0-9_]*)\."
)
_ENTITY_ID_LITERAL_RE = re.compile(
    r"(?P<prefix>(?:\{|,|\bWHERE\b|\bAND\b|\bOR\b)\s*)"
    r"(?P<field>[A-Za-z_][A-Za-z0-9_\.]*)\s*(?P<operator>:|=)\s*"
    r"(?P<quote>['\"])(?P<value>@?[A-Za-z]+\d+@?)(?P=quote)",
    re.IGNORECASE,
)
_ENTITY_ID_FIELDS = {"id", "owner_id", "association_target_id", "family_id"}


def _translate_query_error(error: RuntimeError) -> AppError | None:
    message = str(error)
    if not message.startswith(_QUERY_ERROR_PREFIXES):
        return None

    match = _QUERY_LOCATION_RE.search(message)
    location = None
    if match is not None:
        location = ErrorLocation(
            line=int(match.group("line")),
            column=int(match.group("offset")) + 1,
        )

    missing_property = _MISSING_PROPERTY_RE.search(message)
    if missing_property is not None:
        property_name = missing_property.group("property")
        hint = non_scalar_entity_property_hint(property_name)
        if hint is not None:
            return AppError(hint, location=location)

    return AppError(message, location=location)


def _normalize_entity_id_literals(cypher: str) -> str:
    """Normalize entity-ID literals in Cypher comparisons without altering numeric shape."""

    def replace(match: re.Match[str]) -> str:
        field_name = match.group("field").split(".")[-1]
        if field_name.casefold() not in _ENTITY_ID_FIELDS:
            return match.group(0)

        normalized = normalize_entity_id(match.group("value"))
        return (
            f"{match.group('prefix')}{match.group('field')}{match.group('operator')} "
            f"{match.group('quote')}{normalized}{match.group('quote')}"
        )

    return _ENTITY_ID_LITERAL_RE.sub(replace, cypher)


def execute_raw_query(handle: QueryHandle, cypher: str) -> list[dict[str, object]]:
    """Execute a raw Cypher query against the derived Ladybug index.

    Args:
        handle: The derived index handle.
        cypher: The raw Cypher query string.

    Returns:
        The materialized query rows as dictionaries.
    """
    normalized_cypher = _normalize_entity_id_literals(cypher)
    try:
        return query_rows_as_dicts(handle.connection.execute(normalized_cypher))
    except RuntimeError as error:
        translated = _translate_query_error(error)
        if translated is None:
            raise
        raise translated from error
