"""Search helpers over the derived Ladybug index."""

from __future__ import annotations

from collections.abc import Sequence
from pathlib import Path

from gedq.model.dates import DateValue, matches_year, parse_date_value
from gedq.model.entity_ids import normalize_entity_id
from gedq.query.properties import build_record_raw_fields
from gedq.service.validate import load_strict_document
from gedq.storage.ladybug_index import QueryHandle, query_rows_as_dicts


def search_entities(
    handle: QueryHandle,
    *,
    kind: str | None = None,
    surname: str | None = None,
    name: str | None = None,
    place: str | None = None,
    year: int | None = None,
    year_from: int | None = None,
    year_to: int | None = None,
    occupation: str | None = None,
    sex: str | None = None,
    residence: str | None = None,
    text: str | None = None,
    cites: str | None = None,
) -> list[str]:
    """Search projected entities using simple semantic filters.

    Args:
        handle: The derived index handle.
        kind: Optional GEDCOM entity kind filter.
        surname: Optional surname substring filter.
        name: Optional given-name or nickname substring filter.
        place: Optional event place substring filter.
        year: Optional event year filter.
        year_from: Optional inclusive start year filter.
        year_to: Optional inclusive end year filter.
        occupation: Optional occupation substring filter.
        sex: Optional sex filter.
        residence: Optional address substring filter.
        text: Optional note or source-text substring filter.
        cites: Optional source identifier filter.

    Returns:
        Matching entity identifiers.
    """
    source_text_by_id = _source_text_by_entity_id(handle.source_path) if text is not None else {}
    entity_rows = query_rows_as_dicts(
        handle.connection.execute(
            "MATCH (e:entities) RETURN e.id AS id, e.kind AS kind, e.name AS name, "
            "e.name_search AS name_search, e.nickname AS nickname, e.note AS note, "
            "e.sex AS sex, e.occupation AS occupation;"
        )
    )
    event_rows = query_rows_as_dicts(
        handle.connection.execute(
            "MATCH (e:entities)-[:has_event]->(event:events) "
            "RETURN e.id AS owner_id, event.tag AS tag, "
            "event.date_raw AS date_raw, event.year AS year, event.place AS place, "
            "event.address AS address, event.note_text AS note_text;"
        )
    )
    cite_rows = query_rows_as_dicts(
        handle.connection.execute(
            "MATCH (e:entities)-[:cites]->(s:entities) RETURN e.id AS entity_id, s.id AS source_id;"
        )
    )

    events_by_owner: dict[str, list[dict[str, object]]] = {}
    for row in event_rows:
        events_by_owner.setdefault(str(row["owner_id"]), []).append(row)

    cites_by_owner: dict[str, set[str]] = {}
    for row in cite_rows:
        cites_by_owner.setdefault(str(row["entity_id"]), set()).add(str(row["source_id"]))

    matches: list[str] = []
    for row in entity_rows:
        entity_id = str(row["id"])
        owner_events = events_by_owner.get(entity_id, [])
        name_haystack = str(row.get("name_search", row.get("name", ""))).lower()
        if kind is not None and str(row.get("kind", "")) != kind:
            continue
        if surname is not None and surname.lower() not in name_haystack:
            continue
        if name is not None:
            haystack = (
                f"{row.get('name_search', row.get('name', ''))} {row.get('nickname', '')}".lower()
            )
            if name.lower() not in haystack:
                continue
        if sex is not None and str(row.get("sex", "")).lower() != sex.lower():
            continue
        if (
            occupation is not None
            and occupation.lower() not in str(row.get("occupation", "")).lower()
        ):
            continue
        if text is not None and not _text_matches_entity(
            row,
            owner_events,
            text,
            source_text=source_text_by_id.get(entity_id),
        ):
            continue
        if cites is not None and _normalize_id(cites) not in cites_by_owner.get(entity_id, set()):
            continue

        if place is not None and not any(
            place.lower() in str(event.get("place", "")).lower() for event in owner_events
        ):
            continue
        if residence is not None and not any(
            residence.lower() in str(event.get("address", "")).lower() for event in owner_events
        ):
            continue
        if year is not None and not any(_event_matches_year(event, year) for event in owner_events):
            continue
        if (year_from is not None or year_to is not None) and not any(
            _event_matches_year_range(event, year_from=year_from, year_to=year_to)
            for event in owner_events
        ):
            continue

        matches.append(entity_id)

    return matches


def _normalize_id(entity_id: str) -> str:
    return normalize_entity_id(entity_id)


def _text_matches_entity(
    row: dict[str, object],
    events: Sequence[dict[str, object]],
    text: str,
    *,
    source_text: str | None = None,
) -> bool:
    needle = text.lower()
    entity_haystack = f"{row.get('note', '')} {source_text or row.get('source_text', '')}".lower()
    if needle in entity_haystack:
        return True
    return any(needle in str(event.get("note_text", "")).lower() for event in events)


def _source_text_by_entity_id(ged_path: Path) -> dict[str, str]:
    _, projection = load_strict_document(ged_path)
    source_text_by_id: dict[str, str] = {}
    for record in projection.records:
        if record.entity_id is None:
            continue
        value = build_record_raw_fields(record, projection).get("TEXT")
        if isinstance(value, str):
            source_text_by_id[_normalize_id(record.entity_id)] = value
    return source_text_by_id


def _event_matches_year(event: dict[str, object], year: int) -> bool:
    parsed = _parse_event_date(event)
    return parsed is not None and matches_year(parsed, year)


def _event_matches_year_range(
    event: dict[str, object], *, year_from: int | None, year_to: int | None
) -> bool:
    parsed = _parse_event_date(event)
    if parsed is None:
        return False

    if year_from is not None and year_to is not None:
        lower, upper = sorted((year_from, year_to))
        return any(matches_year(parsed, candidate) for candidate in range(lower, upper + 1))

    if year_from is not None:
        upper = max(year_from, _date_upper_bound(parsed))
        return any(matches_year(parsed, candidate) for candidate in range(year_from, upper + 1))

    if year_to is not None:
        lower = min(year_to, _date_lower_bound(parsed))
        return any(matches_year(parsed, candidate) for candidate in range(lower, year_to + 1))

    return True


def _parse_event_date(event: dict[str, object]) -> DateValue | None:
    raw = event.get("date_raw")
    if raw is None:
        return None
    return parse_date_value(str(raw).encode("utf-8"))


def _date_lower_bound(parsed: DateValue) -> int:
    if parsed.qualifier == "AFT" and parsed.year is not None:
        return parsed.year + 1
    return parsed.year or 0


def _date_upper_bound(parsed: DateValue) -> int:
    if parsed.qualifier in {"BET", "FROM"} and parsed.end_year is not None:
        return parsed.end_year
    if parsed.qualifier == "BEF" and parsed.year is not None:
        return parsed.year - 1
    return parsed.year or 0
