"""Query helpers for gedq."""
