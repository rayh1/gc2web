"""Console entrypoint for gedq."""

from __future__ import annotations

import errno
import os
import sys


def main() -> None:
    """Run the gedq command-line application."""
    from gedq import Settings
    from gedq.cli.app import app, initialize_runtime_logging

    settings = Settings()
    initialize_runtime_logging(settings)
    try:
        app(prog_name="gedq")
    except BrokenPipeError:
        _quiet_broken_pipe_exit()
        return
    except OSError as error:
        if error.errno == errno.EPIPE:
            _quiet_broken_pipe_exit()
            return
        raise


def _quiet_broken_pipe_exit() -> None:
    try:
        sys.stdout = open(os.devnull, "w", encoding="utf-8")
    except OSError:
        pass
