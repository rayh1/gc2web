"""CLI-facing output models for gedq renderers."""

from __future__ import annotations

from typing import Any, Literal, Self, cast

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, RootModel, model_serializer

from gedq.errors import ErrorLocation
from gedq.model.dates import ComputedDateField, flatten_computed_field
from gedq.model.output_keys import outward_record_raw_fields, record_outward_field_spec

_COMPUTED_RECORD_FIELDS: tuple[tuple[str, str | None], ...] = (
    ("lifespan_years", "lifespan_full"),
    ("current_age", None),
    ("marriage_age_husb", None),
    ("marriage_age_wife", None),
    ("age_gap_years", None),
    ("marriage_duration_years", None),
    ("years_to_first_child", None),
    ("years_between_first_and_last_child", None),
)


class OutputSourceRef(BaseModel):
    """Source provenance for one emitted payload element."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    file: str
    line: int
    line_end: int | None = None


class OutputNoteSourceRef(BaseModel):
    """Source provenance wrapper aligned to one emitted note block."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    src: OutputSourceRef


class OutputFieldSourceMap(BaseModel):
    """Tag-keyed provenance map for flat non-event fields."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    by_tag: dict[str, OutputSourceRef | list[OutputSourceRef]] = Field(default_factory=dict)


class OutputAssociation(BaseModel):
    """Typed association payload for rich lookup and rendering surfaces."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    target_id: str | None = None
    role: str | None = None
    source_ids: tuple[str, ...] = ()
    src: OutputSourceRef | None = None

    def without_provenance(self) -> Self:
        """Return this association without file/line provenance."""
        return self.model_copy(update={"src": None})


class OutputEvent(BaseModel):
    """Typed event payload for rich lookup and rendering surfaces."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    tag: str
    src: OutputSourceRef | None = None
    value: str | None = None
    type: str | None = None
    cause: str | None = None
    date: str | None = None
    place: str | None = None
    address: str | None = None
    source_ids: tuple[str, ...] = ()
    associations: tuple[OutputAssociation, ...] = ()
    notes: tuple[str, ...] = ()
    note_src: tuple[OutputNoteSourceRef, ...] = ()
    note_refs: tuple[str, ...] = ()
    age_at_event: ComputedDateField | None = None

    def without_provenance(self) -> Self:
        """Return this event without file/line provenance."""
        return self.model_copy(
            update={
                "src": None,
                "associations": tuple(
                    association.without_provenance() for association in self.associations
                ),
                "note_src": (),
            }
        )


class OutputNameOccurrence(BaseModel):
    """Typed outward payload for one GEDCOM NAME occurrence."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    name_index: int
    value: str
    source_ids: tuple[str, ...] = ()
    notes: tuple[str, ...] = ()
    note_refs: tuple[str, ...] = ()
    src: OutputSourceRef | None = None

    def without_provenance(self) -> Self:
        """Return this name occurrence without file/line provenance."""
        return self.model_copy(update={"src": None})

    @model_serializer(mode="wrap")
    def _serialize(self, handler: Any) -> dict[str, Any]:
        payload = cast(dict[str, Any], handler(self))
        payload.setdefault("source_ids", list(self.source_ids))
        payload.setdefault("notes", list(self.notes))
        payload.setdefault("note_refs", list(self.note_refs))
        return payload


class OutputCitationFact(BaseModel):
    """Typed source-centric citation row for source expansion payloads."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    entity_id: str
    entity_kind: str
    subject_kind: Literal["record", "event", "association", "name"]
    tag: str | None = None
    value: str | None = None
    type: str | None = None
    cause: str | None = None
    date: str | None = None
    place: str | None = None
    address: str | None = None
    association_target_id: str | None = None
    association_role: str | None = None
    name_index: int | None = None

    @model_serializer(mode="wrap")
    def _serialize(self, handler: Any) -> dict[str, Any]:
        payload = cast(dict[str, Any], handler(self))
        payload["value"] = self.value
        if self.subject_kind == "name":
            payload.setdefault("name_index", self.name_index)
        else:
            payload.pop("name_index", None)
        return payload


class OutputCitationEventNotes(BaseModel):
    """Typed sibling note payload for note-bearing cited events."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    owner_id: str
    owner_kind: str
    event_tag: str
    event_source_ids: tuple[str, ...] = ()
    notes: tuple[str, ...] = ()
    note_refs: tuple[str, ...] = ()


class GapRow(BaseModel):
    """Typed outward row for one deterministic gaps candidate."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    check: str
    entity_id: str
    entity_kind: str
    label: str
    reason: str
    birth_year: int | None = None

    @model_serializer(mode="wrap")
    def _serialize(self, handler: Any) -> dict[str, Any]:
        payload = cast(dict[str, Any], handler(self))
        payload["birth_year"] = self.birth_year
        return payload


class GapsReport(BaseModel):
    """Typed outward payload for the gaps command."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    reference_year: int
    niches: tuple[GapRow, ...] = ()

    @model_serializer(mode="wrap")
    def _serialize(self, handler: Any) -> dict[str, Any]:
        payload = cast(dict[str, Any], handler(self))
        payload.setdefault("niches", list(self.niches))
        return payload


class AnniversaryLifespan(BaseModel):
    """Compact year-range payload for anniversary rows."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    birth: int | None = None
    death: int | None = None


class AnniversaryAnchor(BaseModel):
    """Relationship anchor payload for one anniversary row."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    role: str
    of: tuple[str, ...] = ()
    names: tuple[str, ...] | None = None


class AnniversaryEventRow(BaseModel):
    """Typed outward anniversary row for JSON output."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    event: Literal["BIRT", "MARR", "DEAT"]
    entity_id: str
    name: str | None = None
    names: tuple[str, ...] | None = None
    spouse_ids: tuple[str, ...] | None = None
    date: str
    day: int
    month: int
    year: int | None = None
    ordinal: int | None = None
    ordinal_kind: Literal["birthday", "anniversary", "years_ago"] | None = None
    lifespan: AnniversaryLifespan | None = None
    anchor: AnniversaryAnchor | None = None

    @model_serializer(mode="wrap")
    def _serialize(self, handler: Any) -> dict[str, Any]:
        payload = cast(dict[str, Any], handler(self))
        payload.setdefault("ordinal", self.ordinal)
        payload.setdefault("lifespan", None if self.lifespan is None else payload.get("lifespan"))
        payload.setdefault("anchor", None if self.anchor is None else payload.get("anchor"))
        return payload


class AnniversaryReport(BaseModel):
    """Typed outward payload for the anniversary command."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    query_date: str
    events: tuple[AnniversaryEventRow, ...] = ()


class NumberedReportPersonRow(BaseModel):
    """Typed outward row for one numbered-report person or placeholder slot."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    number: str
    entity_id: str | None = None
    name: str | None = None
    birth_year: int | None = None
    death_year: int | None = None
    generation: int
    also_numbered: tuple[str, ...] = ()
    child_marker: str | None = None
    carries_forward: bool | None = None

    @model_serializer(mode="wrap")
    def _serialize(self, handler: Any) -> dict[str, Any]:
        payload = cast(dict[str, Any], handler(self))
        payload["entity_id"] = self.entity_id
        payload["name"] = self.name
        payload["birth_year"] = self.birth_year
        payload["death_year"] = self.death_year
        payload["child_marker"] = self.child_marker
        payload["carries_forward"] = self.carries_forward
        payload.setdefault("also_numbered", list(self.also_numbered))
        return payload


class NumberedReport(BaseModel):
    """Typed outward payload for numbered genealogy report commands."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    report: Literal["ahnentafel", "register"]
    subject_id: str
    system: str
    generations: int | None = None
    people: tuple[NumberedReportPersonRow, ...] = ()

    @model_serializer(mode="wrap")
    def _serialize(self, handler: Any) -> dict[str, Any]:
        payload = cast(dict[str, Any], handler(self))
        payload["generations"] = self.generations
        payload.setdefault("people", list(self.people))
        return payload


class OutputRecord(BaseModel):
    """Typed renderer input for a projected GEDCOM record."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    entity_id: str | None = None
    kind: str
    src: OutputSourceRef | None = None
    name: str | None = None
    name_variants: tuple[str, ...] = ()
    names: tuple[OutputNameOccurrence, ...] = ()
    nickname: str | None = None
    date: str | None = None
    date_tag: str | None = None
    place: str | None = None
    note: str | None = None
    media_path: str | None = None
    media_refs: tuple[str, ...] = ()
    source_text: str | None = None
    title: str | None = None
    publication: str | None = None
    repository_ref: str | None = None
    relations: tuple[str, ...] = ()
    field_src: OutputFieldSourceMap | None = None
    raw_fields: dict[str, object | None] = Field(default_factory=dict)
    events: tuple[OutputEvent, ...] = ()
    associations: tuple[OutputAssociation, ...] = ()
    is_alive: bool | None = None
    lifespan_years: ComputedDateField | None = None
    current_age: ComputedDateField | None = None
    marriage_age_husb: ComputedDateField | None = None
    marriage_age_wife: ComputedDateField | None = None
    age_gap_years: ComputedDateField | None = None
    marriage_duration_years: ComputedDateField | None = None
    years_to_first_child: ComputedDateField | None = None
    years_between_first_and_last_child: ComputedDateField | None = None

    def without_provenance(self) -> Self:
        """Return this record without file/line provenance."""
        return self.model_copy(
            update={
                "src": None,
                "field_src": None,
                "events": tuple(event.without_provenance() for event in self.events),
                "associations": tuple(
                    association.without_provenance() for association in self.associations
                ),
                "names": tuple(name.without_provenance() for name in self.names),
            }
        )

    def lean_search_view(self, *, with_src: bool = False) -> OutputRecord:
        """Return the lean search-row projection for this record."""
        return OutputRecord(
            entity_id=self.entity_id,
            kind=self.kind,
            src=self.src if with_src else None,
            name=self.name,
            date=self.date,
            date_tag=self.date_tag,
            place=self.place,
            field_src=self.field_src if with_src else None,
        )


class LookupPayload(BaseModel):
    """Structured lookup payload for JSON lookup and expansion surfaces."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    _raw_fields: dict[str, Any] = PrivateAttr(default_factory=dict)
    _expanded_fields: dict[str, Any] = PrivateAttr(default_factory=dict)

    entity_id: str | None = None
    kind: str
    src: OutputSourceRef | None = None
    name: str | None = None
    name_variants: tuple[str, ...] = ()
    names: tuple[OutputNameOccurrence, ...] = ()
    nickname: str | None = None
    date: str | None = None
    date_tag: str | None = None
    place: str | None = None
    note: str | None = None
    media_path: str | None = None
    media_refs: tuple[str, ...] = ()
    source_text: str | None = None
    title: str | None = None
    publication: str | None = None
    repository_ref: str | None = None
    relations: tuple[str, ...] = ()
    events: tuple[OutputEvent, ...] = ()
    associations: tuple[OutputAssociation, ...] = ()
    is_alive: bool | None = None
    lifespan_years: ComputedDateField | None = None
    current_age: ComputedDateField | None = None
    marriage_age_husb: ComputedDateField | None = None
    marriage_age_wife: ComputedDateField | None = None
    age_gap_years: ComputedDateField | None = None
    marriage_duration_years: ComputedDateField | None = None
    years_to_first_child: ComputedDateField | None = None
    years_between_first_and_last_child: ComputedDateField | None = None
    field_src: OutputFieldSourceMap | None = None
    event_notes: tuple[OutputCitationEventNotes, ...] | None = None

    @classmethod
    def from_record(
        cls,
        record: OutputRecord,
        *,
        expanded_fields: dict[str, Any] | None = None,
    ) -> Self:
        """Build a lookup payload from one typed output record."""
        normalized_expanded_fields = {} if expanded_fields is None else dict(expanded_fields)
        event_notes = normalized_expanded_fields.pop("EVENT_NOTES", None)
        payload = cls(
            **record.model_dump(exclude={"raw_fields"}),
            event_notes=event_notes,
        )
        object.__setattr__(payload, "_raw_fields", dict(record.raw_fields))
        object.__setattr__(
            payload,
            "_expanded_fields",
            normalized_expanded_fields,
        )
        return payload

    @model_serializer(mode="wrap")
    def _serialize(self, handler: Any) -> dict[str, Any]:
        payload = cast(dict[str, Any], handler(self))
        payload["events"] = [serialize_output_event_payload(event) for event in self.events]
        payload.pop("event_notes", None)
        if self.event_notes is not None:
            payload["EVENT_NOTES"] = [
                note.model_dump(mode="json", exclude_none=True) for note in self.event_notes
            ]
        payload = serialize_output_record_payload(self, payload)
        payload.update(suppress_shadow_raw_fields(payload, self._raw_fields))
        payload = suppress_duplicate_source_text(payload)
        payload.update(self._expanded_fields)
        return payload


TraversalRole = Literal["CHIL-of", "HUSB-of", "WIFE-of", "SIBLING-of"]


class TraversalPerson(BaseModel):
    """Typed traversal element representing one person."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    type: Literal["person"] = "person"
    entity_id: str
    record: LookupPayload | None = None


class TraversalEdge(BaseModel):
    """Typed traversal element representing one family edge."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    type: Literal["edge"] = "edge"
    fam_id: str
    role: TraversalRole
    record: LookupPayload | None = None


TraversalElement = TraversalPerson | TraversalEdge


class TraversalEnvelope(BaseModel):
    """Shared traversal wrapper with stable element and notice fields."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    elements: list[TraversalElement] = Field(default_factory=list)
    notices: list[str] = Field(default_factory=list)


class CommonAncestorPath(TraversalEnvelope):
    """Wrapper payload for common-ancestor mode."""

    common_ancestor: str | None

    @model_serializer(mode="wrap")
    def _serialize(self, handler: Any) -> dict[str, Any]:
        payload = cast(dict[str, Any], handler(self))
        payload["common_ancestor"] = self.common_ancestor
        return payload


class CousinDistancePath(TraversalEnvelope):
    """Wrapper payload for cousin-distance mode."""

    cousin_distance: int | None
    generations_removed: int | None = None

    @model_serializer(mode="wrap")
    def _serialize(self, handler: Any) -> dict[str, Any]:
        payload = cast(dict[str, Any], handler(self))
        payload["cousin_distance"] = self.cousin_distance
        payload["generations_removed"] = self.generations_removed
        return payload


class ValidationIssuePayload(BaseModel):
    """Structured validate payload item for JSON validation output."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    code: str
    message: str
    location: ErrorLocation | None = None
    entity_id: str | None = None


class ValidationIssueList(RootModel[list[ValidationIssuePayload]]):
    """Top-level JSON payload for validate-command output."""

    model_config = ConfigDict(frozen=True)


def serialize_output_event_payload(event: OutputEvent | dict[str, Any]) -> dict[str, Any]:
    """Flatten one event payload to its public JSON surface."""
    payload = (
        event if isinstance(event, dict) else event.model_dump(mode="json", exclude_none=False)
    )
    age_at_event = (
        event.age_at_event if isinstance(event, OutputEvent) else payload.pop("age_at_event", None)
    )
    if isinstance(age_at_event, ComputedDateField):
        payload.update(flatten_computed_field("age_at_event", age_at_event))
    return payload


def serialize_output_record_payload(
    record: OutputRecord | LookupPayload | None,
    payload: dict[str, Any],
) -> dict[str, Any]:
    """Flatten typed computed-date helpers into flat sibling keys."""
    serialized = dict(payload)
    if not serialized.get("names"):
        serialized.pop("names", None)
    for field_name, full_key in _COMPUTED_RECORD_FIELDS:
        value = (
            getattr(record, field_name) if record is not None else serialized.pop(field_name, None)
        )
        if record is not None:
            serialized.pop(field_name, None)
        if isinstance(value, ComputedDateField):
            serialized.update(flatten_computed_field(field_name, value, full_key=full_key))
    return serialized


def suppress_duplicate_source_text(payload: dict[str, Any]) -> dict[str, Any]:
    """Remove outward TEXT only when it duplicates source_text exactly."""
    source_text_spec = record_outward_field_spec("TEXT")
    source_text_key = "source_text" if source_text_spec is None else source_text_spec.json_key
    if (
        payload.get("TEXT") == payload.get(source_text_key)
        and payload.get(source_text_key) is not None
    ):
        payload = dict(payload)
        payload.pop("TEXT", None)
    return payload


def suppress_shadow_raw_fields(
    payload: dict[str, Any],
    raw_fields: dict[str, Any],
) -> dict[str, Any]:
    """Return canonical outward record fields, dropping raw-field shadows."""
    shadowed_event_tags = {
        event["tag"]
        for event in payload.get("events", [])
        if isinstance(event, dict) and isinstance(event.get("tag"), str)
    }
    filtered = outward_record_raw_fields(payload, raw_fields)
    for tag in shadowed_event_tags:
        filtered.pop(tag, None)
    for raw_tag in (
        "ASSO",
        "CHIL",
        "FAMC",
        "FAMS",
        "HUSB",
        "NAME",
        "NICK",
        "OBJE",
        "PUBL",
        "REPO",
        "SEX",
        "SOUR",
        "TEXT",
        "TITL",
        "WIFE",
    ):
        spec = record_outward_field_spec(raw_tag)
        if spec is None or not spec.shadow_raw:
            continue
        filtered.pop(raw_tag, None)
    return filtered
