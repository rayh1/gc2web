"""Public package surface for gedq."""

from gedq.config import Settings
from gedq.errors import (
    AppError,
    ErrorDetail,
    ErrorEnvelope,
    ErrorLocation,
    InternalError,
    ParseDataError,
    UserError,
)

__all__ = [
    "AppError",
    "ErrorDetail",
    "ErrorEnvelope",
    "ErrorLocation",
    "InternalError",
    "ParseDataError",
    "Settings",
    "UserError",
]

__version__ = "2.1.0"
